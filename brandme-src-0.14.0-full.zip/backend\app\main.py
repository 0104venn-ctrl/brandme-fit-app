"""brandme Fit example backend.

Run:  uvicorn app.main:app --host 0.0.0.0 --port 8000   (from the backend/ folder)

The OpenAI API key lives only in this server's environment (backend/.env) and is never sent
to or stored in the Android app. Uploaded screenshots are processed in memory and not saved.
"""
from __future__ import annotations

import logging
import os

from fastapi import FastAPI, File, Form, HTTPException, UploadFile

from . import vision
from .compare import ALGORITHM_VERSION, compare
from .schemas import AnalyzeScreenResponse, CompareRequest, CompareResponse

try:  # optional: load backend/.env when python-dotenv is installed
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # pragma: no cover
    pass

MAX_IMAGE_BYTES = int(os.environ.get("MAX_IMAGE_BYTES", str(6 * 1024 * 1024)))
ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp"}

log = logging.getLogger("brandme")
app = FastAPI(title="brandme Fit backend (example)", version="0.1.0")


@app.get("/health")
def health() -> dict:
    return {
        "ok": True,
        "algorithmVersion": ALGORITHM_VERSION,
        "aiConfigured": bool(os.environ.get("OPENAI_API_KEY") and os.environ.get("OPENAI_MODEL")),
    }


@app.post("/api/analyze-screen", response_model=AnalyzeScreenResponse)
async def analyze_screen(image: UploadFile = File(...), consent: bool = Form(False)) -> AnalyzeScreenResponse:
    if not consent:
        raise HTTPException(status_code=400, detail="CONSENT_REQUIRED")
    mime = image.content_type or "application/octet-stream"
    if mime not in ALLOWED_MIME:
        raise HTTPException(status_code=415, detail="UNSUPPORTED_IMAGE_TYPE")
    data = await image.read(MAX_IMAGE_BYTES + 1)
    if len(data) > MAX_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail="IMAGE_TOO_LARGE")
    try:
        # Never log or persist the image itself.
        return vision.analyze_image(data, mime)
    except vision.NotConfigured:
        raise HTTPException(status_code=503, detail="AI_NOT_CONFIGURED")
    except Exception as e:  # upstream/network errors
        log.warning("vision call failed: %s", type(e).__name__)
        raise HTTPException(status_code=502, detail="AI_UPSTREAM_FAILED")
    finally:
        del data


@app.post("/api/compare", response_model=CompareResponse)
def compare_endpoint(req: CompareRequest) -> CompareResponse:
    return compare(req.reference, req.chart)
