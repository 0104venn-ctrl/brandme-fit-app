"""
MakeHuman CC0 base mesh + targets -> compact body model asset for the app.

Usage: python -I mh_process.py <assets_dir> <out_dir>
Outputs: body_model.bin, body_model.json (see app BodyModel.kt for the format)
"""
import json
import struct
import sys
from pathlib import Path

import numpy as np

src = Path(sys.argv[1])
out = Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------- load base
verts = []
groups = {}
cur = None
for line in open(src / "base.obj", encoding="utf-8"):
    if line.startswith("v "):
        verts.append([float(x) for x in line.split()[1:4]])
    elif line.startswith("g "):
        cur = line.split()[1]
        groups.setdefault(cur, [])
    elif line.startswith("f "):
        idx = [int(p.split("/")[0]) - 1 for p in line.split()[1:]]
        groups[cur].append(idx)
base = np.array(verts) * 10.0  # dm -> cm

body_faces = groups["body"]
body_vids = sorted({i for f in body_faces for i in f})
remap = {old: new for new, old in enumerate(body_vids)}
tris = []
for f in body_faces:
    f = [remap[i] for i in f]
    tris.append([f[0], f[1], f[2]])
    if len(f) == 4:
        tris.append([f[0], f[2], f[3]])
tris = np.array(tris, dtype=np.int64)
V = len(body_vids)
print("body vertices", V, "triangles", len(tris))

joints = {}
for name, faces in groups.items():
    if name.startswith("joint-"):
        ids = sorted({i for f in faces for i in f})
        joints[name] = ids


def load_target(name):
    d = np.zeros_like(base)
    for line in open(src / "t" / name, encoding="utf-8"):
        if not line.strip() or line.startswith("#"):
            continue
        p = line.split()
        d[int(p[0])] = [float(p[1]) * 10, float(p[2]) * 10, float(p[3]) * 10]
    return d


def gender_full(g):
    full = base + load_target(f"universal-{g}-young-averagemuscle-averageweight.target")
    for r in ["african", "asian", "caucasian"]:
        full = full + load_target(f"{r}-{g}-young.target") / 3.0
    return full


def joint_pos(full, name):
    return full[joints[name]].mean(axis=0)


# ---------------------------------------------------------------- measuring
def slice_loops(p, y):
    """Cross-section of the body mesh at height y -> list of point loops (x, z)."""
    a, b, c = p[tris[:, 0]], p[tris[:, 1]], p[tris[:, 2]]
    pts = []
    for e0, e1, e2 in [(a, b, c)]:
        pass
    ya, yb, yc = a[:, 1] - y, b[:, 1] - y, c[:, 1] - y
    segs = []
    for (p0, y0), (p1, y1), (p2, y2) in [((a, ya), (b, yb), (c, yc))]:
        pass
    sa, sb, sc = np.sign(ya), np.sign(yb), np.sign(yc)
    mask = ~((sa == sb) & (sb == sc))
    out_pts = []
    for i in np.nonzero(mask)[0]:
        q = []
        for (u, yu), (v, yv) in [((a[i], ya[i]), (b[i], yb[i])), ((b[i], yb[i]), (c[i], yc[i])), ((c[i], yc[i]), (a[i], ya[i]))]:
            if (yu > 0) != (yv > 0):
                t = yu / (yu - yv)
                q.append(u + (v - u) * t)
        if len(q) == 2:
            out_pts.append(q)
    return np.array(out_pts)  # (n, 2, 3)


def hull_perimeter(xz):
    pts = sorted(map(tuple, xz))
    if len(pts) < 3:
        return 0.0

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower, upper = [], []
    for q in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], q) <= 0:
            lower.pop()
        lower.append(q)
    for q in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], q) <= 0:
            upper.pop()
        upper.append(q)
    hull = np.array(lower[:-1] + upper[:-1])
    return float(np.sum(np.linalg.norm(hull - np.roll(hull, -1, axis=0), axis=1)))


def torso_section(p, y, half_width):
    """Tape-measure circumference of the torso at y: segments whose x lies within the torso band."""
    segs = slice_loops(p, y)
    if len(segs) == 0:
        return 0.0, None
    mid = segs.mean(axis=1)
    keep = np.abs(mid[:, 0]) < half_width
    pts = segs[keep].reshape(-1, 3)
    if len(pts) < 3:
        return 0.0, None
    return hull_perimeter(pts[:, [0, 2]]), pts


def measure(p):
    ground = p[:, 1].min()
    top = p[:, 1].max()
    h = top - ground
    ls, rs = joint_pos(p, "joint-l-shoulder"), joint_pos(p, "joint-r-shoulder")
    lw = joint_pos(p, "joint-l-hand")
    # torso half width limit: inside the shoulder joints (excludes arms)
    band = abs(ls[0]) * 0.92
    def circ_at(frac):
        return torso_section(p, ground + frac * h, band)[0]
    chest_ys = np.linspace(0.68, 0.74, 7)
    chest = max(circ_at(f) for f in chest_ys)
    chest_y = chest_ys[int(np.argmax([circ_at(f) for f in chest_ys]))]
    waist_ys = np.linspace(0.57, 0.66, 10)
    waist = min(circ_at(f) for f in waist_ys)
    waist_y = waist_ys[int(np.argmin([circ_at(f) for f in waist_ys]))]
    hip_band = abs(ls[0]) * 1.3
    hip_ys = np.linspace(0.47, 0.55, 9)
    hips_list = [torso_section(p, ground + f * h, hip_band)[0] for f in hip_ys]
    hip = max(hips_list)
    hip_y = hip_ys[int(np.argmax(hips_list))]
    # shoulder width: outer surface at the top of the shoulders (lateral-most vertex above the shoulder joint)
    # 어깨너비·팔길이는 관절 중심 사이 거리로 재고, 기본 체형이 평균 비율(키의 0.245/0.225, 0.33)이 되도록 앱에서 보정한다
    shoulder = float(np.linalg.norm(ls - rs))
    arm = float(np.linalg.norm(lw - ls))
    return {
        "height": float(h), "chest": float(chest), "waist": float(waist), "hip": float(hip),
        "shoulder": float(shoulder), "arm": float(arm),
        "_chest_y": float(chest_y), "_waist_y": float(waist_y), "_hip_y": float(hip_y),
    }


print("joints:", [k for k in joints if "shoulder" in k or "hand" in k or "wrist" in k][:10])

# ---------------------------------------------------------------- build
genders = {"male": gender_full("male"), "female": gender_full("female")}
weight_d = {}
for g in genders:
    avg = load_target(f"universal-{g}-young-averagemuscle-averageweight.target")
    weight_d[g] = {
        "pos": load_target(f"universal-{g}-young-averagemuscle-maxweight.target") - avg,
        "neg": load_target(f"universal-{g}-young-averagemuscle-minweight.target") - avg,
    }
MEASURE = {
    "bust": "bust-circ", "waist": "waist-circ", "hips": "hips-circ", "shoulder": "shoulder-dist",
    "upperarm": "upperarm-length", "lowerarm": "lowerarm-length",
}
mdeltas = {k: {"pos": load_target(f"measure-{v}-incr.target"), "neg": load_target(f"measure-{v}-decr.target")} for k, v in MEASURE.items()}

# variables: weight (gender specific), bust, waist, hips, shoulder, arm (upper+lower together)
VARS = ["weight", "bust", "waist", "hips", "shoulder", "arm"]
MEAS = ["chest", "waist", "hip", "shoulder", "arm"]


def delta(g, var, sign):
    if var == "weight":
        return weight_d[g][sign]
    if var == "arm":
        return mdeltas["upperarm"][sign] + mdeltas["lowerarm"][sign]
    return mdeltas[var][sign]


meta = {"vars": VARS, "measurements": MEAS, "genders": {}}
for g, full in genders.items():
    m0 = measure(full)
    jac = {}
    for var in VARS:
        jac[var] = {}
        for sign in ["pos", "neg"]:
            m1 = measure(full + delta(g, var, sign))
            jac[var][sign] = [m1[k] - m0[k] for k in MEAS]
    meta["genders"][g] = {"base": {k: m0[k] for k in ["height"] + MEAS}, "jacobian": jac,
                          "levels": {k: m0[k] for k in ["_chest_y", "_waist_y", "_hip_y"]}}
    print(g, {k: round(v, 1) for k, v in m0.items()})
    for var in VARS:
        print("   ", var, "pos", [round(x, 1) for x in jac[var]["pos"]], "neg", [round(x, 1) for x in jac[var]["neg"]])

# anchors (vertex indices in body numbering) for measurement call-outs, from the male neutral body
full = genders["male"]
pb = full[body_vids]
ground, top = pb[:, 1].min(), pb[:, 1].max()
h = top - ground


def nearest(target):
    return int(np.argmin(np.linalg.norm(pb - target, axis=1)))


lv = meta["genders"]["male"]["levels"]
ls = joint_pos(full, "joint-l-shoulder")
anchors = {}
for name, frac in [("chest", lv["_chest_y"]), ("waist", lv["_waist_y"]), ("hip", lv["_hip_y"])]:
    y = ground + frac * h
    band = abs(ls[0]) * (1.3 if name == "hip" else 0.92)
    cand = np.nonzero((np.abs(pb[:, 1] - y) < 1.0) & (np.abs(pb[:, 0]) < band))[0]
    anchors[name] = int(cand[np.argmax(pb[cand, 0])])  # +x side of the torso
near = np.nonzero((pb[:, 1] > ls[1]) & (np.abs(pb[:, 0]) < abs(ls[0]) + 8) & (pb[:, 0] > 0))[0]
anchors["shoulder"] = int(near[np.argmax(pb[near, 0])]) if len(near) else nearest(ls)
mid_arm = (joint_pos(full, "joint-l-shoulder") + joint_pos(full, "joint-l-hand")) / 2
anchors["arm"] = nearest(mid_arm + np.array([3.0, 0, 0]))
anchors["height"] = int(np.argmax(pb[:, 1]))
meta["anchors"] = anchors
# 반대쪽(-x) 기준점: 좌우 대칭 위치에 가장 가까운 정점
meta["anchorsMirror"] = {k: nearest(pb[v] * np.array([-1.0, 1.0, 1.0])) for k, v in anchors.items()}
print("anchors", anchors, meta["anchorsMirror"])

# 가슴 끝 돌출부(유두) 주변은 하얀 모형에서 부드럽게 다듬는다: 남녀 기본형에서 가슴 높이의 가장 앞 정점 주변
smooth = set()
for g in ["male", "female"]:
    q = genders[g][body_vids]
    gy, gh = q[:, 1].min(), q[:, 1].max() - q[:, 1].min()
    for side in [1, -1]:
        cand = np.nonzero((q[:, 1] > gy + 0.66 * gh) & (q[:, 1] < gy + 0.76 * gh) & (side * q[:, 0] > 4) & (side * q[:, 0] < 16))[0]
        tip = cand[np.argmax(q[cand, 2])]
        smooth |= set(np.nonzero(np.linalg.norm(q - q[tip], axis=1) < 3.2)[0].tolist())
meta["smooth"] = sorted(int(i) for i in smooth)
print("smooth vertices", len(smooth))

# ---------------------------------------------------------------- body parts (for garment fitting)
# 0 head, 1 neck, 2 torso, 3 L upper arm, 4 R upper arm, 5 L forearm, 6 R forearm, 7 L hand, 8 R hand, 9 legs
J = lambda n: joint_pos(full, n)
bones = []  # (part, a, b, radius)
spine = [J("joint-pelvis"), J("joint-spine-4"), J("joint-spine-3"), J("joint-spine-2"), J("joint-spine-1"), J("joint-neck")]
for a, b in zip(spine, spine[1:]):
    bones.append((2, a, b, 13.0))
bones.append((1, J("joint-neck"), J("joint-head"), 5.5))
bones.append((0, J("joint-head"), J("joint-head-2"), 9.0))
for side, (up, fo, hd) in {"l": (3, 5, 7), "r": (4, 6, 8)}.items():
    bones.append((up, J(f"joint-{side}-shoulder"), J(f"joint-{side}-elbow"), 4.5))
    bones.append((fo, J(f"joint-{side}-elbow"), J(f"joint-{side}-hand"), 3.5))
    hand_end = J(f"joint-{side}-hand") + (J(f"joint-{side}-hand") - J(f"joint-{side}-elbow")) * 0.7
    bones.append((hd, J(f"joint-{side}-hand"), hand_end, 2.5))
    bones.append((9, J(f"joint-{side}-upper-leg"), J(f"joint-{side}-knee"), 8.0))
    bones.append((9, J(f"joint-{side}-knee"), J(f"joint-{side}-ankle"), 5.5))
    bones.append((9, J(f"joint-{side}-ankle"), J(f"joint-{side}-foot-2"), 4.0))
# clavicles belong to torso (shoulder top)
for side in ["l", "r"]:
    bones.append((2, J(f"joint-{side}-clavicle"), J(f"joint-{side}-shoulder"), 6.0))

def seg_dist(P, a, b):
    ab = b - a
    t = np.clip(((P - a) @ ab) / max(ab @ ab, 1e-9), 0, 1)
    return np.linalg.norm(P - (a + t[:, None] * ab), axis=1)

scores = np.stack([seg_dist(pb, a, b) - r for (_, a, b, r) in bones], axis=1)
part_of_bone = np.array([b[0] for b in bones])
parts = part_of_bone[np.argmin(scores, axis=1)]
armT = np.zeros(len(pb))
for side, ids in {"l": (3, 5, 7), "r": (4, 6, 8)}.items():
    Sj, Hj = J(f"joint-{side}-shoulder"), J(f"joint-{side}-hand")
    ax = Hj - Sj
    sel = np.isin(parts, ids)
    armT[sel] = ((pb[sel] - Sj) @ ax) / (ax @ ax)
meta["parts"] = [int(x) for x in parts]
meta["armT"] = [round(float(x), 3) for x in armT]
print("parts", np.bincount(parts, minlength=10).tolist())

# ---------------------------------------------------------------- write
deltas = []
names = []
for g in ["male", "female"]:
    for sign in ["pos", "neg"]:
        deltas.append(weight_d[g][sign][body_vids]); names.append(f"{g}-weight-{sign}")
for var in ["bust", "waist", "hips", "shoulder", "upperarm", "lowerarm"]:
    for sign in ["pos", "neg"]:
        deltas.append(mdeltas[var][sign][body_vids]); names.append(f"{var}-{sign}")
meta["deltas"] = names
maxabs = max(np.abs(d).max() for d in deltas)
scale = 32000.0 / maxabs
meta["deltaScale"] = scale

with open(out / "body_model.bin", "wb") as f:
    f.write(b"BMHM")
    f.write(struct.pack("<iiiif", 1, V, len(tris), len(deltas), scale))
    for g in ["male", "female"]:
        pos = genders[g][body_vids].astype("<f4")
        f.write(pos.tobytes())
    f.write(tris.astype("<u2").tobytes())
    for d in deltas:
        f.write(np.round(d * scale).astype("<i2").tobytes())
json.dump(meta, open(out / "body_model.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("written", (out / "body_model.bin").stat().st_size, "bytes")
