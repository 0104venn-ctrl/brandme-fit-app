"""
MakeHuman CC0 clothes (Shirts 01 pack) -> clothes asset bound to the app's body mesh.

Usage: python -I mh_clothes.py <base_assets_dir> <shirts01_extracted_dir> <out_dir>
  base_assets_dir: folder with base.obj and t/*.target (same as mh_process.py)
Output: clothes_model.bin (format in app ClothesLibrary.kt)

Each garment is fitted to the neutral body with its .mhclo binding, subdivided once (Catmull-Clark) for
smoothness, then re-bound to the nearest point of the app's body mesh (body triangle + barycentric weights +
offset along the surface normal) so it follows the user's body shape in the app.
"""
import struct
import sys
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

base_dir = Path(sys.argv[1]); clothes_dir = Path(sys.argv[2]); out = Path(sys.argv[3])
out.mkdir(parents=True, exist_ok=True)

GARMENTS = [
    # (name in app, folder, mhclo, obj, body gender used for binding)
    ("tee_male", "elvs_crude_t-shirt_male", "elvs_crude_t-shirt_male.mhclo", "crude_male_shirt.obj", "male"),
    ("tee_female", "joepal_crude_t-shirt_female", "joepal_crude_t-shirt_female.mhclo", "crudefemaletshirt.obj", "female"),
    ("sweater", "toigo_fisherman_sweater", "toigo_fisherman_sweater.mhclo", "sweater_fisherman.obj", "male"),
]

# ---------------------------------------------------------------- base body (same as mh_process.py)
verts, groups, cur = [], {}, None
for line in open(base_dir / "base.obj", encoding="utf-8"):
    if line.startswith("v "):
        verts.append([float(x) for x in line.split()[1:4]])
    elif line.startswith("g "):
        cur = line.split()[1]; groups.setdefault(cur, [])
    elif line.startswith("f "):
        groups[cur].append([int(p.split("/")[0]) - 1 for p in line.split()[1:]])
base = np.array(verts) * 10.0
body_faces = groups["body"]
body_vids = sorted({i for f in body_faces for i in f})
remap = {o: n for n, o in enumerate(body_vids)}
btris = []
for f in body_faces:
    f = [remap[i] for i in f]
    btris.append([f[0], f[1], f[2]])
    if len(f) == 4:
        btris.append([f[0], f[2], f[3]])
btris = np.array(btris)


def load_target(name):
    d = np.zeros_like(base)
    for line in open(base_dir / "t" / name, encoding="utf-8"):
        if not line.strip() or line.startswith("#"):
            continue
        p = line.split()
        d[int(p[0])] = [float(p[1]) * 10, float(p[2]) * 10, float(p[3]) * 10]
    return d


def gender_full(g):
    full = base + load_target(f"universal-{g}-young-averagemuscle-averageweight.target")
    for r in ["african", "asian", "caucasian"]:
        full = full + load_target(f"{r}-{g}-young.target") / 3.0
    return full


def vertex_normals(p, tris):
    n = np.zeros_like(p)
    fn = np.cross(p[tris[:, 1]] - p[tris[:, 0]], p[tris[:, 2]] - p[tris[:, 0]])
    for k in range(3):
        np.add.at(n, tris[:, k], fn)
    return n / (np.linalg.norm(n, axis=1, keepdims=True) + 1e-12)


# ---------------------------------------------------------------- mhclo fitting
def fit_mhclo(full, mhclo_path):
    scales = {}
    binds = []
    in_verts = False
    for line in open(mhclo_path, encoding="utf-8", errors="replace"):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        p = s.split()
        if p[0] in ("x_scale", "y_scale", "z_scale"):
            scales[p[0][0]] = (int(p[1]), int(p[2]), float(p[3]) * 10.0)
            continue
        if p[0] == "verts":
            in_verts = True; continue
        if in_verts:
            if p[0].lstrip("-").replace(".", "").isdigit() and (len(p) == 9 or len(p) == 1):
                binds.append(p)
                continue
            in_verts = False
    sc = np.array([abs(full[scales[a][0]][k] - full[scales[a][1]][k]) / scales[a][2] for k, a in enumerate("xyz")])
    out_pts = []
    for b in binds:
        if len(b) == 1:
            out_pts.append(full[int(b[0])])
        else:
            v = [int(x) for x in b[:3]]; w = [float(x) for x in b[3:6]]; d = np.array([float(x) for x in b[6:9]]) * 10.0
            out_pts.append(w[0] * full[v[0]] + w[1] * full[v[1]] + w[2] * full[v[2]] + d * sc)
    return np.array(out_pts)


def load_obj_faces(path):
    faces = []
    for line in open(path, encoding="utf-8", errors="replace"):
        if line.startswith("f "):
            faces.append([int(t.split("/")[0]) - 1 for t in line.split()[1:]])
    return faces


def catmull_clark(V, F):
    V = np.asarray(V, float)
    face_pts = np.array([V[f].mean(axis=0) for f in F])
    edges = {}
    for fi, f in enumerate(F):
        for i in range(len(f)):
            a, b = f[i], f[(i + 1) % len(f)]
            edges.setdefault((min(a, b), max(a, b)), []).append(fi)
    edge_ids = {}
    edge_pts = []
    for (a, b), fs in edges.items():
        if len(fs) == 2:
            pt = (V[a] + V[b] + face_pts[fs[0]] + face_pts[fs[1]]) / 4
        else:
            pt = (V[a] + V[b]) / 2  # boundary (hem, cuffs, neck)
        edge_ids[(a, b)] = len(edge_pts); edge_pts.append(pt)
    edge_pts = np.array(edge_pts)
    # move original points
    v_faces = [[] for _ in V]; v_edges = [[] for _ in V]
    for fi, f in enumerate(F):
        for a in f:
            v_faces[a].append(fi)
    for (a, b), fs in edges.items():
        v_edges[a].append((a, b)); v_edges[b].append((a, b))
    newV = V.copy()
    for i in range(len(V)):
        es = v_edges[i]
        if not es:
            continue
        boundary = [e for e in es if len(edges[e]) == 1]
        if boundary:
            nb = [e[0] if e[1] == i else e[1] for e in boundary]
            newV[i] = 0.75 * V[i] + 0.125 * (V[nb[0]] + V[nb[-1]])
            continue
        n = len(v_faces[i])
        Fm = face_pts[v_faces[i]].mean(axis=0)
        Rm = np.mean([(V[a] + V[b]) / 2 for a, b in es], axis=0)
        newV[i] = (Fm + 2 * Rm + (n - 3) * V[i]) / n
    nV = len(V); nF = len(face_pts)
    allV = np.vstack([newV, face_pts, edge_pts])
    quads = []
    for fi, f in enumerate(F):
        k = len(f)
        for i in range(k):
            a, b, c = f[(i - 1) % k], f[i], f[(i + 1) % k]
            e1 = nV + nF + edge_ids[(min(a, b), max(a, b))]
            e2 = nV + nF + edge_ids[(min(b, c), max(b, c))]
            quads.append([b, e2, nV + fi, e1])
    return allV, quads


def closest_point_on_tri(p, a, b, c):
    """Ericson's closest point; returns point and barycentric (u,v,w) for a,b,c."""
    ab, ac, ap = b - a, c - a, p - a
    d1, d2 = ab @ ap, ac @ ap
    if d1 <= 0 and d2 <= 0: return a, (1, 0, 0)
    bp = p - b; d3, d4 = ab @ bp, ac @ bp
    if d3 >= 0 and d4 <= d3: return b, (0, 1, 0)
    vc = d1 * d4 - d3 * d2
    if vc <= 0 and d1 >= 0 and d3 <= 0:
        v = d1 / (d1 - d3); return a + v * ab, (1 - v, v, 0)
    cp = p - c; d5, d6 = ab @ cp, ac @ cp
    if d6 >= 0 and d5 <= d6: return c, (0, 0, 1)
    vb = d5 * d2 - d1 * d6
    if vb <= 0 and d2 >= 0 and d6 <= 0:
        w = d2 / (d2 - d6); return a + w * ac, (1 - w, 0, w)
    va = d3 * d6 - d5 * d4
    if va <= 0 and (d4 - d3) >= 0 and (d5 - d6) >= 0:
        w = (d4 - d3) / ((d4 - d3) + (d5 - d6)); return b + w * (c - b), (0, 1 - w, w)
    denom = 1.0 / (va + vb + vc); v = vb * denom; w = vc * denom
    return a + ab * v + ac * w, (1 - v - w, v, w)


records = []
for name, folder, mhclo, objf, gender in GARMENTS:
    full = gender_full(gender)
    gpos = fit_mhclo(full, clothes_dir / folder / mhclo)
    faces = load_obj_faces(clothes_dir / folder / objf)
    assert max(max(f) for f in faces) < len(gpos), name
    V2, Q2 = catmull_clark(gpos, faces)
    tris = []
    for q in Q2:
        tris += [[q[0], q[1], q[2]], [q[0], q[2], q[3]]]
    tris = np.array(tris)
    # bind to body mesh (neutral body of the same gender)
    bp = full[body_vids]
    bn = vertex_normals(bp, btris)
    v2t = [[] for _ in range(len(bp))]
    for ti, t in enumerate(btris):
        for v in t:
            v2t[v].append(ti)
    tree = cKDTree(bp)
    bind_tri = np.zeros((len(V2), 3), np.int64); bind_w = np.zeros((len(V2), 3)); bind_d = np.zeros(len(V2))
    for i, g in enumerate(V2):
        _, near = tree.query(g, k=10)
        cands = {t for v in near for t in v2t[v]}
        best = None
        for t in cands:
            a, b, c = bp[btris[t]]
            cp, bc = closest_point_on_tri(g, a, b, c)
            dd = np.sum((g - cp) ** 2)
            if best is None or dd < best[0]:
                best = (dd, t, bc, cp)
        _, t, bc, cp = best
        n = bc[0] * bn[btris[t][0]] + bc[1] * bn[btris[t][1]] + bc[2] * bn[btris[t][2]]
        n /= np.linalg.norm(n) + 1e-12
        bind_tri[i] = btris[t]; bind_w[i] = bc; bind_d[i] = (g - cp) @ n
    recon = np.einsum("ij,ijk->ik", bind_w, bp[bind_tri]) + bind_d[:, None] * np.einsum("ij,ijk->ik", bind_w, bn[bind_tri])
    err = np.linalg.norm(recon - V2, axis=1)
    print(name, "verts", len(V2), "tris", len(tris), "offset cm min/med/max", round(bind_d.min(), 2), round(np.median(bind_d), 2), round(bind_d.max(), 2),
          "rebind err cm med/max", round(np.median(err), 3), round(err.max(), 2))
    records.append((name, gender, V2, tris, bind_tri, bind_w, bind_d))

with open(out / "clothes_model.bin", "wb") as f:
    f.write(b"BMCL"); f.write(struct.pack("<ii", 1, len(records)))
    for name, gender, V2, tris, bt, bw, bd in records:
        nb = name.encode("utf-8"); f.write(struct.pack("<i", len(nb))); f.write(nb)
        f.write(struct.pack("<iii", 0 if gender == "male" else 1, len(V2), len(tris)))
        f.write(tris.astype("<u2").tobytes())
        f.write(bt.astype("<u2").tobytes())
        f.write(bw.astype("<f4").tobytes())
        f.write(bd.astype("<f4").tobytes())
print("written", (out / "clothes_model.bin").stat().st_size)
