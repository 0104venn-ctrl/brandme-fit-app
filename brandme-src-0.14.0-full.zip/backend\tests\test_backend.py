"""Run from backend/:  python -m unittest discover -s tests"""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pydantic import ValidationError  # noqa: E402

from app.compare import compare  # noqa: E402
from app.schemas import ReferenceIn, SizeChartCandidate  # noqa: E402
from app.vision import validate_model_output  # noqa: E402

REF = ReferenceIn(name="t", shoulder=46, chestFlat=52, length=70)


def chart(*rows, method="FLAT"):
    return SizeChartCandidate(chestMethod=method, sizes=[dict(r) for r in rows])


class CompareTest(unittest.TestCase):
    def test_diff_and_closest(self):
        r = compare(REF, chart({"label": "M", "shoulder": 48, "chestFlat": 49, "length": 70},
                               {"label": "L", "shoulder": 50, "chestFlat": 56, "length": 74}))
        self.assertEqual(r.closestSizes, ["M"])
        self.assertEqual(r.rankedSizes[0].diffs, {"shoulder": 2.0, "chestFlat": -3.0, "length": 0.0})

    def test_tie(self):
        r = compare(REF, chart({"label": "M", "shoulder": 45, "chestFlat": 52, "length": 70},
                               {"label": "L", "shoulder": 47, "chestFlat": 52, "length": 70}))
        self.assertEqual(r.closestSizes, ["M", "L"])

    def test_mixed_sets_not_ranked(self):
        r = compare(REF, chart({"label": "M", "shoulder": 46, "chestFlat": 52, "length": 70},
                               {"label": "L", "shoulder": 46}))
        self.assertEqual([s.sizeLabel for s in r.unrankedSizes], ["L"])
        self.assertIn("MIXED_ITEM_SETS", r.warnings)

    def test_no_common_items(self):
        r = compare(ReferenceIn(name="t", sleeve=20), chart({"label": "M", "shoulder": 46}))
        self.assertEqual(r.error, "NO_COMPARABLE_ITEMS")

    def test_invalid_values_rejected(self):
        with self.assertRaises(ValidationError):
            chart({"label": "M", "shoulder": 0})
        with self.assertRaises(ValidationError):
            chart({"label": "M", "shoulder": 46}, {"label": "m", "shoulder": 47})
        with self.assertRaises(ValidationError):
            SizeChartCandidate(unit="inch", sizes=[{"label": "M", "shoulder": 46}])


class ModelOutputValidationTest(unittest.TestCase):
    def test_exact_without_name_is_downgraded(self):
        r = validate_model_output({"status": "EXACT_MATCH", "product": {"brand": "B", "name": None}}, "m")
        self.assertEqual(r.status, "CANDIDATE_MATCH")

    def test_invalid_chart_dropped_not_repaired(self):
        r = validate_model_output({
            "status": "EXACT_MATCH", "product": {"brand": "B", "name": "N"},
            "sizeChartCandidates": [{"unit": "inch", "chestMethod": "FLAT", "sizes": [{"label": "M", "shoulder": 18}]}],
        }, "m")
        self.assertEqual(r.sizeChartCandidates, [])
        self.assertEqual(r.failureReason, "SIZE_CHART_UNREADABLE")


if __name__ == "__main__":
    unittest.main()
