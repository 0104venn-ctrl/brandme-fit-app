"""OpenAI Vision call that extracts ONLY what is visible on a shopping-app screenshot.

The model is told never to guess sizes. Its JSON is then validated with Pydantic; anything
invalid is dropped and reported as a failure reason instead of being repaired or invented.
"""
from __future__ import annotations

import base64
import json
import os

from pydantic import ValidationError

from .schemas import AnalyzeScreenResponse, ProductInfo, SizeChartCandidate

SYSTEM_PROMPT = """You read a single screenshot of a Korean shopping app (e.g. Musinsa, Zigzag, Ably).
Return JSON only. Rules:
- Report only text that is actually visible. Never guess, never fill in typical S/M/L values.
- status: EXACT_MATCH only if one product's brand AND name are clearly visible as the main product.
  CANDIDATE_MATCH if one product is likely but brand or name is partly missing.
  AMBIGUOUS if several products are shown (lists, feeds). NOT_FOUND otherwise.
- sizeChartCandidates: only if a garment measurement table (실측 사이즈) is visible.
  Use cm values exactly as printed. Map columns: 어깨->shoulder, 가슴단면/가슴너비->chestFlat,
  가슴둘레->chestCircumference, 총장/기장->length, 소매길이->sleeve. Ignore 소매밑단, 밑단, 암홀, 허리 etc.
  If the table is in inches, or cells are cut off/unreadable, return no chart and
  failureReason "SIZE_CHART_UNREADABLE". If no table is visible, failureReason "SIZE_CHART_NOT_VISIBLE".
- evidence: short quote of the table header you read.
"""

# JSON schema for structured output. Kept permissive on nulls; strict checks happen in Pydantic.
_num = {"type": ["number", "null"]}
RESPONSE_SCHEMA = {
    "name": "screen_analysis",
    "strict": True,
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["status", "product", "candidates", "sizeChartCandidates", "failureReason"],
        "properties": {
            "status": {"type": "string", "enum": ["EXACT_MATCH", "CANDIDATE_MATCH", "AMBIGUOUS", "NOT_FOUND"]},
            "product": {
                "type": ["object", "null"], "additionalProperties": False,
                "required": ["brand", "name", "shop", "productCode"],
                "properties": {k: {"type": ["string", "null"]} for k in ["brand", "name", "shop", "productCode"]},
            },
            "candidates": {
                "type": "array",
                "items": {
                    "type": "object", "additionalProperties": False,
                    "required": ["brand", "name", "shop", "productCode"],
                    "properties": {k: {"type": ["string", "null"]} for k in ["brand", "name", "shop", "productCode"]},
                },
            },
            "sizeChartCandidates": {
                "type": "array",
                "items": {
                    "type": "object", "additionalProperties": False,
                    "required": ["unit", "chestMethod", "sizes", "evidence"],
                    "properties": {
                        "unit": {"type": "string", "enum": ["cm", "inch", "unknown"]},
                        "chestMethod": {"type": "string", "enum": ["FLAT", "CIRCUMFERENCE", "UNKNOWN"]},
                        "evidence": {"type": ["string", "null"]},
                        "sizes": {
                            "type": "array",
                            "items": {
                                "type": "object", "additionalProperties": False,
                                "required": ["label", "shoulder", "chestFlat", "chestCircumference", "length", "sleeve"],
                                "properties": {"label": {"type": "string"}, "shoulder": _num, "chestFlat": _num,
                                               "chestCircumference": _num, "length": _num, "sleeve": _num},
                            },
                        },
                    },
                },
            },
            "failureReason": {"type": ["string", "null"]},
        },
    },
}


class NotConfigured(RuntimeError):
    pass


def validate_model_output(raw: dict, model: str | None) -> AnalyzeScreenResponse:
    """Turns raw model JSON into a validated response. Invalid charts are dropped, not fixed."""
    charts: list[SizeChartCandidate] = []
    failure = raw.get("failureReason")
    for c in raw.get("sizeChartCandidates") or []:
        try:
            charts.append(SizeChartCandidate.model_validate(c))
        except ValidationError:
            failure = "SIZE_CHART_UNREADABLE"
    status = raw.get("status", "NOT_FOUND")
    product = ProductInfo.model_validate(raw["product"]) if raw.get("product") else None
    # A "match" without both brand and name is not a confirmed match.
    if status == "EXACT_MATCH" and (product is None or not product.brand or not product.name):
        status = "CANDIDATE_MATCH" if product else "NOT_FOUND"
    return AnalyzeScreenResponse(
        status=status,
        product=product,
        candidates=[ProductInfo.model_validate(c) for c in raw.get("candidates") or []],
        sizeChartCandidates=charts,
        failureReason=failure if not charts else None,
        model=model,
    )


def analyze_image(image_bytes: bytes, mime: str) -> AnalyzeScreenResponse:
    api_key = os.environ.get("OPENAI_API_KEY")
    model = os.environ.get("OPENAI_MODEL")
    if not api_key or not model:
        raise NotConfigured("OPENAI_API_KEY and OPENAI_MODEL must be set in backend/.env")

    from openai import OpenAI  # imported lazily so /api/compare works without the SDK

    client = OpenAI(api_key=api_key, timeout=float(os.environ.get("OPENAI_TIMEOUT_SECONDS", "25")))
    data_url = f"data:{mime};base64,{base64.b64encode(image_bytes).decode()}"
    completion = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": [
                {"type": "text", "text": "Analyze this screenshot."},
                {"type": "image_url", "image_url": {"url": data_url, "detail": "high"}},
            ]},
        ],
        response_format={"type": "json_schema", "json_schema": RESPONSE_SCHEMA},
    )
    raw = json.loads(completion.choices[0].message.content or "{}")
    return validate_model_output(raw, model)
