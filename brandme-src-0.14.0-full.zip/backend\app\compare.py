"""Server-side copy of FitComparisonEngine v1.0.0 (the Android client also compares on-device).

diff = product - reference; score = mean |diff| over items both sides have; lower is closer.
Sizes compared on a different item set are not ranked against the main group. Ties are joint.
No stretch/fit estimation, no chest circumference <-> flat conversion.
"""
from __future__ import annotations

from .schemas import RANGES, CompareResponse, ReferenceIn, SizeChartCandidate, SizeComparisonOut

ALGORITHM_VERSION = "1.0.0"
REFERENCE_ITEMS = ["shoulder", "chestFlat", "length", "sleeve"]


def _fail(error: str) -> CompareResponse:
    return CompareResponse(algorithmVersion=ALGORITHM_VERSION, closestSizes=[], rankedSizes=[],
                           unrankedSizes=[], comparedItems=[], warnings=[], error=error)


def compare(reference: ReferenceIn, chart: SizeChartCandidate) -> CompareResponse:
    ref_items = [k for k in REFERENCE_ITEMS if getattr(reference, k) is not None]
    if not ref_items:
        return _fail("REFERENCE_INCOMPLETE")
    for k in ref_items:
        lo, hi = RANGES[k]
        if not (lo <= getattr(reference, k) <= hi):
            return _fail("REFERENCE_INCOMPLETE")

    rows = []
    for size in chart.sizes:
        items = [k for k in ref_items if getattr(size, k) is not None]
        diffs = {k: round(getattr(size, k) - getattr(reference, k), 1) for k in items}
        score = sum(abs(v) for v in diffs.values()) / len(items) if items else None
        rows.append(SizeComparisonOut(sizeLabel=size.label, diffs=diffs, comparedItems=items, score=score))

    groups: dict[tuple, list[SizeComparisonOut]] = {}
    for r in rows:
        if r.comparedItems:
            groups.setdefault(tuple(r.comparedItems), []).append(r)
    if not groups:
        return _fail("NO_COMPARABLE_ITEMS")

    primary = max(groups, key=lambda k: (len(k), len(groups[k])))
    ranked = sorted(groups[primary], key=lambda r: r.score)
    unranked = [r for r in rows if tuple(r.comparedItems) != primary]
    best = round(ranked[0].score * 1000)
    closest = [r.sizeLabel for r in ranked if round(r.score * 1000) == best]

    warnings = []
    if len(primary) == 1:
        warnings.append("SINGLE_ITEM")
    if unranked:
        warnings.append("MIXED_ITEM_SETS")
    if "chestFlat" in ref_items and "chestFlat" not in primary and (
            chart.chestMethod == "CIRCUMFERENCE" or any(s.chestCircumference is not None for s in chart.sizes)):
        warnings.append("CHEST_METHOD_MISMATCH")
    warnings.append("UNVERIFIED_DATA")

    return CompareResponse(algorithmVersion=ALGORITHM_VERSION, closestSizes=closest, rankedSizes=ranked,
                           unrankedSizes=unranked, comparedItems=list(primary), warnings=warnings, error=None)
