"""Pydantic models shared by the API. Field names match the Android DTOs
(app/src/main/java/com/brandme/fit/recognition/RemoteAnalyzer.kt)."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

IdentificationStatus = Literal["EXACT_MATCH", "CANDIDATE_MATCH", "AMBIGUOUS", "NOT_FOUND"]
ChestMethod = Literal["FLAT", "CIRCUMFERENCE", "UNKNOWN"]

# Same plausible ranges (cm) as MeasurementRules.kt. Values outside are rejected, never clamped.
RANGES = {
    "shoulder": (20.0, 90.0),
    "chestFlat": (25.0, 100.0),
    "chestCircumference": (50.0, 200.0),
    "length": (30.0, 130.0),
    "sleeve": (5.0, 110.0),
}


class SizeRow(BaseModel):
    label: str = Field(min_length=1, max_length=12)
    shoulder: Optional[float] = None
    chestFlat: Optional[float] = None
    chestCircumference: Optional[float] = None
    length: Optional[float] = None
    sleeve: Optional[float] = None

    @model_validator(mode="after")
    def _check_values(self) -> "SizeRow":
        present = 0
        for key, (lo, hi) in RANGES.items():
            v = getattr(self, key)
            if v is None:
                continue
            present += 1
            if not (lo <= v <= hi):
                raise ValueError(f"{self.label}.{key}={v} outside {lo}-{hi} cm")
        if present == 0:
            raise ValueError(f"{self.label}: no measurements")
        return self


class SizeChartCandidate(BaseModel):
    unit: Literal["cm"] = "cm"
    chestMethod: ChestMethod = "UNKNOWN"
    sizes: list[SizeRow] = Field(min_length=1)
    evidence: Optional[str] = Field(default=None, max_length=300)

    @field_validator("sizes")
    @classmethod
    def _unique_labels(cls, sizes: list[SizeRow]) -> list[SizeRow]:
        labels = [s.label.strip().upper() for s in sizes]
        if len(set(labels)) != len(labels):
            raise ValueError("duplicate size labels")
        return sizes


class ProductInfo(BaseModel):
    brand: Optional[str] = None
    name: Optional[str] = None
    shop: Optional[str] = None
    productCode: Optional[str] = None
    score: Optional[float] = None


class AnalyzeScreenResponse(BaseModel):
    status: IdentificationStatus
    product: Optional[ProductInfo] = None
    candidates: list[ProductInfo] = []
    sizeChartCandidates: list[SizeChartCandidate] = []
    failureReason: Optional[str] = None
    model: Optional[str] = None


class ReferenceIn(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    shoulder: Optional[float] = None
    chestFlat: Optional[float] = None
    length: Optional[float] = None
    sleeve: Optional[float] = None


class CompareRequest(BaseModel):
    reference: ReferenceIn
    chart: SizeChartCandidate


class SizeComparisonOut(BaseModel):
    sizeLabel: str
    diffs: dict[str, float]
    comparedItems: list[str]
    score: Optional[float]


class CompareResponse(BaseModel):
    algorithmVersion: str
    closestSizes: list[str]
    rankedSizes: list[SizeComparisonOut]
    unrankedSizes: list[SizeComparisonOut]
    comparedItems: list[str]
    warnings: list[str]
    error: Optional[str]
