package com.brandme.fit.photo

import com.brandme.fit.data.model.BodyItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 그림으로 만든 사람 윤곽(정면·옆면)으로 추정 계산을 확인한다. 1px = 0.22cm (몸 높이 800px = 키 176cm) */
class BodyPhotoEstimatorTest {

    private class Canvas(val w: Int, val h: Int) {
        val px = BooleanArray(w * h)
        fun rect(x0: Int, y0: Int, x1: Int, y1: Int) { for (y in y0..y1) for (x in x0..x1) px[y * w + x] = true }
        fun ellipse(cx: Int, cy: Int, rx: Int, ry: Int) {
            for (y in cy - ry..cy + ry) for (x in cx - rx..cx + rx) {
                val dx = (x - cx).toDouble() / rx; val dy = (y - cy).toDouble() / ry
                if (dx * dx + dy * dy <= 1) px[y * w + x] = true
            }
        }
        fun mask() = BodyMask(w, h, px)
    }

    private fun front(armsTouching: Boolean = false): PhotoObservation {
        val c = Canvas(500, 1000)
        c.ellipse(250, 150, 45, 50)            // 머리: 맨 위 y=100
        c.rect(230, 195, 270, 235)             // 목
        c.rect(165, 230, 335, 400)             // 가슴 쪽 몸통 171px
        c.rect(175, 401, 325, 460)             // 허리 151px
        c.rect(160, 461, 340, 560)             // 엉덩이 181px
        c.rect(170, 561, 245, 900)             // 다리(맨 아래 y=900)
        c.rect(255, 561, 330, 900)
        if (armsTouching) { c.rect(135, 240, 164, 600); c.rect(336, 240, 365, 600) }
        else { c.rect(110, 240, 140, 600); c.rect(360, 240, 390, 600) }
        return PhotoObservation(
            c.mask(),
            leftShoulder = Pt(160.0, 250.0), rightShoulder = Pt(340.0, 250.0),
            leftHip = Pt(200.0, 500.0), rightHip = Pt(300.0, 500.0),
            leftWrist = Pt(125.0, 600.0), rightWrist = Pt(375.0, 600.0),
        )
    }

    private fun side(): PhotoObservation {
        val c = Canvas(500, 1000)
        c.ellipse(250, 150, 40, 50)
        c.rect(235, 195, 265, 235)
        c.rect(200, 230, 300, 400)              // 가슴 두께 101px
        c.rect(205, 401, 295, 460)              // 허리 91px
        c.rect(195, 461, 305, 560)              // 엉덩이 111px
        c.rect(215, 561, 285, 900)
        return PhotoObservation(
            c.mask(),
            leftShoulder = Pt(250.0, 250.0), rightShoulder = null,
            leftHip = Pt(250.0, 500.0), rightHip = null,
            leftWrist = null, rightWrist = null,
        )
    }

    @Test fun `estimates match the drawn body`() {
        val r = BodyPhotoEstimator.estimate(front(), side(), heightCm = 176.0)
        assertTrue(r.problems.toString(), r.problems.isEmpty())
        val k = 176.0 / 800 // 머리 꼭대기 1px 은 너무 얇아 몸 높이에서 빠질 수 있어 0.2% 오차를 허용한다
        assertEquals(180 * k * BodyPhotoEstimator.SHOULDER_JOINT_TO_TIP, r.values.getValue(BodyItem.SHOULDER).value, r.values.getValue(BodyItem.SHOULDER).value * 0.003)
        val arm = Math.hypot(35.0, 350.0) * k + BodyPhotoEstimator.ARM_TIP_OFFSET_CM
        assertEquals(arm, r.values.getValue(BodyItem.ARM).value, r.values.getValue(BodyItem.ARM).value * 0.003)
        val chest = BodyPhotoEstimator.ellipseCircumference(171 * k, 101 * k)
        assertEquals(chest, r.values.getValue(BodyItem.CHEST).value, r.values.getValue(BodyItem.CHEST).value * 0.003)
        val waist = BodyPhotoEstimator.ellipseCircumference(151 * k, 91 * k)
        assertEquals(waist, r.values.getValue(BodyItem.WAIST).value, r.values.getValue(BodyItem.WAIST).value * 0.003)
        // 어깨 바깥너비: 삼각근 높이(어깨 관절 y=250 에서 아래로)의 윤곽 폭. 그림의 어깨 높이 몸통 171px + 양팔 붙은 부분 없음 → 몸통 폭
        assertTrue(BodyItem.SHOULDER_OUTER !in r.values || r.values.getValue(BodyItem.SHOULDER_OUTER).value >= r.values.getValue(BodyItem.SHOULDER).value / BodyPhotoEstimator.SHOULDER_JOINT_TO_TIP)
        val hip = BodyPhotoEstimator.ellipseCircumference(181 * k, 111 * k)
        assertEquals(hip, r.values.getValue(BodyItem.HIP).value, r.values.getValue(BodyItem.HIP).value * 0.003)
    }

    /** 0.9.0 실기기: 어깨 32cm·팔 46cm 처럼 모든 값이 작게 나온 경우 — 배경의 잘못 잡힌 점이 몸 높이에 섞이면 이렇게 된다 */
    @Test fun `background blobs do not change the body height`() {
        val f = front()
        val noisy = Canvas(500, 1000)
        for (y in 0 until 1000) for (x in 0 until 500) if (f.mask[x, y]) noisy.px[y * 500 + x] = true
        noisy.rect(10, 5, 60, 40)      // 화면 맨 위 구석의 다른 물체
        noisy.rect(420, 950, 480, 990) // 바닥의 그림자
        val r = BodyPhotoEstimator.estimate(f.copy(mask = noisy.mask()), side(), heightCm = 176.0)
        val clean = BodyPhotoEstimator.estimate(f, side(), heightCm = 176.0)
        assertEquals(clean.values.getValue(BodyItem.SHOULDER).value, r.values.getValue(BodyItem.SHOULDER).value, 1e-9)
    }

    @Test fun `landmarks correct a body outline that includes extra floor`() {
        val f = front()
        val c = Canvas(500, 1000)
        for (y in 0 until 1000) for (x in 0 until 500) if (f.mask[x, y]) c.px[y * 500 + x] = true
        c.rect(150, 900, 350, 990)     // 발 아래로 이어진 그림자(몸 덩어리에 붙음)
        val withLm = f.copy(mask = c.mask(), nose = Pt(250.0, 160.0), leftHeel = Pt(205.0, 895.0), rightHeel = Pt(295.0, 895.0))
        val r = BodyPhotoEstimator.estimate(withLm, side(), heightCm = 176.0)
        val diag = r.diagnostics.first()
        assertTrue("bottom ${diag.bottom}", diag.bottom!! in 890..915)
    }

    @Test fun `arms touching the torso are cut out and reported`() {
        val r = BodyPhotoEstimator.estimate(front(armsTouching = true), side(), heightCm = 176.0)
        // 팔 자리를 잘라내고 재므로 손·팔 폭이 엉덩이·가슴에 섞이지 않는다(0.10.0 실기기: 엉덩이 127cm)
        val clean = BodyPhotoEstimator.estimate(front(), side(), heightCm = 176.0)
        val hip = r.values.getValue(BodyItem.HIP)
        assertEquals(clean.values.getValue(BodyItem.HIP).value, hip.value, clean.values.getValue(BodyItem.HIP).value * 0.12)
        assertEquals(7.0, hip.plusMinus, 1e-9)                   // 잘라낸 경우 오차 범위를 넓게
        assertTrue(r.problems.any { "팔" in it })
        assertTrue(BodyItem.SHOULDER in r.values) // 관절로 재는 항목은 그대로
    }

    @Test fun `cut off body is reported`() {
        val c = Canvas(500, 1000).apply { rect(150, 0, 350, 999) }
        val cut = PhotoObservation(c.mask(), Pt(160.0, 250.0), Pt(340.0, 250.0), Pt(200.0, 500.0), Pt(300.0, 500.0), null, null)
        val r = BodyPhotoEstimator.estimate(cut, side(), heightCm = 176.0)
        assertTrue(r.problems.any { "잘렸" in it })
    }

    @Test fun `ellipse circumference of a circle`() {
        assertEquals(Math.PI * 30, BodyPhotoEstimator.ellipseCircumference(30.0, 30.0), 1e-9)
    }

    @Test fun `guide outlines are closed shapes inside the frame`() {
        for (pose in PhotoPose.entries) {
            val pts = PoseGuide.points(pose)
            assertTrue(pts.all { (x, y) -> x in 0.0..1.0 && y in 0.0..1.0 })
            assertEquals(0.0, pts.minOf { it.second }, 1e-9)   // 머리 위
            assertEquals(1.0, pts.maxOf { it.second }, 1e-9)   // 발 아래
            assertEquals(pts.size, PoseGuide.bezierSegments(pts).size)
        }
        // 정면은 좌우 대칭이고, 오른발 아래 다음 점이 왼발 아래(선이 몸 가운데를 가로지르지 않음)
        val f = PoseGuide.FRONT
        val i = f.indexOf(0.530 to 1.000)
        assertEquals(0.470 to 1.000, f[i + 1])
        f.zipWithNext().forEach { (a, b) -> assertTrue("$a -> $b", Math.hypot(a.first - b.first, a.second - b.second) < 0.13) }
        val xs = f.map { it.first }
        assertEquals(1.0, xs.min() + xs.max(), 1e-9)
    }
}
