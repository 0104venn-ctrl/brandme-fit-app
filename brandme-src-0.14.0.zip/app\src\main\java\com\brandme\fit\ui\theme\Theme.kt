package com.brandme.fit.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BrandPurple = Color(0xFF4C3BCF)
val DemoAmber = Color(0xFFB26A00)
val WarnRed = Color(0xFFB3261E)
val OkGreen = Color(0xFF1E7D45)

private val Light = lightColorScheme(
    primary = BrandPurple,
    onPrimary = Color.White,
    secondary = Color(0xFF5E5A71),
    tertiary = DemoAmber,
)

private val Dark = darkColorScheme(
    primary = Color(0xFFC5BFFF),
    onPrimary = Color(0xFF1F1278),
    secondary = Color(0xFFC8C3DC),
    tertiary = Color(0xFFFFB95C),
)

@Composable
fun BrandmeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
