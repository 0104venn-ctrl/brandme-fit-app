package com.brandme.fit.body3d

import com.brandme.fit.data.model.BodyShapeBase
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * 사람 형태 3D 모형. MakeHuman(CC0) 기본 인체 메시와 체형 타깃을 PC 에서 가공한 자산
 * (assets/body/body_model.bin, body_model.json — tools/makehuman/mh_process.py)으로 만든다.
 *
 * 입력한 치수(가슴·허리·엉덩이 둘레, 어깨너비, 팔길이)에 맞도록 체형 타깃 비중을 정하고, 키에 맞게 크기를 바꾼다.
 * 모형은 보여 주기 위한 근사이며, 사이즈 비교에는 입력한 숫자만 쓴다.
 */
class HumanBodyModel private constructor(
    private val vertexCount: Int,
    private val indices: IntArray,
    private val bases: Map<BodyShapeBase, FloatArray>,
    /** 이름 → 정점 변위(cm) */
    private val deltas: Map<String, FloatArray>,
    private val meta: Meta,
    private val neighbors: Array<IntArray>,
) {
    @Serializable
    data class Signed(val pos: List<Double>, val neg: List<Double>)

    @Serializable
    data class GenderMeta(val base: Map<String, Double>, val jacobian: Map<String, Signed>)

    @Serializable
    data class Meta(
        val vars: List<String>,
        val measurements: List<String>,
        val genders: Map<String, GenderMeta>,
        val anchors: Map<String, Int>,
        val anchorsMirror: Map<String, Int>,
        val smooth: List<Int>,
        val deltas: List<String>,
        val deltaScale: Double,
        /** 정점별 몸 부위: 0 머리, 1 목, 2 몸통, 3/4 왼/오른 위팔, 5/6 아래팔, 7/8 손, 9 다리 */
        val parts: List<Int> = emptyList(),
        /** 팔 정점의 위치: 어깨 관절 0 ~ 손목 1 (팔이 아니면 0) */
        val armT: List<Double> = emptyList(),
    )

    /** 만들어진 모형: 메시와 치수 표시선 기준점(좌우) */
    class Result(
        val mesh: Mesh,
        val anchors: Map<String, Pair<FloatArray, FloatArray>>,
        val weights: Map<String, Double>,
        /** 옷 입히기용 정점 정보 */
        val parts: IntArray,
        val armT: FloatArray,
    )

    private val partsArray: IntArray by lazy { meta.parts.toIntArray() }
    private val armTArray: FloatArray by lazy { FloatArray(meta.armT.size) { meta.armT[it].toFloat() } }

    private fun gKey(s: BodyShapeBase) = if (s == BodyShapeBase.MALE) "male" else "female"

    /**
     * 치수에 맞는 타깃 비중(-1..1)을 찾는다. 측정값 변화는 PC 에서 미리 잰 선형 근사(부호별)로 계산한다.
     * 어깨·팔은 관절 사이 거리로 쟀으므로, 기본 체형이 평균 비율(키 × 0.245/0.225, × 0.33)과 같다고 보고 환산한다.
     */
    fun solveWeights(d: MannequinDims): Map<String, Double> {
        val g = meta.genders.getValue(gKey(d.shape))
        val h0 = g.base.getValue("height")
        val s = d.height / h0
        val male = d.shape == BodyShapeBase.MALE
        val kShoulder = (h0 * (if (male) 0.245 else 0.225)) / g.base.getValue("shoulder")
        val kArm = (h0 * 0.33) / g.base.getValue("arm")
        val target = mapOf(
            "chest" to d.chest / s,
            "waist" to d.waist / s,
            "hip" to d.hip / s,
            "shoulder" to d.shoulder / s / kShoulder,
            "arm" to d.arm / s / kArm,
        )
        val meas = meta.measurements
        val resid0 = DoubleArray(meas.size) { i -> target.getValue(meas[i]) - g.base.getValue(meas[i]) }
        val w = DoubleArray(meta.vars.size)
        fun col(j: Int, sign: Double) = meta.genders.getValue(gKey(d.shape)).jacobian.getValue(meta.vars[j]).let { if (sign >= 0) it.pos else it.neg }
        // 좌표 하강: 다른 변수를 고정하고 한 변수씩 최적화(부호에 따라 다른 기울기 사용), 작은 비중을 선호(릿지)
        val lambda = 0.5
        repeat(60) {
            for (j in w.indices) {
                val r = DoubleArray(meas.size) { i ->
                    var v = resid0[i]
                    for (k in w.indices) if (k != j) v -= col(k, w[k])[i] * w[k] * (if (w[k] >= 0) 1.0 else -1.0)
                    v
                }
                var best = w[j]; var bestCost = Double.MAX_VALUE
                for (sign in listOf(1.0, -1.0)) {
                    val c = col(j, sign)
                    // 음수 쪽 기울기는 "decr 타깃을 |w| 만큼" 적용했을 때의 변화량이므로 부호를 맞춘다
                    val a = DoubleArray(meas.size) { i -> c[i] * sign }
                    val num = a.indices.sumOf { a[it] * r[it] }
                    val den = a.indices.sumOf { a[it] * a[it] } + lambda
                    val x = (num / den).coerceIn(if (sign > 0) 0.0 else -1.0, if (sign > 0) 1.0 else 0.0)
                    val cost = a.indices.sumOf { (r[it] - a[it] * x).let { e -> e * e } } + lambda * x * x
                    if (cost < bestCost) { bestCost = cost; best = x }
                }
                w[j] = best
            }
        }
        return meta.vars.indices.associate { meta.vars[it] to w[it] }
    }

    fun build(d: MannequinDims): Result {
        val weights = solveWeights(d)
        val g = gKey(d.shape)
        val p = bases.getValue(d.shape).copyOf()
        fun addDelta(name: String, amount: Double) {
            if (abs(amount) < 1e-6) return
            val dl = deltas.getValue(name)
            val a = amount.toFloat()
            for (i in p.indices) p[i] += dl[i] * a
        }
        for ((v, w) in weights) {
            val sign = if (w >= 0) "pos" else "neg"
            val amt = abs(w)
            when (v) {
                "weight" -> addDelta("$g-weight-$sign", amt)
                "arm" -> { addDelta("upperarm-$sign", amt); addDelta("lowerarm-$sign", amt) }
                else -> addDelta("$v-$sign", amt)
            }
        }
        smooth(p)
        // 키에 맞게 크기 조절, 바닥(y=0)·가운데 정렬
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE; var cx = 0.0; var cz = 0.0
        for (i in 0 until vertexCount) {
            val y = p[i * 3 + 1]; if (y < minY) minY = y; if (y > maxY) maxY = y
            cx += p[i * 3]; cz += p[i * 3 + 2]
        }
        cx /= vertexCount; cz /= vertexCount
        val scale = (d.height / (maxY - minY)).toFloat()
        for (i in 0 until vertexCount) {
            p[i * 3] = ((p[i * 3] - cx) * scale).toFloat()
            p[i * 3 + 1] = (p[i * 3 + 1] - minY) * scale
            p[i * 3 + 2] = ((p[i * 3 + 2] - cz) * scale).toFloat()
        }
        val anchors = meta.anchors.mapValues { (k, v) ->
            val m = meta.anchorsMirror.getValue(k)
            floatArrayOf(p[v * 3], p[v * 3 + 1], p[v * 3 + 2]) to floatArrayOf(p[m * 3], p[m * 3 + 1], p[m * 3 + 2])
        }
        return Result(Mesh(p, normals(p), indices), anchors, weights, partsArray, armTArray)
    }

    /** 하얀 모형에서 가슴 끝 돌출부를 부드럽게(라플라시안 평활화, 해당 영역만) */
    private fun smooth(p: FloatArray) {
        repeat(6) {
            val next = HashMap<Int, FloatArray>()
            for (i in meta.smooth) {
                val nb = neighbors[i]
                if (nb.isEmpty()) continue
                val avg = FloatArray(3)
                for (n in nb) for (k in 0..2) avg[k] += p[n * 3 + k]
                next[i] = FloatArray(3) { k -> p[i * 3 + k] * 0.4f + avg[k] / nb.size * 0.6f }
            }
            for ((i, v) in next) for (k in 0..2) p[i * 3 + k] = v[k]
        }
    }

    private fun normals(p: FloatArray): FloatArray {
        val n = FloatArray(p.size)
        for (t in indices.indices step 3) {
            val a = indices[t] * 3; val b = indices[t + 1] * 3; val c = indices[t + 2] * 3
            val ux = p[b] - p[a]; val uy = p[b + 1] - p[a + 1]; val uz = p[b + 2] - p[a + 2]
            val vx = p[c] - p[a]; val vy = p[c + 1] - p[a + 1]; val vz = p[c + 2] - p[a + 2]
            val fx = uy * vz - uz * vy; val fy = uz * vx - ux * vz; val fz = ux * vy - uy * vx
            for (k in intArrayOf(a, b, c)) { n[k] += fx; n[k + 1] += fy; n[k + 2] += fz }
        }
        for (i in 0 until p.size / 3) {
            val l = sqrt(n[i * 3] * n[i * 3] + n[i * 3 + 1] * n[i * 3 + 1] + n[i * 3 + 2] * n[i * 3 + 2]).coerceAtLeast(1e-9f)
            n[i * 3] /= l; n[i * 3 + 1] /= l; n[i * 3 + 2] /= l
        }
        return n
    }

    companion object {
        private val JSON = Json { ignoreUnknownKeys = true }

        fun load(bin: ByteArray, json: String): HumanBodyModel {
            val meta = JSON.decodeFromString(Meta.serializer(), json)
            val buf = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
            val magic = ByteArray(4).also { buf.get(it) }
            require(String(magic) == "BMHM") { "not a body model" }
            require(buf.int == 1) { "unsupported version" }
            val v = buf.int; val t = buf.int; val k = buf.int
            val scale = buf.float
            fun floats(n: Int) = FloatArray(n) { buf.float }
            val male = floats(v * 3)
            val female = floats(v * 3)
            val idx = IntArray(t * 3) { buf.short.toInt() and 0xFFFF }
            val deltas = LinkedHashMap<String, FloatArray>()
            for (j in 0 until k) deltas[meta.deltas[j]] = FloatArray(v * 3) { buf.short / scale }
            val nb = Array(v) { HashSet<Int>() }
            for (i in idx.indices step 3) {
                val a = idx[i]; val b = idx[i + 1]; val c = idx[i + 2]
                nb[a] += b; nb[a] += c; nb[b] += a; nb[b] += c; nb[c] += a; nb[c] += b
            }
            return HumanBodyModel(
                v, idx, mapOf(BodyShapeBase.MALE to male, BodyShapeBase.FEMALE to female), deltas, meta,
                Array(v) { nb[it].toIntArray() },
            )
        }
    }
}
