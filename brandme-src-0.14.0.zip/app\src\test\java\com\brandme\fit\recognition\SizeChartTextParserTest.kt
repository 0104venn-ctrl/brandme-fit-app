package com.brandme.fit.recognition

import com.brandme.fit.data.model.ChestMeasureMethod
import com.brandme.fit.data.model.MeasureItem
import com.brandme.fit.data.model.VerificationStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SizeChartTextParserTest {

    @Test fun `parses tab separated table`() {
        val r = SizeChartTextParser.parse(listOf(
            "실측 사이즈 (cm)",
            "사이즈\t총장\t어깨너비\t가슴단면\t소매길이",
            "S\t68\t44\t50\t20",
            "M\t70\t46\t52.5\t21",
            "L\t72\t48\t55\t22",
            "상품 정보 고시",
        ))
        val chart = (r as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("S", "M", "L"), chart.sizes.map { it.label })
        val m = chart.sizes[1].measurements
        assertEquals(46.0, m.shoulderCm!!, 1e-9)
        assertEquals(52.5, m.chestFlatCm!!, 1e-9)
        assertEquals(70.0, m.lengthCm!!, 1e-9)
        assertEquals(21.0, m.sleeveCm!!, 1e-9)
        assertEquals(VerificationStatus.UNVERIFIED, chart.verification) // 화면에서 읽은 값은 미검증
        assertEquals(ChestMeasureMethod.FLAT, chart.chestMethod)
    }

    @Test fun `parses space separated header with split words`() {
        val r = SizeChartTextParser.parse(listOf("사이즈 어깨 너비 가슴 단면 총장", "M 46 52 70", "L 48 55 72"))
        val chart = (r as SizeChartTextParser.Result.Found).chart
        assertEquals(52.0, chart.sizes[0].measurements.chestFlatCm!!, 1e-9)
    }

    @Test fun `skips hem and other non compared columns`() {
        val r = SizeChartTextParser.parse(listOf(
            "사이즈\t어깨\t가슴단면\t소매밑단\t총장\t허리단면",
            "M\t46\t52\t12\t70\t48",
        ))
        val m = (r as SizeChartTextParser.Result.Found).chart.sizes.single().measurements
        assertEquals(46.0, m.shoulderCm!!, 1e-9)
        assertEquals(70.0, m.lengthCm!!, 1e-9)
        assertNull(m.sleeveCm) // 소매밑단은 소매 길이가 아니다
        assertEquals(listOf(MeasureItem.SHOULDER, MeasureItem.CHEST_FLAT, MeasureItem.LENGTH),
            SizeChartTextParser.recognizedItems("어깨\t가슴단면\t소매 밑단\t총장"))
    }

    @Test fun `chest circumference kept separate`() {
        val r = SizeChartTextParser.parse(listOf("사이즈 어깨 가슴 둘레 총장", "M 46 104 70"))
        val chart = (r as SizeChartTextParser.Result.Found).chart
        assertNull(chart.sizes.single().measurements.chestFlatCm)
        assertEquals(104.0, chart.sizes.single().measurements.chestCircumferenceCm!!, 1e-9)
        assertEquals(ChestMeasureMethod.CIRCUMFERENCE, chart.chestMethod)
    }

    @Test fun `no table returns not found`() {
        assertEquals(SizeChartTextParser.Result.NotFound,
            SizeChartTextParser.parse(listOf("무료배송", "베이직 반팔 티셔츠", "29,000원", "M 사이즈 추천")))
    }

    @Test fun `misaligned rows are unreadable not guessed`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\t어깨\t가슴단면\t총장", "M\t46\t52", "L\t48\t55\t72"))
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    /** 사전에 없는 항목명은 그 칸만 빼고(위치대로 건너뜀) 결과에 알린다 */
    @Test fun `unknown columns are skipped and reported`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\t어깨\t가슴단면\t??\t총장", "M\t46\t52\t9\t70"))
        val chart = (r as SizeChartTextParser.Result.Found).chart
        assertEquals(70.0, chart.sizes.single().measurements.lengthCm!!, 1e-9)
        assertEquals(listOf("??"), chart.skippedItems)
    }

    @Test fun `known non-compared columns are still skipped`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\t어깨\t가슴단면\t암홀\t총장", "M\t46\t52\t24\t70"))
        val m = (r as SizeChartTextParser.Result.Found).chart.sizes.single().measurements
        assertEquals(70.0, m.lengthCm!!, 1e-9)
    }

    /** 0.2.4 실기기 결과: 헤더 오타로 어깨·총길이가 무시되고, XL 라벨을 못 읽어 M·L 가슴만 결과로 나온 경우 */
    @Test fun `real ocr with header typos and lost label row`() {
        assertEquals(
            listOf(MeasureItem.SHOULDER, MeasureItem.CHEST_FLAT, MeasureItem.SLEEVE, MeasureItem.LENGTH),
            SizeChartTextParser.recognizedItems("사이즈\t1.어개\t2가슴\t3소매\t7.층걸이"),
        )
        val r = SizeChartTextParser.parse(listOf(
            "사이즈|1.어개|2가슴|3소매|7.층걸이",
            "M1번|58|60|55|68",
            "L2번)|61|63|56|69",
            "3번|64",
            "위으 슬즉시 프는 단연의 글 입-다 장고좌 주세요",
        ))
        assertTrue(r is SizeChartTextParser.Result.Unreadable)

        val full = SizeChartTextParser.parse(listOf(
            "사이즈|1.어개|2가슴|3소매|7.층걸이",
            "M1번|58|60|55|68",
            "L2번)|61|63|56|69",
            "XL3번)|64|66|57|70",
            "위으 슬즉시 프는 단연의 글 입-다 장고좌 주세요",
        ))
        val chart = (full as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("M", "L", "XL"), chart.sizes.map { it.label })
        assertEquals(58.0, chart.sizes[0].measurements.shoulderCm!!, 1e-9)
        assertEquals(70.0, chart.sizes[2].measurements.lengthCm!!, 1e-9)
    }

    @Test fun `fuzzy header does not turn unrelated words into measurements`() {
        assertEquals(SizeChartTextParser.Column.IGNORE, SizeChartTextParser.classifyHeader("모델")) // 착용 정보
        assertNull(SizeChartTextParser.classifyHeader("배송"))
        assertNull(SizeChartTextParser.classifyHeader("색상"))
    }

    @Test fun `unknown column with missing value is still unreadable`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\t어깨\t가슴단면\t??\t총장", "M\t46\t52\t70"))
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    @Test fun `parses vertical table with sizes as columns`() {
        val r = SizeChartTextParser.parse(listOf(
            "사이즈 정보",
            "cm\tS\tM\tL",
            "어깨너비\t44\t46\t48",
            "가슴 단면\t50\t52\t55",
            "소매 밑단\t12\t13\t14",
            "총장\t68\t70\t72",
            "모델 정보 175cm",
        ))
        val chart = (r as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("S", "M", "L"), chart.sizes.map { it.label })
        val l = chart.sizes[2].measurements
        assertEquals(48.0, l.shoulderCm!!, 1e-9)
        assertEquals(55.0, l.chestFlatCm!!, 1e-9)
        assertEquals(72.0, l.lengthCm!!, 1e-9)
        assertNull(l.sleeveCm)
        assertEquals(VerificationStatus.UNVERIFIED, chart.verification)
    }

    @Test fun `vertical table with misaligned values is unreadable`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\tS\tM\tL", "어깨\t44\t46", "총장\t68\t70\t72"))
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    @Test fun `numeric value rows are not taken as size header`() {
        assertEquals(SizeChartTextParser.Result.NotFound, SizeChartTextParser.parse(listOf("44 46 48", "어깨 1 2 3")))
    }

    @Test fun `parses inline size lines`() {
        val r = SizeChartTextParser.parse(listOf(
            "[실측 사이즈]",
            "M : 어깨너비 46 / 가슴단면 52 / 총장 70cm",
            "L : 어깨너비 48 / 가슴단면 55 / 총장 72cm",
        ))
        val chart = (r as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("M", "L"), chart.sizes.map { it.label })
        assertEquals(55.0, chart.sizes[1].measurements.chestFlatCm!!, 1e-9)
        assertEquals(72.0, chart.sizes[1].measurements.lengthCm!!, 1e-9)
    }

    @Test fun `free size label and dash cells`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\t어깨\t가슴단면\t소매\t총장", "FREE SIZE\t50\t60\t-\t70"))
        val s = (r as SizeChartTextParser.Result.Found).chart.sizes.single()
        assertEquals("FREESIZE", s.label)
        assertNull(s.measurements.sleeveCm)
        assertEquals(70.0, s.measurements.lengthCm!!, 1e-9)
    }

    @Test fun `false header line does not block a later table`() {
        val r = SizeChartTextParser.parse(listOf(
            "어깨 가슴 총장 기준으로 측정했어요",
            "상세 설명",
            "사이즈\t어깨\t가슴단면\t총장",
            "M\t46\t52\t70",
        ))
        assertTrue(r is SizeChartTextParser.Result.Found)
    }

    /** 실기기 캡처(쿠팡 상세정보 이미지 표)에서 OCR 이 실제로 돌려준 행 */
    @Test fun `parses real coupang ocr rows`() {
        val r = SizeChartTextParser.parse(listOf(
            "여유 있는 밑단 디자인",
            "신축성이 좋아 편안하게 착용할 수 있으며, 내구성이 뛰어나 오래",
            "사이즈 표\t어깨\t\t가슴 단면 팔기장\t총기장\t체중 (kg)",
            "XL (95)\t46\t53\t74.8\t68\t65-75",
            "2XL (100)\t47.5\t55\t76. 6\t70\t75-82",
            "3XL (105)\t49\t57\t78.4\t72\t82-90",
            "4XL (110)\t50. 5\t59\t80.2\t74\t90-100",
            "*측정방법에 따라 1`3cm오차가 있을 수 있습니다!",
            "THEGANDG는 대한민국 특허청 등록상표입니다.",
        ))
        val chart = (r as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("XL(95)", "2XL(100)", "3XL(105)", "4XL(110)"), chart.sizes.map { it.label })
        val xxl = chart.sizes[1].measurements
        assertEquals(47.5, xxl.shoulderCm!!, 1e-9)
        assertEquals(55.0, xxl.chestFlatCm!!, 1e-9)
        assertEquals(76.6, xxl.sleeveCm!!, 1e-9)
        assertEquals(70.0, xxl.lengthCm!!, 1e-9)
        assertEquals(50.5, chart.sizes[3].measurements.shoulderCm!!, 1e-9)
        assertEquals(ChestMeasureMethod.FLAT, chart.chestMethod)
    }

    /** 두 번째 실기기 캡처: 번호 붙은 헤더, "총길이", "M(1번)" 라벨 */
    @Test fun `numbered headers and option-number labels`() {
        assertEquals(
            listOf(MeasureItem.SHOULDER, MeasureItem.CHEST_FLAT, MeasureItem.SLEEVE, MeasureItem.LENGTH),
            SizeChartTextParser.recognizedItems("사이즈\t1.어깨\t2가슴\t3소매\t7.총길이"),
        )
        val r = SizeChartTextParser.parse(listOf(
            "단위 cm",
            "사이즈\t1.어깨\t2.가슴\t3.소매\t7.총길이",
            "M(1번)\t59\t60\t55\t68",
            "L(2번)\t61\t63\t56\t69",
            "XL(3번)\t64\t66\t57\t70",
        ))
        val chart = (r as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("M", "L", "XL"), chart.sizes.map { it.label })
        assertEquals(66.0, chart.sizes[2].measurements.chestFlatCm!!, 1e-9)
    }

    /** 표가 너무 작아 OCR 이 값을 놓친 행은 추측하지 않고 읽지 못함으로 끝난다 */
    @Test fun `garbled small table stays unreadable`() {
        val r = SizeChartTextParser.parse(listOf(
            "사이즈\t1.어깨\t2가슴\t3소매\t7.총길이", "M1번)", "L2번\t61\t63", "X3번)\t6\t66\t57\t70",
        ))
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    @Test fun `table region is found below header and enlarged`() {
        val screen = ScreenText(listOf(
            TextLine("상세정보", 100, 100, 300, 140),
            TextLine("사이즈", 120, 1000, 160, 1012),
            TextLine("1.어깨", 300, 1000, 340, 1012),
            TextLine("2가슴", 500, 1000, 540, 1012),
            TextLine("7.총길이", 800, 1000, 860, 1012),
        ))
        val region = TableRegion.find(screen, 1080, 2340)!!
        assertTrue(region.top in 970..1000)
        assertTrue(region.bottom in 1250..1400)
        assertTrue(region.left < 120 && region.right > 860)
        assertTrue(region.scale > 2f)
        assertNull(TableRegion.find(ScreenText(listOf(TextLine("무료배송", 0, 0, 100, 40))), 1080, 2340))
    }

    @Test fun `row with values but unreadable label rejects the table`() {
        val r = SizeChartTextParser.parse(listOf(
            "사이즈\t어깨\t가슴단면\t총장", "M\t46\t52\t70", "L\t48\t55\t72", "3번)\t50\t58\t74",
        ))
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    @Test fun `rows with several empty cells are unreadable`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\t어깨\t가슴단면\t소매\t총장", "M\t-\t60\t-\t-", "L\t-\t63\t-\t-"))
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    /** 0.2.3 실기기 결과: 가슴만 읽히고 나머지 칸이 비었는데 M·L 결과가 나왔던 경우(세로형/빈칸 경로 공통 차단) */
    @Test fun `chart with whole empty columns is unreadable`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\tM\tL", "2가슴\t60\t63", "가슴\t60\t63", "소매\t-\t-"))
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    /** 원본 사이트 표(사용자 제공): 사이즈 / 1.어깨 / 2가슴 / 3소매 / 7.총길이 */
    @Test fun `original site table values`() {
        val r = SizeChartTextParser.parse(listOf(
            "단위(cm)",
            "사이즈\t1.어깨\t2가슴\t3.소매\t7.총길이",
            "M(1번)\t58\t60\t55\t68",
            "L(2번)\t61\t63\t56\t69",
            "XL(3번)\t64\t66\t57\t70",
        ))
        val chart = (r as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("M", "L", "XL"), chart.sizes.map { it.label })
        assertEquals(58.0, chart.sizes[0].measurements.shoulderCm!!, 1e-9)
        assertEquals(70.0, chart.sizes[2].measurements.lengthCm!!, 1e-9)
    }

    @Test fun `size labels with parentheses`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\t어깨\t가슴단면\t총장", "M(95)\t46\t52\t70", "L(100)\t48\t55\t72"))
        assertEquals(listOf("M(95)", "L(100)"), (r as SizeChartTextParser.Result.Found).chart.sizes.map { it.label })
    }

    @Test fun `inch tables are rejected`() {
        val r = SizeChartTextParser.parse(listOf("size\tshoulder (inch)\tchest (inch)\tlength (inch)", "M\t18\t21\t28"))
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    @Test fun `duplicate size with different values is conflicting`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\t어깨\t가슴단면\t총장", "M\t46\t52\t70", "M\t47\t53\t71"))
        assertEquals(SizeChartTextParser.Result.Conflicting("M"), r)
    }

    @Test fun `abnormal values are unreadable`() {
        val r = SizeChartTextParser.parse(listOf("사이즈\t어깨\t가슴단면\t총장", "M\t0\t52\t70"))
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }
}
