package com.brandme.fit.body3d

import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.BodyShapeBase
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** 그리기용 삼각형 메시(단위 cm, y 위쪽, 바닥 중앙이 원점, 정면이 +z) */
class Mesh(val positions: FloatArray, val normals: FloatArray, val indices: IntArray) {
    val vertexCount: Int get() = positions.size / 3

    fun bounds(): Pair<FloatArray, FloatArray> {
        val min = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE)
        val max = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        for (i in 0 until vertexCount) for (k in 0..2) {
            val v = positions[i * 3 + k]
            if (v < min[k]) min[k] = v
            if (v > max[k]) max[k] = v
        }
        return min to max
    }
}

/**
 * 3D 모형에 쓰는 치수. 입력한 값은 그대로, 입력하지 않은 부위는 체형별 평균 비율(키 대비)로 채운다.
 * 이 값은 모형을 그리는 데만 쓰고 사이즈 비교에는 쓰지 않는다(비교는 입력한 값만).
 */
data class MannequinDims(
    val height: Double,
    val shoulder: Double,
    val chest: Double,
    val waist: Double,
    val hip: Double,
    val arm: Double,
    val shape: BodyShapeBase,
    /** 입력하지 않아 평균 비율로 채운 항목 이름 */
    val estimated: List<String>,
) {
    companion object {
        fun from(p: BodyProfile): MannequinDims {
            val h = p.heightCm
            val male = p.shapeBase == BodyShapeBase.MALE
            // 몸무게가 있으면 둘레 기본값을 BMI 로 조금 조정한다(모형 모양용)
            val bmiScale = p.weightKg?.let { w -> sqrt((w / ((h / 100) * (h / 100))) / 22.0).coerceIn(0.8, 1.4) } ?: 1.0
            val est = mutableListOf<String>()
            fun pick(v: Double?, default: Double, name: String) = v ?: default.also { est += name }
            return MannequinDims(
                height = h,
                shoulder = pick(p.shoulderCm, h * if (male) 0.245 else 0.225, "어깨너비"),
                chest = pick(p.chestCm, h * (if (male) 0.53 else 0.52) * bmiScale, "가슴둘레"),
                waist = pick(p.waistCm, h * (if (male) 0.45 else 0.42) * bmiScale, "허리둘레"),
                hip = pick(p.hipCm, h * (if (male) 0.535 else 0.565) * bmiScale, "엉덩이둘레"),
                arm = pick(p.armCm, h * 0.33, "팔길이"),
                shape = p.shapeBase,
                estimated = est,
            )
        }
    }
}

/**
 * 치수로 매끈한 마네킹 형태를 만든다. 실제 몸을 스캔한 형태가 아니라
 * 몸통 단면(타원)을 키 방향으로 이어 붙이고 팔·다리·머리를 더한 "치수 기반 모형"이다.
 */
object MannequinMesh {

    private const val AROUND = 48

    private class V(val x: Double, val y: Double, val z: Double) {
        operator fun plus(o: V) = V(x + o.x, y + o.y, z + o.z)
        operator fun minus(o: V) = V(x - o.x, y - o.y, z - o.z)
        operator fun times(s: Double) = V(x * s, y * s, z * s)
        fun cross(o: V) = V(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
        fun len() = sqrt(x * x + y * y + z * z)
        fun norm() = len().let { if (it < 1e-9) this else this * (1 / it) }
    }

    private class Builder {
        val pos = ArrayList<Double>()
        val idx = ArrayList<Int>()
        private var partStart = 0
        private val parts = ArrayList<IntRange>()

        fun add(v: V): Int { pos += v.x; pos += v.y; pos += v.z; return pos.size / 3 - 1 }
        fun tri(a: Int, b: Int, c: Int) { idx += a; idx += b; idx += c }
        fun endPart() { parts += partStart until pos.size / 3; partStart = pos.size / 3 }

        /** 같은 점 개수의 닫힌 고리들을 순서대로 이어 관을 만든다. 양 끝은 중심점으로 막는다. */
        fun tube(rings: List<List<V>>, capStart: Boolean, capEnd: Boolean, outwardAtStart: V, outwardAtEnd: V) {
            val n = rings.first().size
            val base = rings.map { r -> r.map { add(it) } }
            for (i in 0 until rings.size - 1) for (j in 0 until n) {
                val a = base[i][j]; val b = base[i][(j + 1) % n]
                val c = base[i + 1][j]; val d = base[i + 1][(j + 1) % n]
                tri(a, c, b); tri(b, c, d)
            }
            fun cap(ring: List<Int>, ringPts: List<V>, out: V, flip: Boolean) {
                val cx = ringPts.sumOf { it.x } / n; val cy = ringPts.sumOf { it.y } / n; val cz = ringPts.sumOf { it.z } / n
                val center = add(V(cx, cy, cz) + out)
                for (j in 0 until n) if (flip) tri(center, ring[(j + 1) % n], ring[j]) else tri(center, ring[j], ring[(j + 1) % n])
            }
            if (capStart) cap(base.first(), rings.first(), outwardAtStart, flip = false)
            if (capEnd) cap(base.last(), rings.last(), outwardAtEnd, flip = true)
            endPart()
        }

        /** 축(u,v,w 방향 반지름 벡터)으로 정한 타원체 */
        fun ellipsoid(c: V, u: V, v: V, w: V, lat: Int = 16, lon: Int = 24) {
            val top = add(c + v)
            val rows = (1 until lat).map { i ->
                val th = PI * i / lat
                (0 until lon).map { j ->
                    val ph = 2 * PI * j / lon
                    add(c + v * cos(th) + u * (sin(th) * cos(ph)) + w * (sin(th) * sin(ph)))
                }
            }
            val bottom = add(c - v)
            for (j in 0 until lon) tri(top, rows.first()[(j + 1) % lon], rows.first()[j])
            for (i in 0 until rows.size - 1) for (j in 0 until lon) {
                val a = rows[i][j]; val b = rows[i][(j + 1) % lon]; val d = rows[i + 1][j]; val e = rows[i + 1][(j + 1) % lon]
                tri(a, b, d); tri(b, e, d)
            }
            for (j in 0 until lon) tri(bottom, rows.last()[j], rows.last()[(j + 1) % lon])
            endPart()
        }

        fun build(): Mesh {
            val p = FloatArray(pos.size) { pos[it].toFloat() }
            val nAcc = DoubleArray(pos.size)
            for (t in idx.indices step 3) {
                val a = idx[t]; val b = idx[t + 1]; val c = idx[t + 2]
                val pa = V(pos[a * 3], pos[a * 3 + 1], pos[a * 3 + 2])
                val pb = V(pos[b * 3], pos[b * 3 + 1], pos[b * 3 + 2])
                val pc = V(pos[c * 3], pos[c * 3 + 1], pos[c * 3 + 2])
                val fn = (pb - pa).cross(pc - pa)
                for (k in listOf(a, b, c)) { nAcc[k * 3] += fn.x; nAcc[k * 3 + 1] += fn.y; nAcc[k * 3 + 2] += fn.z }
            }
            val nrm = FloatArray(pos.size)
            for (i in 0 until pos.size / 3) {
                val v = V(nAcc[i * 3], nAcc[i * 3 + 1], nAcc[i * 3 + 2]).norm()
                nrm[i * 3] = v.x.toFloat(); nrm[i * 3 + 1] = v.y.toFloat(); nrm[i * 3 + 2] = v.z.toFloat()
            }
            return Mesh(p, nrm, idx.toIntArray())
        }
    }

    /** 둘레 P, 깊이/너비 비 k 인 타원의 가로 반지름 (Ramanujan 근사) */
    fun ellipseHalfWidth(perimeter: Double, k: Double): Double {
        val f = PI * (3 * (1 + k) - sqrt((3 + k) * (1 + 3 * k)))
        return perimeter / f
    }

    /** Catmull-Rom 으로 키 방향 단면 값을 부드럽게 잇는다 */
    private fun spline(keys: List<Pair<Double, Double>>, y: Double): Double {
        val i = keys.indexOfLast { it.first <= y }.coerceIn(0, keys.size - 2)
        val (y1, v1) = keys[i]; val (y2, v2) = keys[i + 1]
        val v0 = keys.getOrNull(i - 1)?.second ?: v1
        val v3 = keys.getOrNull(i + 2)?.second ?: v2
        val t = ((y - y1) / (y2 - y1)).coerceIn(0.0, 1.0)
        val t2 = t * t; val t3 = t2 * t
        return 0.5 * ((2 * v1) + (-v0 + v2) * t + (2 * v0 - 5 * v1 + 4 * v2 - v3) * t2 + (-v0 + 3 * v1 - 3 * v2 + v3) * t3)
    }

    fun build(d: MannequinDims): Mesh {
        val h = d.height
        val male = d.shape == BodyShapeBase.MALE
        val b = Builder()

        // ---- 몸통: 단면(가로 반지름 a, 깊이 비 k, 앞뒤 중심 이동 z)을 키 방향으로 잇는다
        val sh = d.shoulder / 2
        val hipA = ellipseHalfWidth(d.hip, 0.74)
        val waistA = ellipseHalfWidth(d.waist, 0.72)
        val chestK = if (male) 0.66 else 0.72
        val chestA = ellipseHalfWidth(d.chest, chestK)
        val neckR = d.chest * (if (male) 0.40 else 0.35) / (2 * PI)
        // (높이 비율, 가로 반지름, 깊이 비, 앞쪽 이동)
        val keys = listOf(
            Triple(0.455, hipA * 0.35, 0.55) to 0.0,
            Triple(0.47, hipA * 0.86, 0.66) to 0.0,
            Triple(0.50, hipA * 0.97, 0.72) to -0.004,
            Triple(0.53, hipA, 0.74) to -0.006,
            Triple(0.575, (hipA + waistA) / 2, 0.73) to -0.002,
            Triple(0.62, waistA, 0.72) to 0.0,
            Triple(0.67, waistA * 0.4 + chestA * 0.6, 0.70) to 0.002,
            Triple(0.72, chestA, chestK) to if (male) 0.004 else 0.008,
            Triple(0.765, maxOf(chestA * 0.97, sh * 0.80), 0.62) to 0.0,
            Triple(0.80, sh * 0.90, 0.46) to -0.004,
            Triple(0.815, sh * 0.58, 0.55) to -0.004,
            Triple(0.828, neckR * 1.35, 0.85) to -0.004,
        )
        val aKeys = keys.map { it.first.first to it.first.second }
        val kKeys = keys.map { it.first.first to it.first.third }
        val zKeys = keys.map { it.first.first to it.second }
        val torsoRings = (0..48).map { i ->
            val yf = 0.455 + (0.828 - 0.455) * i / 48.0
            val a = spline(aKeys, yf); val k = spline(kKeys, yf); val zo = spline(zKeys, yf) * h
            (0 until AROUND).map { j ->
                val t = 2 * PI * j / AROUND
                V(a * cos(t), yf * h, zo + a * k * sin(t))
            }
        }
        b.tube(torsoRings, capStart = true, capEnd = false, outwardAtStart = V(0.0, -0.5, 0.0), outwardAtEnd = V(0.0, 0.0, 0.0))

        // ---- 목
        val neckRings = listOf(0.82, 0.845, 0.87, 0.885).map { yf ->
            (0 until AROUND).map { j -> val t = 2 * PI * j / AROUND; V(neckR * cos(t), yf * h, -0.004 * h + neckR * 0.95 * sin(t)) }
        }
        b.tube(neckRings, capStart = false, capEnd = true, outwardAtStart = V(0.0, 0.0, 0.0), outwardAtEnd = V(0.0, 0.3, 0.0))

        // ---- 머리
        b.ellipsoid(V(0.0, 0.935 * h, 0.004 * h), V(0.046 * h, 0.0, 0.0), V(0.0, 0.066 * h, 0.0), V(0.0, 0.0, 0.054 * h))

        // ---- 팔(살짝 벌린 A 자세)
        val armCirc = d.chest * (if (male) 0.31 else 0.29)
        val ru = armCirc / (2 * PI)
        val angle = 12.0 * PI / 180
        for (side in listOf(-1.0, 1.0)) {
            val dir = V(side * sin(angle), -cos(angle), 0.0)
            val start = V(side * (sh - ru * 1.05), 0.79 * h, -0.006 * h)
            val side1 = V(0.0, 0.0, 1.0)
            val side2 = dir.cross(side1).norm()
            val sections = listOf(0.0 to 1.0, 0.18 to 0.97, 0.42 to 0.78, 0.48 to 0.74, 0.6 to 0.8, 0.85 to 0.62, 1.0 to 0.55)
            val rings = sections.map { (t, s) ->
                val c = start + dir * (t * d.arm)
                (0 until 24).map { j -> val th = 2 * PI * j / 24; c + side2 * (ru * s * cos(th)) + side1 * (ru * s * 0.88 * sin(th)) }
            }
            b.tube(rings, capStart = false, capEnd = false, outwardAtStart = V(0.0, 0.0, 0.0), outwardAtEnd = V(0.0, 0.0, 0.0))
            b.ellipsoid(start, V(ru * 1.0, 0.0, 0.0), V(0.0, ru * 0.95, 0.0), V(0.0, 0.0, ru * 0.92), 10, 16) // 어깨 관절
            val wrist = start + dir * d.arm
            val handLen = 0.105 * h
            b.ellipsoid(wrist + dir * (handLen * 0.45), side2 * (0.024 * h), dir * (handLen * 0.52), side1 * (0.013 * h), 12, 16)
        }

        // ---- 다리
        val thighR = d.hip * 0.6 / (2 * PI)
        for (side in listOf(-1.0, 1.0)) {
            val sections = listOf(
                0.55 to 0.95, 0.50 to 1.02, 0.45 to 0.98, 0.40 to 0.90, 0.34 to 0.76, 0.29 to 0.62,
                0.24 to 0.66, 0.20 to 0.68, 0.15 to 0.56, 0.09 to 0.42, 0.045 to 0.36,
            )
            val rings = sections.map { (yf, s) ->
                val xc = side * hipA * (0.40 + 0.10 * (yf - 0.045) / 0.505)
                (0 until 32).map { j -> val t = 2 * PI * j / 32; V(xc + thighR * s * cos(t), yf * h, thighR * s * 0.95 * sin(t)) }
            }
            b.tube(rings, capStart = false, capEnd = true, outwardAtStart = V(0.0, 0.0, 0.0), outwardAtEnd = V(0.0, -0.3, 0.0))
            val footX = side * hipA * 0.40
            b.ellipsoid(V(footX, 0.022 * h, 0.03 * h), V(0.03 * h, 0.0, 0.0), V(0.0, 0.022 * h, 0.0), V(0.0, 0.0, 0.07 * h), 10, 18)
        }
        return b.build()
    }
}
