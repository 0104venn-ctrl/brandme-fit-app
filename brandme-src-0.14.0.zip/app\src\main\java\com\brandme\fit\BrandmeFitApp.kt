package com.brandme.fit

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.brandme.fit.catalog.DemoCatalog
import com.brandme.fit.data.local.AppDatabase
import com.brandme.fit.data.local.BodyProfileStore
import com.brandme.fit.data.local.SettingsDataStore
import com.brandme.fit.data.repository.GarmentRepository
import com.brandme.fit.data.repository.HistoryRepository
import com.brandme.fit.recognition.AnalysisPipeline
import com.brandme.fit.recognition.FitBasis
import com.brandme.fit.recognition.MlKitScreenTextReader

/** 간단한 수동 DI 컨테이너 */
class AppContainer(app: Application) {
    private val db = AppDatabase.create(app)
    val settings = SettingsDataStore(app)
    val body = BodyProfileStore(app)
    val garments = GarmentRepository(db.garmentDao())
    val history = HistoryRepository(db.historyDao())

    /** 비교 기준: 내 몸 치수. (예전 버전의 기준 옷 데이터는 쓰지 않고, 전체 삭제 때만 함께 지운다) */
    suspend fun fitBasis(): FitBasis = FitBasis(null, body.get())
    val catalog: DemoCatalog by lazy { DemoCatalog.load(app) }
    val pipeline: AnalysisPipeline by lazy { AnalysisPipeline(catalog, MlKitScreenTextReader()) }
}

class BrandmeFitApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_OVERLAY, "플로팅 버튼", NotificationManager.IMPORTANCE_LOW).apply {
                description = "brandme Fit 플로팅 버튼이 켜져 있을 때 표시됩니다."
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_CAPTURE, "화면 캡처", NotificationManager.IMPORTANCE_LOW).apply {
                description = "화면 캡처 세션이 활성화되어 있을 때 표시됩니다."
            },
        )
    }

    companion object {
        const val CHANNEL_OVERLAY = "overlay"
        const val CHANNEL_CAPTURE = "capture"
    }
}

val android.content.Context.appContainer: AppContainer
    get() = (applicationContext as BrandmeFitApp).container
