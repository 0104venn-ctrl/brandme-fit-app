package com.brandme.fit.body3d

import com.brandme.fit.data.model.Measurements
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 실제 옷 틀(티셔츠·스웨터, MakeHuman CC0)을 사용자의 몸에 입히고 사이즈표 수치에 맞춘다.
 *
 *  1. 옷 틀은 몸 표면에 묶여 있어 체형을 그대로 따라간다(목선·소매·주름 모양 유지).
 *  2. 둘레: 높이마다 지금 옷 둘레를 재고, 사이즈표 둘레(가슴 단면 × 2)가 되도록 몸에서 더 띄운다.
 *     겨드랑이 아래는 옷 둘레가 몸 둘레보다 작아지지 않게 곧게 내린다(허리로 파고들지 않음).
 *  3. 총장: 가슴 아래 부분을 위아래로 늘이거나 줄여 목 옆점~밑단이 총장이 되게 한다. 늘린 부분이 몸 안으로
 *     들어가면 몸 바깥으로 밀어낸다. 가랑이보다 길면 가랑이 높이에서 멈춘다.
 *  4. 소매: 어깨 끝~소매 끝이 (드롭 길이 + 소매 길이)가 되도록 팔 방향으로 늘이거나 줄인다.
 * 천 시뮬레이션이 아니므로 처짐·흔들림은 없다.
 */
object TemplateDresser {

    private const val TORSO = 2
    private const val LEGS = 9
    private val ARM_PARTS = setOf(3, 4, 5, 6, 7, 8)
    private val LEFT_ARM = setOf(3, 5, 7)

    private class P2(val x: Double, val z: Double)

    private fun hull(pts: List<P2>): List<P2> {
        if (pts.size < 3) return pts
        val s = pts.sortedWith(compareBy({ it.x }, { it.z }))
        fun cross(o: P2, a: P2, b: P2) = (a.x - o.x) * (b.z - o.z) - (a.z - o.z) * (b.x - o.x)
        val lower = ArrayList<P2>(); val upper = ArrayList<P2>()
        for (q in s) { while (lower.size >= 2 && cross(lower[lower.size - 2], lower.last(), q) <= 0) lower.removeAt(lower.size - 1); lower += q }
        for (q in s.asReversed()) { while (upper.size >= 2 && cross(upper[upper.size - 2], upper.last(), q) <= 0) upper.removeAt(upper.size - 1); upper += q }
        return lower.dropLast(1) + upper.dropLast(1)
    }

    private fun perimeter(h: List<P2>) = if (h.size < 3) 0.0 else h.indices.sumOf { i ->
        val a = h[i]; val b = h[(i + 1) % h.size]; sqrt((a.x - b.x) * (a.x - b.x) + (a.z - b.z) * (a.z - b.z))
    }

    private fun radiusAt(h: List<P2>, cx: Double, cz: Double, th: Double): Double {
        val dx = cos(th); val dz = sin(th)
        var best = 0.0
        for (i in h.indices) {
            val a = h[i]; val b = h[(i + 1) % h.size]
            val ex = b.x - a.x; val ez = b.z - a.z
            val den = dx * ez - dz * ex
            if (abs(den) < 1e-9) continue
            val t = ((a.x - cx) * ez - (a.z - cz) * ex) / den
            val u = ((a.x - cx) * dz - (a.z - cz) * dx) / den
            if (t > 0 && u in -1e-6..1.000001) best = maxOf(best, t)
        }
        return best
    }

    fun dress(body: HumanBodyModel.Result, dims: MannequinDims, garment: Measurements, tpl: ClothesTemplate): FittedGarment {
        val m = body.mesh
        val P = m.positions; val N = m.normals; val parts = body.parts; val armT = body.armT
        val h = dims.height
        val crotchY = (0 until m.vertexCount).filter { parts[it] == TORSO }.minOf { P[it * 3 + 1] }.toDouble()

        // ---- 몸통 단면(높이 1cm 칸): 몸통 + 엉덩이·허벅지 윗부분
        val bodyBins = HashMap<Int, ArrayList<P2>>()
        for (i in 0 until m.vertexCount) {
            val y = P[i * 3 + 1]
            if (parts[i] == TORSO || (parts[i] == LEGS && y > crotchY - 0.06 * h)) {
                bodyBins.getOrPut(y.toInt()) { ArrayList() } += P2(P[i * 3].toDouble(), P[i * 3 + 2].toDouble())
            }
        }
        val hullCache = HashMap<Int, List<P2>>()
        fun bodyHull(y: Double): List<P2> = hullCache.getOrPut(y.toInt()) { hull((-1..1).flatMap { bodyBins[y.toInt() + it].orEmpty() }) }
        fun bodyGirth(y: Double) = perimeter(bodyHull(y))

        // ---- 옷 틀을 지금 몸에 붙인 위치
        val v = tpl.vertexCount
        val base = DoubleArray(v * 3); val nrm = DoubleArray(v * 3); val aT = DoubleArray(v)
        val part = IntArray(v)
        for (i in 0 until v) {
            var bestW = -1f
            for (k in 0..2) {
                val j = tpl.bindVerts[i * 3 + k]; val w = tpl.bindWeights[i * 3 + k]
                for (c in 0..2) { base[i * 3 + c] += w * P[j * 3 + c]; nrm[i * 3 + c] += w * N[j * 3 + c] }
                aT[i] += w * armT[j]
                if (w > bestW) { bestW = w; part[i] = parts[j] }
            }
            val l = sqrt(nrm[i * 3] * nrm[i * 3] + nrm[i * 3 + 1] * nrm[i * 3 + 1] + nrm[i * 3 + 2] * nrm[i * 3 + 2]).coerceAtLeast(1e-9)
            for (c in 0..2) nrm[i * 3 + c] /= l
        }
        val off = DoubleArray(v) { tpl.bindOffset[it].toDouble() }
        val isArm = BooleanArray(v) { part[it] in ARM_PARTS }
        val isTorso = BooleanArray(v) { !isArm[it] }

        val hpsY = 0.835 * h
        val armpitY = 0.735 * h
        val yokeY = 0.795 * h
        val garmentGirth = garment.chestCircumferenceCm ?: garment.chestFlatCm?.let { it * 2 } ?: (dims.chest + 10)
        val shoulderEase = garment.shoulderCm?.let { it - dims.shoulder } ?: 1.0
        val drop = maxOf(0.0, shoulderEase / 2)
        val sleeveLen = garment.sleeveCm
        val shortSleeve = (sleeveLen ?: 0.0) < dims.arm * 0.6
        val sleeveEase = sleeveLen?.let { (garment.shoulderCm ?: dims.shoulder) / 2 + it - (dims.shoulder / 2 + dims.arm) } ?: 0.0

        val chestRefY = 0.715 * h
        val chestGirth = bodyGirth(chestRefY)

        // ---- 둘레: 지금 옷 둘레(2cm 칸)와 목표 둘레의 차이만큼 띄운다
        val tplBins = HashMap<Int, ArrayList<P2>>()
        for (i in 0 until v) if (isTorso[i]) {
            val p = pos(base, nrm, off, i, 0.0)
            tplBins.getOrPut((p[1] / 2).toInt()) { ArrayList() } += P2(p[0], p[2])
        }
        val tplGirth = tplBins.mapValues { perimeter(hull(it.value)) }
        val extra = DoubleArray(v)
        val heat = arrayOfNulls<HeatLevel>(v)
        for (i in 0 until v) {
            val y = base[i * 3 + 1]
            if (isTorso[i]) {
                val cur = tplGirth[(y / 2).toInt()] ?: continue
                val bg = bodyGirth(y)
                val target = when {
                    y <= armpitY -> maxOf(garmentGirth, bg + 1.0)
                    y <= yokeY -> { val t = (y - armpitY) / (yokeY - armpitY); maxOf(garmentGirth, bg + 1.0) * (1 - t) + cur * t }
                    else -> cur
                }
                extra[i] = ((target - cur) / (2 * PI)).coerceIn(-off[i] + 0.15, 14.0)
                // 겨드랑이 높이 몸 단면에는 팔이 붙는 부분이 섞여 둘레가 튀므로, 그 위쪽은 가슴 높이 몸 둘레로 판단한다
                heat[i] = when {
                    y > armpitY + (yokeY - armpitY) * 0.5 -> GarmentFitter.shoulderLevel(shoulderEase)
                    y > chestRefY -> GarmentFitter.torsoLevel(garmentGirth - chestGirth)
                    else -> GarmentFitter.torsoLevel(garmentGirth - bg)
                }
            } else {
                val k = aT[i].coerceIn(0.0, 1.0)
                extra[i] = (0.6 + minOf(drop, 10.0) * 0.12) * (1 - k) + 0.25 * k
                heat[i] = when {
                    aT[i] * dims.arm < drop -> GarmentFitter.shoulderLevel(shoulderEase)
                    shortSleeve -> HeatLevel.COMFORT
                    else -> GarmentFitter.sleeveLevel(sleeveEase)
                }
            }
        }
        val out = DoubleArray(v * 3)
        for (i in 0 until v) { val p = pos(base, nrm, off, i, extra[i]); for (c in 0..2) out[i * 3 + c] = p[c] }

        // ---- 총장: 가슴 아래를 위아래로 늘이거나 줄인다
        val torsoIdx = (0 until v).filter { isTorso[it] }
        val tplHem = torsoIdx.minOf { out[it * 3 + 1] }
        val chestY = armpitY - 0.02 * h
        val wantHem = hpsY - (garment.lengthCm ?: (hpsY - tplHem))
        val hemLimit = crotchY + 1.0
        val hemCut = wantHem < hemLimit
        val hemY = maxOf(wantHem, hemLimit)
        if (tplHem < chestY - 1) {
            val k = (chestY - hemY) / (chestY - tplHem)
            for (i in torsoIdx) {
                val y = out[i * 3 + 1]
                if (y >= chestY) continue
                val ny = chestY - (chestY - y) * k
                out[i * 3 + 1] = ny
                // 늘어난 자리에서 몸 안으로 들어가면 몸 바깥으로 밀어낸다(엉덩이를 덮을 때)
                val hb = bodyHull(ny)
                if (hb.size >= 3) {
                    val cx = hb.sumOf { it.x } / hb.size; val cz = hb.sumOf { it.z } / hb.size
                    val dx = out[i * 3] - cx; val dz = out[i * 3 + 2] - cz
                    val r = sqrt(dx * dx + dz * dz)
                    val th = atan2(dz, dx)
                    val rMin = radiusAt(hb, cx, cz, th) + 0.4
                    if (r < rMin && r > 1e-6) { out[i * 3] = cx + dx / r * rMin; out[i * 3 + 2] = cz + dz / r * rMin }
                }
            }
        }

        // ---- 소매 길이: 팔 방향으로 늘이거나 줄인다
        if (sleeveLen != null) {
            for (left in listOf(true, false)) {
                val sideParts = if (left) LEFT_ARM else ARM_PARTS - LEFT_ARM
                val bodyArm = (0 until m.vertexCount).filter { parts[it] in sideParts }
                if (bodyArm.size < 20) continue
                fun centroid(sel: List<Int>) = DoubleArray(3) { c -> sel.sumOf { P[it * 3 + c].toDouble() } / sel.size }
                val s0 = centroid(bodyArm.filter { armT[it] < 0.08f }.ifEmpty { bodyArm })
                val s1 = centroid(bodyArm.filter { armT[it] > 0.92f && armT[it] < 1.05f }.ifEmpty { bodyArm })
                val ax = DoubleArray(3) { s1[it] - s0[it] }
                val axLen = sqrt(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2]); for (c in 0..2) ax[c] /= axLen
                val sleeveIdx = (0 until v).filter { isArm[it] && part[it] in sideParts }
                if (sleeveIdx.isEmpty()) continue
                fun along(i: Int) = (0..2).sumOf { (out[i * 3 + it] - s0[it]) * ax[it] }
                val curEnd = sleeveIdx.maxOf { along(it) }
                val wantEnd = (drop + sleeveLen).coerceAtMost(axLen * 1.05)
                val pivot = axLen * 0.12
                if (curEnd > pivot + 1) {
                    val k = (wantEnd - pivot) / (curEnd - pivot)
                    for (i in sleeveIdx) {
                        val a = along(i)
                        if (a <= pivot) continue
                        val shift = (a - pivot) * (k - 1)
                        for (c in 0..2) out[i * 3 + c] += ax[c] * shift
                    }
                }
            }
        }

        val pos = FloatArray(v * 3) { out[it].toFloat() }
        val heatC = FloatArray(v * 3); val plainC = FloatArray(v * 3)
        val plain = floatArrayOf(0xB9 / 255f, 0xC3 / 255f, 0xCF / 255f)
        for (i in 0 until v) {
            val c = (heat[i] ?: HeatLevel.COMFORT).rgb
            heatC[i * 3] = ((c shr 16) and 0xFF) / 255f; heatC[i * 3 + 1] = ((c shr 8) and 0xFF) / 255f; heatC[i * 3 + 2] = (c and 0xFF) / 255f
            for (k in 0..2) plainC[i * 3 + k] = plain[k]
        }
        return FittedGarment(Mesh(pos, normals(pos, tpl.indices), tpl.indices), heatC, plainC, hemCut)
    }

    private fun pos(base: DoubleArray, nrm: DoubleArray, off: DoubleArray, i: Int, extra: Double): DoubleArray =
        DoubleArray(3) { c -> base[i * 3 + c] + nrm[i * 3 + c] * (off[i] + extra) }

    private fun normals(p: FloatArray, idx: IntArray): FloatArray {
        val out = FloatArray(p.size)
        for (t in idx.indices step 3) {
            val a = idx[t] * 3; val b = idx[t + 1] * 3; val c = idx[t + 2] * 3
            val ux = p[b] - p[a]; val uy = p[b + 1] - p[a + 1]; val uz = p[b + 2] - p[a + 2]
            val vx = p[c] - p[a]; val vy = p[c + 1] - p[a + 1]; val vz = p[c + 2] - p[a + 2]
            val fx = uy * vz - uz * vy; val fy = uz * vx - ux * vz; val fz = ux * vy - uy * vx
            for (k in intArrayOf(a, b, c)) { out[k] += fx; out[k + 1] += fy; out[k + 2] += fz }
        }
        for (i in 0 until p.size / 3) {
            val l = sqrt(out[i * 3] * out[i * 3] + out[i * 3 + 1] * out[i * 3 + 1] + out[i * 3 + 2] * out[i * 3 + 2]).coerceAtLeast(1e-9f)
            out[i * 3] /= l; out[i * 3 + 1] /= l; out[i * 3 + 2] /= l
        }
        return out
    }
}
