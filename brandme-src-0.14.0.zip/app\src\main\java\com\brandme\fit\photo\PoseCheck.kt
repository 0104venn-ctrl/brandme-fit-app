package com.brandme.fit.photo

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import kotlin.math.abs
import kotlin.math.atan2

/** 실시간 자세 점검 결과. ok 면 촬영해도 되는 자세 */
data class PoseStatus(val ok: Boolean, val message: String, val anchor: Pt? = null)

/**
 * 카메라 미리보기 프레임의 관절 위치(0..1 정규화, 위가 y=0)로 촬영 자세를 점검한다.
 * 기준값은 촬영 안내(가이드 선)에 맞춰 정한 값이다.
 */
object PoseCheck {
    const val NOSE = 0
    const val L_SHOULDER = 11; const val R_SHOULDER = 12
    const val L_WRIST = 15; const val R_WRIST = 16
    const val L_HIP = 23; const val R_HIP = 24
    const val L_ANKLE = 27; const val R_ANKLE = 28
    const val L_HEEL = 29; const val R_HEEL = 30

    fun evaluate(pose: PhotoPose, lm: (Int) -> Pt?): PoseStatus {
        val nose = lm(NOSE)
        val feet = listOfNotNull(lm(L_HEEL), lm(R_HEEL), lm(L_ANKLE), lm(R_ANKLE))
        if (nose == null || feet.isEmpty()) return PoseStatus(false, "머리부터 발끝까지 화면에 들어오게 서 주세요")
        val footY = feet.maxOf { it.y }
        val bodyH = footY - nose.y
        if (nose.y < 0.06) return PoseStatus(false, "머리 위가 잘려요. 조금 뒤로 물러나 주세요")
        if (footY > 0.97) return PoseStatus(false, "발이 잘려요. 조금 뒤로 물러나 주세요")
        if (bodyH < 0.55) return PoseStatus(false, "조금 더 가까이 와 주세요")
        if (bodyH > 0.86) return PoseStatus(false, "조금 뒤로 물러나 주세요")
        val ls = lm(L_SHOULDER); val rs = lm(R_SHOULDER); val lh = lm(L_HIP); val rh = lm(R_HIP)
        val hips = listOfNotNull(lh, rh)
        if (hips.isEmpty() || (ls == null && rs == null)) return PoseStatus(false, "몸 전체가 잘 보이게 서 주세요")
        val cx = hips.map { it.x }.average()
        if (cx < 0.35) return PoseStatus(false, "화면 가운데로 조금 이동해 주세요")
        if (cx > 0.65) return PoseStatus(false, "화면 가운데로 조금 이동해 주세요")

        val shoulderDx = if (ls != null && rs != null) abs(ls.x - rs.x) / bodyH else 0.0
        return when (pose) {
            PhotoPose.FRONT -> {
                if (ls == null || rs == null || lh == null || rh == null) return PoseStatus(false, "정면을 봐 주세요")
                if (shoulderDx < 0.13) return PoseStatus(false, "몸을 카메라 정면으로 돌려 주세요")
                if (abs(ls.y - rs.y) / bodyH > 0.04) return PoseStatus(false, "어깨가 수평이 되게 똑바로 서 주세요")
                // A자 자세: 양팔이 몸에서 비스듬히(아래 방향 기준 20~60°) 벌어져 있어야 한다
                val lw = lm(L_WRIST); val rw = lm(R_WRIST)
                if (lw == null || rw == null) return PoseStatus(false, "양팔이 보이게 서 주세요")
                val angles = listOf(armAngle(ls, lw, cx), armAngle(rs, rw, cx))
                if (angles.any { it < MIN_ARM_DEG }) return PoseStatus(false, "양팔을 몸에서 비스듬히 더 벌려 주세요 (약 45°)")
                if (angles.any { it > MAX_ARM_DEG }) return PoseStatus(false, "팔을 조금 내려 주세요 (약 45°)")
                PoseStatus(true, "좋아요! 그대로 멈춰 주세요")
            }
            PhotoPose.SIDE -> {
                if (shoulderDx > 0.07) return PoseStatus(false, "몸을 옆으로 돌려 서 주세요")
                PoseStatus(true, "좋아요! 그대로 멈춰 주세요")
            }
        }
    }

    /** A자 자세로 인정하는 팔 각도(몸 아래 방향 0°, 수평 90°) */
    const val MIN_ARM_DEG = 20.0
    const val MAX_ARM_DEG = 60.0

    /**
     * 어깨→손목이 몸 바깥쪽으로 아래 방향에서 몇 도 벌어졌는지. 손목이 몸 안쪽으로 들어오면 음수.
     * 손목이 어깨보다 위면 90° 이상.
     */
    fun armAngle(shoulder: Pt, wrist: Pt, centerX: Double): Double {
        val outward = if (shoulder.x >= centerX) wrist.x - shoulder.x else shoulder.x - wrist.x
        val down = wrist.y - shoulder.y
        return Math.toDegrees(atan2(outward, down))
    }

    /** 최근 관절 위치가 거의 움직이지 않았는지(정규화 좌표 기준) */
    fun isSteady(history: List<Pt>, tolerance: Double = 0.012): Boolean {
        if (history.size < 3) return false
        val xs = history.map { it.x }; val ys = history.map { it.y }
        return (xs.max() - xs.min()) < tolerance && (ys.max() - ys.min()) < tolerance
    }
}

/** 미리보기 프레임용 가벼운 자세 인식(lite 모델). 프레임은 메모리에서만 쓰고 저장하지 않는다. */
class LivePoseChecker(context: Context) : AutoCloseable {
    private val landmarker = PoseLandmarker.createFromOptions(
        context,
        PoseLandmarker.PoseLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("mediapipe/pose_landmarker_lite.task").build())
            .setRunningMode(RunningMode.IMAGE)
            .setNumPoses(1)
            .build(),
    )

    /** 반환: 자세 점검 결과와 안정성 판단용 기준점(골반 중앙) */
    fun check(bitmap: Bitmap, pose: PhotoPose): PoseStatus {
        val lms = landmarker.detect(BitmapImageBuilder(bitmap).build()).landmarks().firstOrNull()
            ?: return PoseStatus(false, "사람을 찾고 있어요. 가이드 선 안에 서 주세요")
        fun lm(i: Int): Pt? {
            val l = lms.getOrNull(i) ?: return null
            if (l.visibility().orElse(1f) < 0.6f) return null
            if (l.x() !in -0.02f..1.02f || l.y() !in -0.02f..1.02f) return null
            return Pt(l.x().toDouble(), l.y().toDouble())
        }
        val status = PoseCheck.evaluate(pose, ::lm)
        val anchor = listOfNotNull(lm(PoseCheck.L_HIP), lm(PoseCheck.R_HIP), lm(PoseCheck.NOSE))
            .takeIf { it.isNotEmpty() }?.let { p -> Pt(p.map { it.x }.average(), p.map { it.y }.average()) }
        return status.copy(anchor = anchor)
    }

    override fun close() = landmarker.close()
}
