package com.brandme.fit.recognition

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

fun interface ScreenTextReader {
    suspend fun read(bitmap: Bitmap): ScreenText
}

/** ML Kit 한국어 OCR. 모델이 APK에 포함되어 네트워크 없이 기기 안에서만 동작한다. */
class MlKitScreenTextReader : ScreenTextReader {
    override suspend fun read(bitmap: Bitmap): ScreenText {
        val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        try {
            val text = suspendCancellableCoroutine { cont ->
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { cont.resume(it) }
                    .addOnFailureListener { cont.resumeWithException(it) }
            }
            val lines = text.textBlocks.flatMap { it.lines }.mapNotNull { line ->
                val box = line.boundingBox ?: return@mapNotNull null
                val words = line.elements.mapNotNull { e ->
                    e.boundingBox?.let { b -> TextLine(e.text, b.left, b.top, b.right, b.bottom) }
                }
                TextLine(line.text, box.left, box.top, box.right, box.bottom, words)
            }
            return ScreenText(lines)
        } finally {
            recognizer.close()
        }
    }
}
