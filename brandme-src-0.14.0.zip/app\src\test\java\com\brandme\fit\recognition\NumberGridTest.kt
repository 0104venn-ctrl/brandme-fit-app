package com.brandme.fit.recognition

import com.brandme.fit.data.model.ChestMeasureMethod
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 실기기에서 받은 4가지 사이즈표를 좌표까지 재현해, "숫자로 표 만들기 → 이름 붙이기" 방식이
 * 형식별 규칙 없이 모두 읽는지 확인한다. 셀 텍스트는 실제 OCR 결과(오타 포함)를 그대로 썼다.
 */
class NumberGridTest {

    private val step = 150

    /** 칸 하나 = OCR 줄 하나 (실제 ML Kit 도 넓게 떨어진 칸은 따로 줄로 준다) */
    private fun cell(text: String, col: Int, y: Int, h: Int = 14): TextLine {
        val cx = 80 + col * step
        val w = maxOf(20, text.length * 8)
        return TextLine(text, cx - w / 2, y, cx + w / 2, y + h)
    }

    private fun row(y: Int, vararg texts: String?) = texts.mapIndexedNotNull { i, t -> t?.let { cell(it, i, y) } }

    private fun found(lines: List<TextLine>) =
        (NumberGrid.read(lines)!!.result as SizeChartTextParser.Result.Found).chart

    /** 1) 쿠팡 후드: 가로형, "XL (95)" 라벨, "76. 6" 띄어 읽힘, 체중 범위 열 */
    @Test fun `coupang hoodie horizontal table`() {
        val lines = listOf(cell("여유 있는 밑단 디자인", 2, 20)) +
            row(100, "사이즈 표", "어깨", "가슴 단면", "팔기장", "총기장", "체중 (kg)") +
            row(140, "XL (95)", "46", "53", "74.8", "68", "65-75") +
            row(180, "2XL (100)", "47.5", "55", null, "70", "75-82") +
            // OCR 이 "76. 6" 을 두 단어로 준 경우(단어 위치 포함)
            listOf(TextLine("76. 6", 510, 180, 550, 194, listOf(TextLine("76.", 510, 180, 535, 194), TextLine("6", 540, 180, 550, 194)))) +
            row(220, "3XL (105)", "49", "57", "78.4", "72", "82-90") +
            row(260, "4XL (110)", "50. 5".replace(". ", "."), "59", "80.2", "74", "90-100") +
            listOf(cell("*측정방법에 따라 1`3cm오차가 있을 수 있습니다!", 2, 300))
        val chart = found(lines)
        assertEquals(listOf("XL(95)", "2XL(100)", "3XL(105)", "4XL(110)"), chart.sizes.map { it.label })
        val xxl = chart.sizes[1].measurements
        assertEquals(47.5, xxl.shoulderCm!!, 1e-9)
        assertEquals(55.0, xxl.chestFlatCm!!, 1e-9)
        assertEquals(76.6, xxl.sleeveCm!!, 1e-9)
        assertEquals(70.0, xxl.lengthCm!!, 1e-9)
    }

    /** 2) 작은 표: 번호 붙은 헤더와 라벨 */
    @Test fun `numbered headers and labels`() {
        val lines = listOf(cell("단위(cm)", 4, 60)) +
            row(100, "사이즈", "1.어깨", "2가슴", "3.소매", "7.총길이") +
            row(140, "M(1번)", "58", "60", "55", "68") +
            row(180, "L(2번)", "61", "63", "56", "69") +
            row(220, "XL(3번)", "64", "66", "57", "70")
        val chart = found(lines)
        assertEquals(listOf("M", "L", "XL"), chart.sizes.map { it.label })
        assertEquals(58.0, chart.sizes[0].measurements.shoulderCm!!, 1e-9)
        assertEquals(66.0, chart.sizes[2].measurements.chestFlatCm!!, 1e-9)
    }

    /** 2-1) 같은 표를 작게 찍어 XL 라벨이 깨진 실제 OCR — 일부 사이즈만으로 결과를 내지 않는다 */
    @Test fun `broken size label is not dropped silently`() {
        val lines = row(100, "사이즈", "1.어깨", "2가슴", "3소매", "7.총길이") +
            row(140, "M1번", "58", "60", "55", "68") +
            row(180, "L2번)", "61", "63", "56", "69") +
            row(220, "3번)", "64", "66", "57", "70")
        assertTrue(NumberGrid.read(lines)!!.result is SizeChartTextParser.Result.Unreadable)
    }

    /** 3) FREE / 1번, 헤더 오타 "종기장", 비교 안 하는 "암홀" 열 */
    @Test fun `free and numbered sizes with ignored column`() {
        val lines = row(100, "SIZE", "어깨", "가슴", "팔", "암홀", "종기장") +
            row(140, "FREE", "58", "62", "57", "24", "70") +
            row(180, "1번", "62", "67", "63", "28", "74") +
            listOf(cell("-사이즈는 측정 방법에 따라 1~5cm 정도 오차가 있을 수 있습니다", 2, 230))
        val chart = found(lines)
        assertEquals(listOf("FREE", "1번"), chart.sizes.map { it.label })
        val free = chart.sizes[0].measurements
        assertEquals(58.0, free.shoulderCm!!, 1e-9)
        assertEquals(62.0, free.chestFlatCm!!, 1e-9)
        assertEquals(57.0, free.sleeveCm!!, 1e-9)
        assertEquals(70.0, free.lengthCm!!, 1e-9)
    }

    /** 3-1) 실제 1차 OCR: 헤더 "팔"을 놓침 → 숫자 칸 하나에 이름이 없으므로 읽지 않는다 */
    @Test fun `numeric column without header is unreadable`() {
        val lines = row(100, "SIZE", "어깨", "가슴", null, "암홀", "총기장") +
            row(140, "FREE", "58", "62", "57", "24", "70") +
            row(180, "1번", "62", "67", "63", "28", "74")
        val r = NumberGrid.read(lines)!!.result
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    /** 4) 세로형: 위에 사이즈, 왼쪽에 항목. 라벨 OCR 오타 "니100)", "XXL(11o)" */
    @Test fun `vertical table with sizes on top`() {
        val lines = listOf(cell("실측사이", 0, 20), cell("단위 : Cm", 0, 50)) +
            row(100, "사이즈", "M(95)", "니100)", "XL(105)", "XXL(11o)") +
            row(140, "가슴둘레", "111", "116", "121", "126") +
            row(180, "밑단둘레", "107", "112", "117", "122") +
            row(220, "소매길이", "63", "64", "65", "66") +
            row(260, "소매통", "45.5", "47", "48.5", "50") +
            row(300, "소매밑단너비", "20", "21", "22", "23") +
            row(340, "어깨너비", "46.5", "48", "49.5", "51") +
            row(380, "총기장", "67.5", "69", "70.5", "72") +
            listOf(cell("* 사이즈는 측정 방법과 생산 과정에 따라 약간의 오차가 발생할", 2, 430))
        val chart = found(lines)
        assertEquals(listOf("M(95)", "L(100)", "XL(105)", "XXL(110)"), chart.sizes.map { it.label })
        val l = chart.sizes[1].measurements
        assertEquals(48.0, l.shoulderCm!!, 1e-9)
        assertEquals(116.0, l.chestCircumferenceCm!!, 1e-9)
        assertNull(l.chestFlatCm)
        assertEquals(64.0, l.sleeveCm!!, 1e-9)
        assertEquals(69.0, l.lengthCm!!, 1e-9)
        assertEquals(ChestMeasureMethod.CIRCUMFERENCE, chart.chestMethod)
    }

    /**
     * 0.4.0 실기기: 같은 세로형 표가 "소매가 두 번"으로 실패. OCR 텍스트에 보이지 않는 문자(폭 없는 공백, NBSP)가
     * 섞이면 "소매통"을 제외 목록에서 못 찾고 "소매"로 판정할 수 있다. 정규화 후에는 제외되어야 한다.
     */
    @Test fun `invisible characters in row names do not change classification`() {
        assertEquals(SizeChartTextParser.Column.IGNORE, SizeChartTextParser.classifyHeader("소매​통"))
        assertEquals(SizeChartTextParser.Column.IGNORE, SizeChartTextParser.classifyHeader("소매밑단 너비"))
        assertEquals(SizeChartTextParser.Column.SLEEVE, SizeChartTextParser.classifyHeader("소매﻿길이"))
        val lines = row(100, "사이즈", "M(95)", "L(100)") +
            row(140, "소매길이", "63", "64") +
            row(180, "소매​통", "45.5", "47") +
            row(220, "소매밑단 너비", "20", "21") +
            row(260, "어깨너비", "46.5", "48") +
            row(300, "총기장", "67.5", "69")
        val out = NumberGrid.read(lines)!!
        assertTrue(out.debug.last().startsWith("항목 판단:"))
        assertEquals(63.0, (out.result as SizeChartTextParser.Result.Found).chart.sizes[0].measurements.sleeveCm!!, 1e-9)
    }

    /**
     * 실기기 캡처(0.5.0 실패): 사이즈 아래 국내 참고 사이즈가 한 줄 더 있고("L" / "(105)"),
     * M 은 판매하지 않아 열 전체가 "-". 위에는 도식 범례("총장 / Length")가 있다.
     */
    @Test fun `two line size header and unavailable size column`() {
        val lines = listOf(cell("상세 사이즈", 0, 0), cell("0 총장/ Length", 4, 20), cell("가슴 단면/ Chest", 4, 40)) +
            row(100, "사이즈(cm)", "M", "L", "XL", "XXL") +
            row(120, "(국내참고사이즈)", null, "(105)", "(110~115)", "(120~125)") +
            row(160, "총장", "-", "73.5", "75.5", "77.5") +
            row(200, "가슴 단면", "-", "66", "68", "70") +
            row(240, "어깨", "-", "63.5", "65", "66.5") +
            row(280, "소매 길이", "-", "54.5", "56", "57.5") +
            listOf(cell("* 사이즈는 측정 방법, 제작 특성에 따라 1-3cm 오차 범위가 있을 수 있습니다.", 2, 320))
        val chart = found(lines)
        assertEquals(listOf("L(105)", "XL(110~115)", "XXL(120~125)"), chart.sizes.map { it.label })
        val l = chart.sizes[0].measurements
        assertEquals(73.5, l.lengthCm!!, 1e-9)
        assertEquals(66.0, l.chestFlatCm!!, 1e-9)
        assertEquals(63.5, l.shoulderCm!!, 1e-9)
        assertEquals(54.5, l.sleeveCm!!, 1e-9)
        assertEquals(57.5, chart.sizes[2].measurements.sleeveCm!!, 1e-9)
    }

    /** 숫자 사이즈(90, 95, 100)가 위에 있는 세로형: "사이즈" 행을 라벨로 떼어 낸다 */
    @Test fun `numeric size labels in vertical table`() {
        val lines = row(100, "사이즈", "90", "95", "100") +
            row(140, "어깨", "44", "46", "48") +
            row(180, "총장", "66", "68", "70")
        val chart = found(lines)
        assertEquals(listOf("90", "95", "100"), chart.sizes.map { it.label })
        assertEquals(46.0, chart.sizes[1].measurements.shoulderCm!!, 1e-9)
    }

    /** OCR 이 "116"을 "16"으로 읽으면 순서가 깨지므로 결과를 내지 않는다 */
    @Test fun `value breaking size order is unreadable`() {
        val lines = row(100, "사이즈", "M", "L", "XL") +
            row(140, "가슴단면", "55", "16", "60") +
            row(180, "총장", "68", "70", "72")
        val r = NumberGrid.read(lines)!!.result
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    @Test fun `numbers that are not a size table are ignored`() {
        val lines = row(100, "상품번호", "12", "34") + row(140, "배송", "1", "2")
        assertNull(NumberGrid.read(lines))
    }
}
