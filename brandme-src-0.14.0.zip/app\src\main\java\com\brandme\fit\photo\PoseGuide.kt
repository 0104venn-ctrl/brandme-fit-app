package com.brandme.fit.photo

/** 촬영 자세 */
enum class PhotoPose(val title: String, val instruction: String) {
    FRONT("정면", "정면을 보고 서서 발은 어깨너비로, 양팔은 몸에서 비스듬히(약 45°) 벌려 주세요."),
    SIDE("옆면", "오른쪽 옆으로 서서 팔을 자연스럽게 내리고, 고개는 정면(화면 오른쪽)을 봐 주세요."),
}

/**
 * 촬영 가이드 외곽선. 정사각형(0..1) 안의 좌표로, 위가 y=0(머리)·아래가 y=1(발)이다.
 * 몸 전체가 이 선 안에 들어오게 서면 된다. 점들은 부드러운 곡선으로 이어서 그린다.
 */
object PoseGuide {

    /**
     * 정면 A자 자세: 오른쪽 절반을 정의하고 좌우 대칭으로 만든다.
     * 머리 위 → 어깨 → 비스듬히(약 40°) 벌린 팔 바깥 → 손 → 팔 안쪽 → 겨드랑이 → 몸통 옆 → 다리 바깥 → 발 아래
     */
    private val FRONT_RIGHT = listOf(
        0.50 to 0.000, 0.555 to 0.012, 0.582 to 0.055, 0.578 to 0.105, 0.552 to 0.140,
        0.548 to 0.165, 0.610 to 0.180, 0.668 to 0.198,
        0.730 to 0.240, 0.795 to 0.305, 0.855 to 0.375, 0.895 to 0.440, 0.915 to 0.485, 0.895 to 0.510,
        0.855 to 0.475, 0.795 to 0.400, 0.735 to 0.330, 0.672 to 0.275,
        0.660 to 0.340, 0.648 to 0.420, 0.662 to 0.500, 0.668 to 0.565,
        0.650 to 0.665, 0.630 to 0.780, 0.615 to 0.890, 0.622 to 0.955, 0.600 to 0.990,
        0.530 to 1.000,
    )

    val FRONT: List<Pair<Double, Double>> = FRONT_RIGHT + listOf(0.470 to 1.000) +
        FRONT_RIGHT.drop(1).dropLast(1).reversed().map { (x, y) -> 1.0 - x to y }

    /** 옆면(오른쪽을 보는 자세): 머리 위에서 시계 방향 */
    val SIDE: List<Pair<Double, Double>> = listOf(
        0.495 to 0.000, 0.548 to 0.015, 0.578 to 0.060, 0.596 to 0.100, 0.578 to 0.138,
        0.552 to 0.162, 0.590 to 0.215, 0.605 to 0.275, 0.598 to 0.360, 0.598 to 0.450,
        0.590 to 0.540, 0.575 to 0.660, 0.565 to 0.750, 0.560 to 0.880, 0.575 to 0.950, 0.625 to 0.985, 0.620 to 1.000,
        0.455 to 1.000, 0.445 to 0.965, 0.440 to 0.860, 0.448 to 0.780, 0.440 to 0.700,
        0.420 to 0.600, 0.408 to 0.520, 0.418 to 0.460, 0.432 to 0.400, 0.418 to 0.300, 0.420 to 0.215,
        0.455 to 0.165, 0.430 to 0.110, 0.438 to 0.040,
    )

    fun points(pose: PhotoPose) = if (pose == PhotoPose.FRONT) FRONT else SIDE

    /**
     * 닫힌 Catmull-Rom 곡선을 3차 베지어 구간으로 바꾼다.
     * 반환: 구간마다 (시작점, 제어점1, 제어점2, 끝점)
     */
    fun bezierSegments(pts: List<Pair<Double, Double>>): List<List<Pair<Double, Double>>> {
        val n = pts.size
        return (0 until n).map { i ->
            val p0 = pts[(i - 1 + n) % n]; val p1 = pts[i]; val p2 = pts[(i + 1) % n]; val p3 = pts[(i + 2) % n]
            listOf(
                p1,
                p1.first + (p2.first - p0.first) / 6 to p1.second + (p2.second - p0.second) / 6,
                p2.first - (p3.first - p1.first) / 6 to p2.second - (p3.second - p1.second) / 6,
                p2,
            )
        }
    }
}
