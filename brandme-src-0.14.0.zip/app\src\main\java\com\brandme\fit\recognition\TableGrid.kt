package com.brandme.fit.recognition

import kotlin.math.abs

/**
 * 가로형 사이즈표를 "위치"로 이해한다.
 *
 * 글자 순서만 보고 값을 헤더에 끼워 맞추면, OCR 이 헤더 하나(예: "팔")를 놓치고 값 하나도 놓쳤을 때
 * 값이 옆 항목으로 밀려 들어가도 알 수 없다. 그래서 헤더 칸마다 가로 범위를 정하고,
 * 각 숫자는 자기 바로 위에 있는 헤더 칸에만 배정한다.
 *  - 한 칸에 값이 두 개 들어오면(헤더를 놓친 경우) "?" 로 표시
 *  - 칸이 비면 "?" 로 표시
 * "?" 는 숫자가 아니므로 파서가 그 표를 "읽지 못함"으로 처리한다. 추측으로 채우지 않는다.
 */
object TableGrid {

    const val UNKNOWN_CELL = "?"
    private val DECIMAL = Regex("""^\d{1,3}[.,]\d{1,2}$""")

    internal data class Token(val text: String, val left: Float, val right: Float) {
        val center: Float get() = (left + right) / 2
    }

    /**
     * 한 OCR 줄을 칸 단위 조각으로 나누고 가로 위치를 붙인다.
     * OCR 이 준 단어 위치가 있으면 그것을 쓰고(넓은 칸 간격도 정확), 없으면 글자 수 비율로 나눈다.
     */
    internal fun tokens(line: TextLine, split: (String) -> List<String>): List<Token> {
        val parts = split(line.text)
        if (parts.isEmpty()) return emptyList()
        fromWords(line.words, parts)?.let { return it }
        val total = parts.sumOf { it.length }.coerceAtLeast(1)
        var x = line.left.toFloat()
        return parts.map { p ->
            val w = (line.right - line.left) * p.length.toFloat() / total
            Token(p, x, x + w).also { x += w }
        }
    }

    /** 조각(예: "가슴단면")을 이루는 OCR 단어들("가슴", "단면")을 차례로 묶어 위치를 정한다. 맞지 않으면 null */
    private fun fromWords(words: List<TextLine>, parts: List<String>): List<Token>? {
        if (words.isEmpty()) return null
        val out = mutableListOf<Token>()
        var i = 0
        for (p in parts) {
            val target = p.filterNot { it.isWhitespace() }
            val start = i
            var acc = ""
            while (i < words.size && acc.length < target.length) acc += words[i++].text.filterNot { it.isWhitespace() }
            if (acc != target || i == start) return null
            out += Token(p, words[start].left.toFloat(), words[i - 1].right.toFloat())
        }
        return if (i == words.size) out else null
    }

    private fun words(s: String) = s.trim().split(Regex("""\s+""")).filter { it.isNotEmpty() }

    /**
     * 화면 줄들을 행 문자열로 만든다. 헤더 행(비교 항목 2개 이상)을 찾으면 그 아래 행들은
     * 헤더 칸 위치에 맞춰 "라벨\t값\t값…" 으로 재구성한다. 헤더가 없으면 null(호출자가 일반 행 사용).
     */
    /** 가로형 헤더: 비교 항목 이름이 2개 이상 */
    private fun isMeasureHeader(g: List<TextLine>) =
        SizeChartTextParser.recognizedItems(g.joinToString("\t") { it.text }).size >= 2

    /** 세로형 헤더: 사이즈 라벨이 2개 이상("사이즈 | M(95) | L(100) | …") */
    private fun sizeHeaderCells(g: List<TextLine>): List<Token>? {
        val toks = g.flatMap { tokens(it, SizeChartTextParser::cellTokens) }
        if (toks.isEmpty()) return null
        val lead = toks.first().text
        val hasLead = SizeChartTextParser.normalizeLabel(lead) == null
        if (hasLead && SizeChartTextParser.classifyHeader(lead) != SizeChartTextParser.Column.SIZE &&
            lead.lowercase().trim('(', ')') !in setOf("cm", "단위")
        ) return null
        val labels = if (hasLead) toks.drop(1) else toks
        if (labels.size < 2 || labels.any { SizeChartTextParser.normalizeLabel(it.text) == null }) return null
        // 숫자만 늘어선 값 행을 헤더로 오인하지 않도록, 숫자 라벨만 있으면 머리말("사이즈")을 요구한다.
        if (!hasLead && labels.all { it.text.first().isDigit() }) return null
        return toks
    }

    fun rows(lines: List<TextLine>): List<String>? {
        val groups = RowAssembler.groups(lines)
        // 설명 문장("어깨·가슴·총장 기준…")을 헤더로 오인하지 않도록, 바로 아래 두 줄 안에 숫자 행이 있는 헤더만 쓴다.
        fun numbersBelow(i: Int) = groups.drop(i + 1).take(2).any { g -> g.any { l -> l.text.any(Char::isDigit) } }
        var headerCells: List<Token>? = null
        var headerIndex = -1
        for (i in groups.indices) {
            if (!numbersBelow(i)) continue
            headerCells = when {
                isMeasureHeader(groups[i]) -> groups[i].flatMap { tokens(it, SizeChartTextParser::splitHeader) }
                else -> sizeHeaderCells(groups[i])
            }
            if (headerCells != null) { headerIndex = i; break }
        }
        if (headerCells == null || headerCells.size < 3) return null

        // 첫 칸이 머리말("사이즈", "cm")이 아니면 라벨/항목명 칸을 맨 왼쪽에 둔다.
        val first = headerCells.first()
        val hasLeadCell = SizeChartTextParser.classifyHeader(first.text) == SizeChartTextParser.Column.SIZE ||
            first.text.lowercase().trim('(', ')') in setOf("cm", "단위")
        val cells = if (hasLeadCell) {
            headerCells
        } else {
            val w = (first.right - first.left).coerceAtLeast(1f)
            listOf(Token("사이즈", first.left - w * 1.5f, first.left - w * 0.5f)) + headerCells
        }
        val bounds = cells.indices.map { i ->
            val l = if (i == 0) Float.NEGATIVE_INFINITY else (cells[i - 1].center + cells[i].center) / 2
            val r = if (i == cells.lastIndex) Float.POSITIVE_INFINITY else (cells[i].center + cells[i + 1].center) / 2
            l to r
        }

        val out = groups.take(headerIndex).map { g -> g.joinToString("\t") { it.text.trim() } }.toMutableList()
        out += cells.joinToString("\t") { it.text }
        groups.drop(headerIndex + 1).forEach { g ->
            val toks = g.flatMap { tokens(it, ::words) }
            val hasNumber = toks.any { t -> t.text.any { it.isDigit() } }
            if (!hasNumber) {
                out += g.joinToString("\t") { it.text.trim() }
                return@forEach
            }
            val slots = Array(cells.size) { mutableListOf<String>() }
            toks.forEach { t ->
                val i = bounds.indexOfFirst { (l, r) -> t.center >= l && t.center < r }.takeIf { it >= 0 }
                    ?: bounds.indices.minBy { abs(cells[it].center - t.center) }
                slots[i] += t.text
            }
            val row = slots.mapIndexed { i, s ->
                when {
                    i == 0 -> s.joinToString("").ifEmpty { UNKNOWN_CELL } // "1 번" 처럼 쪼개진 라벨은 붙인다
                    s.size == 1 -> s.single()
                    // OCR 이 소수점 뒤를 띄운 "76. 6" 은 한 값
                    DECIMAL.matches(s.joinToString("")) -> s.joinToString("")
                    else -> UNKNOWN_CELL // 비었거나(값 누락) 두 개(헤더 누락) — 어느 쪽이든 위치를 확신할 수 없다
                }
            }
            out += row.joinToString("\t")
        }
        return out
    }
}
