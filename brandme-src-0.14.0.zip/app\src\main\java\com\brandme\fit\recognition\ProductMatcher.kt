package com.brandme.fit.recognition

import com.brandme.fit.catalog.CatalogProduct
import com.brandme.fit.data.model.DetectedProduct
import com.brandme.fit.data.model.IdentificationStatus
import com.brandme.fit.data.model.ProductCandidate

/**
 * 화면 텍스트를 로컬 카탈로그와 대조한다.
 *
 * - EXACT_MATCH: 브랜드와 상품명이 모두 화면에 있고, 화면에 다른 상품 코드가 보이지 않을 때만.
 * - 브랜드/이름/코드가 서로 어긋나면 확정하지 않는다(CANDIDATE 또는 AMBIGUOUS).
 * - 비슷한 상품의 사이즈표를 대신 쓰지 않는다 — 후보는 사용자 선택 전까지 비교에 쓰지 않는다.
 */
class ProductMatcher(private val products: List<CatalogProduct>) {

    data class Match(
        val status: IdentificationStatus,
        val product: CatalogProduct?,
        val candidates: List<ProductCandidate>,
    ) {
        fun toDetected(): DetectedProduct = DetectedProduct(
            id = product?.id,
            brand = product?.brand,
            name = product?.name,
            shop = product?.shop,
            productCode = product?.productCode,
            status = status,
            candidates = candidates,
            isDemo = product?.isDemo ?: false,
        )
    }

    fun match(screenText: String): Match {
        val text = normalize(screenText)
        if (text.isEmpty()) return Match(IdentificationStatus.NOT_FOUND, null, emptyList())

        val codesOnScreen = products.mapNotNull { p -> p.productCode?.takeIf { text.contains(normalize(it)) } }.toSet()

        data class Scored(val p: CatalogProduct, val brand: Boolean, val name: Boolean, val tokenScore: Double, val codeConflict: Boolean)

        val scored = products.map { p ->
            val brandHit = text.contains(normalize(p.brand))
            val nameHit = text.contains(normalize(p.name))
            val tokens = p.name.split(' ').map { normalize(it) }.filter { it.length >= 2 }
            val tokenScore = if (tokens.isEmpty()) 0.0 else tokens.count { text.contains(it) }.toDouble() / tokens.size
            // 화면에 상품 코드가 보이는데 이 상품의 코드가 아니면 불일치로 본다.
            val codeConflict = codesOnScreen.isNotEmpty() && p.productCode !in codesOnScreen
            Scored(p, brandHit, nameHit, tokenScore, codeConflict)
        }

        fun Scored.toCandidate() = ProductCandidate(p.id, p.brand, p.name, p.shop,
            score = listOf(brand, name).count { it } * 0.25 + tokenScore * 0.5)

        val exact = scored.filter { it.brand && it.name && !it.codeConflict }
        if (exact.size == 1) {
            return Match(IdentificationStatus.EXACT_MATCH, exact.single().p, listOf(exact.single().toCandidate()))
        }
        if (exact.size > 1) {
            return Match(IdentificationStatus.AMBIGUOUS, null, exact.map { it.toCandidate() }.sortedByDescending { it.score })
        }

        val partial = scored.filter {
            (it.brand && it.tokenScore >= 0.5) || it.name || (it.brand && it.name && it.codeConflict)
        }.map { it.toCandidate() }.sortedByDescending { it.score }

        return when (partial.size) {
            0 -> Match(IdentificationStatus.NOT_FOUND, null, emptyList())
            1 -> Match(IdentificationStatus.CANDIDATE_MATCH, null, partial)
            else -> Match(IdentificationStatus.AMBIGUOUS, null, partial.take(5))
        }
    }

    companion object {
        fun normalize(s: String): String =
            s.lowercase().filter { it.isLetterOrDigit() }
    }
}
