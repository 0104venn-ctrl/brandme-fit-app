package com.brandme.fit.data.local

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.brandme.fit.BuildConfig
import com.brandme.fit.recognition.AnalysisMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore(name = "settings")

data class AppSettings(
    val onboardingDone: Boolean = false,
    val mode: AnalysisMode = AnalysisMode.DEMO,
    /** 외부 AI 서버로 화면 이미지를 보내는 것에 대한 명시적 동의. 기본값 false. */
    val aiConsent: Boolean = false,
    val serverUrl: String = BuildConfig.DEFAULT_AI_SERVER_URL,
    val bubbleX: Int = -1,
    val bubbleY: Int = -1,
)

class SettingsDataStore(private val context: Context) {
    private object Keys {
        val ONBOARDING = booleanPreferencesKey("onboarding_done")
        val MODE = stringPreferencesKey("analysis_mode")
        val AI_CONSENT = booleanPreferencesKey("ai_consent")
        val SERVER_URL = stringPreferencesKey("server_url")
        val BUBBLE_X = intPreferencesKey("bubble_x")
        val BUBBLE_Y = intPreferencesKey("bubble_y")
    }

    val settings: Flow<AppSettings> = context.settingsStore.data.map { it.toSettings() }

    suspend fun current(): AppSettings = settings.first()

    private fun Preferences.toSettings() = AppSettings(
        onboardingDone = this[Keys.ONBOARDING] ?: false,
        mode = this[Keys.MODE]?.let { runCatching { AnalysisMode.valueOf(it) }.getOrNull() } ?: AnalysisMode.DEMO,
        aiConsent = this[Keys.AI_CONSENT] ?: false,
        serverUrl = this[Keys.SERVER_URL] ?: BuildConfig.DEFAULT_AI_SERVER_URL,
        bubbleX = this[Keys.BUBBLE_X] ?: -1,
        bubbleY = this[Keys.BUBBLE_Y] ?: -1,
    )

    suspend fun setOnboardingDone() = context.settingsStore.edit { it[Keys.ONBOARDING] = true }

    suspend fun setMode(mode: AnalysisMode) = context.settingsStore.edit { it[Keys.MODE] = mode.name }

    suspend fun setAiConsent(consent: Boolean) = context.settingsStore.edit {
        it[Keys.AI_CONSENT] = consent
        // 동의를 철회하면 AI Mode 도 함께 끈다.
        if (!consent) it[Keys.MODE] = AnalysisMode.DEMO.name
    }

    suspend fun setServerUrl(url: String) = context.settingsStore.edit { it[Keys.SERVER_URL] = url.trim() }

    suspend fun setBubblePosition(x: Int, y: Int) = context.settingsStore.edit {
        it[Keys.BUBBLE_X] = x
        it[Keys.BUBBLE_Y] = y
    }

    suspend fun clearAll() = context.settingsStore.edit { it.clear() }
}
