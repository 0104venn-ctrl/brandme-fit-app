package com.brandme.fit.recognition

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TableColumnsTest {

    private val header = listOf(
        TextLine("사이즈", 100, 1000, 160, 1012),
        TextLine("1.어깨", 300, 1000, 340, 1012),
        TextLine("2가슴 3소매", 480, 1000, 720, 1012), // 두 헤더가 한 줄로 인식된 경우
        TextLine("7.총길이", 860, 1000, 920, 1012),
    )

    @Test fun `columns split merged header lines and cover the region`() {
        val cols = TableColumns.columns(header, 40, 1000)
        assertEquals(listOf("사이즈", "1.어깨", "2가슴", "3소매", "7.총길이"), cols.map { it.name })
        assertEquals(40, cols.first().left)
        assertEquals(1000, cols.last().right)
        cols.zipWithNext().forEach { (a, b) -> assertEquals(a.right, b.left) }
    }

    @Test fun `label column is added when header has no size cell`() {
        val cols = TableColumns.columns(header.drop(1), 40, 1000)
        assertEquals("사이즈", cols.first().name)
        assertEquals(5, cols.size)
    }

    @Test fun `cells are aligned to label rows and parsed`() {
        val cols = TableColumns.columns(header, 40, 1000)
        fun cell(text: String, x: Int, y: Int) = TextLine(text, x, y, x + 30, y + 12)
        val cells = listOf(
            listOf(cell("M(1번)", 110, 1040), cell("L(2번)", 110, 1080), cell("XL(3번)", 110, 1120)),
            listOf(cell("59", 310, 1041), cell("61", 310, 1079), cell("64", 310, 1121)),
            listOf(cell("60", 500, 1040), cell("63", 500, 1080), cell("66", 500, 1120)),
            listOf(cell("55", 650, 1039), cell("56", 650, 1080), cell("57", 650, 1120)),
            listOf(cell("68", 870, 1040), cell("69", 870, 1081), cell("70", 870, 1120)),
        )
        val rows = TableColumns.assemble(cols, cells).rows
        assertEquals("M(1번)\t59\t60\t55\t68", rows[1])
        val chart = (SizeChartTextParser.parse(rows) as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("M", "L", "XL"), chart.sizes.map { it.label })
        assertEquals(63.0, chart.sizes[1].measurements.chestFlatCm!!, 1e-9)
    }

    /** 실기기 0.2.2 결과: 표 선을 "-" 로 읽어 가슴 칸만 남은 채 M·L 만 결과가 나왔던 경우 */
    @Test fun `table line fragments are not empty cells and lost label rows are detected`() {
        val cols = TableColumns.columns(header, 40, 1000)
        fun cell(text: String, x: Int, y: Int) = TextLine(text, x, y, x + 30, y + 12)
        val cells = listOf(
            listOf(cell("M(1번)", 110, 1040), cell("L(2번)", 110, 1080)), // XL 라벨을 못 읽음
            listOf(cell("—", 310, 1040), cell("-", 310, 1080), cell("64", 310, 1120)),
            listOf(cell("60", 500, 1040), cell("63", 500, 1080), cell("66", 500, 1120)),
            listOf(cell("-", 650, 1040), cell("-", 650, 1080)),
            listOf(cell("|", 870, 1040), cell("-", 870, 1080)),
        )
        val assembled = TableColumns.assemble(cols, cells)
        assertEquals(2, assembled.orphanCells) // XL 행의 64, 66
        assertEquals("M(1번)\t60", assembled.rows[1])
        assertTrue(SizeChartTextParser.parse(assembled.rows) is SizeChartTextParser.Result.Unreadable)
    }

    @Test fun `missing cell leaves row unreadable instead of shifting values`() {
        val cols = TableColumns.columns(header, 40, 1000)
        fun cell(text: String, x: Int, y: Int) = TextLine(text, x, y, x + 30, y + 12)
        val cells = listOf(
            listOf(cell("M", 110, 1040)),
            listOf(cell("59", 310, 1040)),
            emptyList(), // 가슴 칸을 못 읽음
            listOf(cell("55", 650, 1040)),
            listOf(cell("68", 870, 1040)),
        )
        assertTrue(SizeChartTextParser.parse(TableColumns.assemble(cols, cells).rows) is SizeChartTextParser.Result.Unreadable)
    }
}
