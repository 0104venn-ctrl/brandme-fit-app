package com.brandme.fit.body3d

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PointF
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * 3D 몸 모형(과 입힌 옷)을 그리는 뷰. 손가락으로 좌우로 끌면 돌아가고, 손을 떼면 천천히 계속 돈다.
 * 기기 안에서만 그리며 아무것도 저장하거나 전송하지 않는다.
 */
class MannequinView(context: Context) : GLSurfaceView(context) {

    private val renderer = Renderer()
    private var lastX = 0f

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 4)
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    /** 치수 표시선 기준점의 화면 좌표(px) 콜백: 이름 → (+x 쪽, -x 쪽) */
    var onAnchorsProjected: ((Map<String, Pair<PointF, PointF>>) -> Unit)? = null

    fun setMesh(mesh: Mesh, heightCm: Float, anchors: Map<String, Pair<FloatArray, FloatArray>> = emptyMap()) {
        queueEvent { renderer.pendingBody = mesh; renderer.heightCm = heightCm; renderer.anchors = anchors; renderer.anchorsDirty = true }
    }

    /** 옷 메시와 정점별 색(rgb). null 이면 옷을 지운다. */
    fun setGarment(mesh: Mesh?, colors: FloatArray?) {
        queueEvent { renderer.pendingGarment = mesh to colors; renderer.garmentChanged = true }
    }

    fun setSkinColor(rgb: Int) {
        queueEvent { renderer.skin = floatArrayOf(((rgb shr 16) and 0xFF) / 255f, ((rgb shr 8) and 0xFF) / 255f, (rgb and 0xFF) / 255f) }
    }

    fun setAutoSpin(on: Boolean) { renderer.autoSpin = on; renderer.spinDefault = on }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = e.x; renderer.autoSpin = false; parent?.requestDisallowInterceptTouchEvent(true) }
            MotionEvent.ACTION_MOVE -> { val dx = e.x - lastX; lastX = e.x; queueEvent { renderer.yaw += dx * 0.5f } }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { renderer.autoSpin = renderer.spinDefault; parent?.requestDisallowInterceptTouchEvent(false) }
        }
        return true
    }

    /** GPU 에 올린 메시 하나 */
    private class GpuMesh {
        var vbo = 0; var ibo = 0; var cbo = 0; var count = 0; var hasColors = false

        fun create() {
            val b = IntArray(3)
            GLES20.glGenBuffers(3, b, 0)
            vbo = b[0]; ibo = b[1]; cbo = b[2]; count = 0
        }

        fun upload(mesh: Mesh, colors: FloatArray?) {
            val n = mesh.vertexCount
            val inter: FloatBuffer = ByteBuffer.allocateDirect(n * 24).order(ByteOrder.nativeOrder()).asFloatBuffer()
            for (i in 0 until n) { inter.put(mesh.positions, i * 3, 3); inter.put(mesh.normals, i * 3, 3) }
            inter.position(0)
            val idx: ShortBuffer = ByteBuffer.allocateDirect(mesh.indices.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
            mesh.indices.forEach { idx.put(it.toShort()) }
            idx.position(0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, n * 24, inter, GLES20.GL_STATIC_DRAW)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ibo)
            GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, mesh.indices.size * 2, idx, GLES20.GL_STATIC_DRAW)
            hasColors = colors != null && colors.size == n * 3
            if (hasColors) {
                val cb = ByteBuffer.allocateDirect(n * 12).order(ByteOrder.nativeOrder()).asFloatBuffer()
                cb.put(colors!!); cb.position(0)
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, cbo)
                GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, n * 12, cb, GLES20.GL_STATIC_DRAW)
            }
            count = mesh.indices.size
        }

        fun draw(program: Int) {
            if (count == 0) return
            val aPos = GLES20.glGetAttribLocation(program, "aPos")
            val aNormal = GLES20.glGetAttribLocation(program, "aNormal")
            val aColor = GLES20.glGetAttribLocation(program, "aColor")
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
            GLES20.glEnableVertexAttribArray(aPos)
            GLES20.glEnableVertexAttribArray(aNormal)
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 24, 0)
            GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, 24, 12)
            if (hasColors) {
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, cbo)
                GLES20.glEnableVertexAttribArray(aColor)
                GLES20.glVertexAttribPointer(aColor, 3, GLES20.GL_FLOAT, false, 12, 0)
            } else {
                GLES20.glDisableVertexAttribArray(aColor)
            }
            GLES20.glUniform1f(GLES20.glGetUniformLocation(program, "uUseColor"), if (hasColors) 1f else 0f)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ibo)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, count, GLES20.GL_UNSIGNED_SHORT, 0)
        }
    }

    private inner class Renderer : GLSurfaceView.Renderer {
        @Volatile var pendingBody: Mesh? = null
        @Volatile var pendingGarment: Pair<Mesh?, FloatArray?>? = null
        @Volatile var garmentChanged = false
        @Volatile var autoSpin = true
        @Volatile var spinDefault = true
        var heightCm = 170f
        var yaw = 20f
        var anchors: Map<String, Pair<FloatArray, FloatArray>> = emptyMap()
        var skin = floatArrayOf(0.93f, 0.93f, 0.95f)
        var anchorsDirty = false
        private var lastYaw = Float.NaN
        private var viewW = 1
        private var viewH = 1

        private var program = 0
        private val body = GpuMesh()
        private val garment = GpuMesh()
        private val proj = FloatArray(16)
        private val view = FloatArray(16)
        private val model = FloatArray(16)
        private val mvp = FloatArray(16)
        private val tmp = FloatArray(16)

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0.11f, 0.12f, 0.13f, 1f)
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            program = link(Shaders.VERTEX, Shaders.FRAGMENT)
            body.create(); garment.create()
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            GLES20.glViewport(0, 0, width, height)
            viewW = width; viewH = height; anchorsDirty = true
            Matrix.perspectiveM(proj, 0, 28f, width.toFloat() / height.coerceAtLeast(1), 10f, 2000f)
        }

        override fun onDrawFrame(gl: GL10?) {
            pendingBody?.let { body.upload(it, null); pendingBody = null }
            if (garmentChanged) {
                garmentChanged = false
                val (m, c) = pendingGarment ?: (null to null)
                if (m == null) garment.count = 0 else garment.upload(m, c)
            }
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            if (body.count == 0) return
            if (autoSpin) yaw += 0.35f

            val h = heightCm
            Matrix.setLookAtM(view, 0, 0f, h * 0.55f, h * 2.25f, 0f, h * 0.5f, 0f, 0f, 1f, 0f)
            Matrix.setIdentityM(model, 0)
            Matrix.rotateM(model, 0, yaw, 0f, 1f, 0f)
            Matrix.multiplyMM(tmp, 0, view, 0, model, 0)
            Matrix.multiplyMM(mvp, 0, proj, 0, tmp, 0)

            GLES20.glUseProgram(program)
            GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program, "uMvp"), 1, false, mvp, 0)
            GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program, "uModel"), 1, false, model, 0)
            GLES20.glUniform3f(GLES20.glGetUniformLocation(program, "uEye"), 0f, h * 0.55f, h * 2.25f)
            GLES20.glUniform3f(GLES20.glGetUniformLocation(program, "uBase"), skin[0], skin[1], skin[2])

            // 몸을 살짝 뒤로 밀어 그려, 몸에 딱 붙은 옷이 몸 표면과 겹쳐 깜빡이지 않게 한다
            GLES20.glEnable(GLES20.GL_POLYGON_OFFSET_FILL)
            GLES20.glPolygonOffset(2f, 4f)
            body.draw(program)
            GLES20.glDisable(GLES20.GL_POLYGON_OFFSET_FILL)
            garment.draw(program)

            val cb = onAnchorsProjected
            if (cb != null && anchors.isNotEmpty() && (anchorsDirty || yaw != lastYaw)) {
                anchorsDirty = false; lastYaw = yaw
                val v = FloatArray(4); val out = FloatArray(4)
                fun project(p: FloatArray): PointF {
                    v[0] = p[0]; v[1] = p[1]; v[2] = p[2]; v[3] = 1f
                    Matrix.multiplyMV(out, 0, mvp, 0, v, 0)
                    return PointF((out[0] / out[3] + 1f) / 2f * viewW, (1f - out[1] / out[3]) / 2f * viewH)
                }
                val projected = anchors.mapValues { (_, pair) -> project(pair.first) to project(pair.second) }
                post { cb(projected) }
            }
        }

        private fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            return s
        }

        private fun link(vs: String, fs: String): Int {
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(p)
            return p
        }
    }
}

private object Shaders {
    const val VERTEX = """
        uniform mat4 uMvp;
        uniform mat4 uModel;
        attribute vec3 aPos;
        attribute vec3 aNormal;
        attribute vec3 aColor;
        varying vec3 vNormal;
        varying vec3 vWorld;
        varying vec3 vColor;
        void main() {
            vNormal = mat3(uModel) * aNormal;
            vWorld = (uModel * vec4(aPos, 1.0)).xyz;
            vColor = aColor;
            gl_Position = uMvp * vec4(aPos, 1.0);
        }
    """
    const val FRAGMENT = """
        precision mediump float;
        uniform vec3 uEye;
        uniform vec3 uBase;
        uniform float uUseColor;
        varying vec3 vNormal;
        varying vec3 vWorld;
        varying vec3 vColor;
        void main() {
            vec3 v = normalize(uEye - vWorld);
            vec3 n = normalize(vNormal);
            if (dot(n, v) < 0.0) n = -n;
            vec3 key = normalize(vec3(0.5, 0.8, 0.9));
            vec3 fill = normalize(vec3(-0.7, 0.2, 0.4));
            float diff = max(dot(n, key), 0.0) * 0.75 + max(dot(n, fill), 0.0) * 0.25;
            float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0) * 0.25;
            vec3 h = normalize(key + v);
            float spec = pow(max(dot(n, h), 0.0), 40.0) * 0.12;
            vec3 base = mix(uBase, vColor, uUseColor);
            gl_FragColor = vec4(base * (0.28 + diff) + vec3(rim + spec), 1.0);
        }
    """
}
