package com.brandme.fit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.brandme.fit.ui.body.BodyProfileScreen
import com.brandme.fit.ui.home.HomeScreen
import com.brandme.fit.ui.home.PrivacyScreen
import com.brandme.fit.ui.onboarding.OnboardingScreen
import com.brandme.fit.ui.onboarding.SplashScreen
import com.brandme.fit.ui.theme.BrandmeTheme

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val BODY = "body"
    const val HOME = "home"
    const val PRIVACY = "privacy"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BrandmeTheme {
                val nav = rememberNavController()
                fun go(route: String) = nav.navigate(route) { popUpTo(0) { inclusive = true } }
                NavHost(navController = nav, startDestination = Routes.SPLASH) {
                    composable(Routes.SPLASH) { SplashScreen(onResolved = ::go) }
                    composable(Routes.ONBOARDING) { OnboardingScreen(onStart = { go(Routes.BODY) }) }
                    composable(Routes.BODY) {
                        BodyProfileScreen(
                            onSaved = { if (nav.previousBackStackEntry != null) nav.popBackStack() else go(Routes.HOME) },
                            onBack = if (nav.previousBackStackEntry != null) ({ nav.popBackStack() }) else null,
                        )
                    }
                    composable(Routes.HOME) {
                        HomeScreen(
                            onEditBody = { nav.navigate(Routes.BODY) },
                            onPrivacy = { nav.navigate(Routes.PRIVACY) },
                        )
                    }
                    composable(Routes.PRIVACY) {
                        PrivacyScreen(onBack = { nav.popBackStack() }, onAllDeleted = { go(Routes.ONBOARDING) })
                    }
                }
            }
        }
    }
}
