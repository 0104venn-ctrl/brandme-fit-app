package com.brandme.fit.recognition

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 실기기 캡처(SIZE / 어깨 / 가슴 / 팔 / 암홀 / 총기장 표)를 좌표까지 재현한 테스트 */
class TableGridTest {

    /** 칸 중심 x 좌표: 사이즈, 어깨, 가슴, 팔, 암홀, 총기장 */
    private val xs = listOf(80, 230, 380, 530, 680, 830)

    private fun word(text: String, cx: Int, y: Int) = TextLine(text, cx - 20, y, cx + 20, y + 14)

    /** 칸마다 OCR 줄이 따로 나온 경우 */
    private fun row(y: Int, vararg cells: Pair<Int, String>) = cells.map { (col, t) -> word(t, xs[col], y) }

    /** 한 줄로 합쳐 나왔지만 단어 위치가 있는 경우 */
    private fun mergedLine(y: Int, vararg cells: Pair<Int, String>): TextLine {
        val words = cells.map { (col, t) -> word(t, xs[col], y) }
        return TextLine(words.joinToString(" ") { it.text }, words.first().left, y, words.last().right, y + 14, words)
    }

    @Test fun `values are mapped to the header above them`() {
        val lines = row(100, 0 to "SIZE", 1 to "어깨", 2 to "가슴", 3 to "팔", 4 to "암홀", 5 to "종기장") +
            mergedLine(140, 0 to "FREE", 1 to "58", 2 to "62", 3 to "57", 4 to "24", 5 to "70") +
            row(180, 0 to "1번", 1 to "62", 2 to "67", 3 to "63", 4 to "28", 5 to "74") +
            word("- 위의 실측 사이즈는 '단면의 길이'입니다.", 400, 230)
        val rows = TableGrid.rows(lines)!!
        val chart = (SizeChartTextParser.parse(rows) as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("FREE", "1번"), chart.sizes.map { it.label })
        val free = chart.sizes[0].measurements
        assertEquals(58.0, free.shoulderCm!!, 1e-9)
        assertEquals(62.0, free.chestFlatCm!!, 1e-9)
        assertEquals(57.0, free.sleeveCm!!, 1e-9)
        assertEquals(70.0, free.lengthCm!!, 1e-9) // 암홀 24 는 비교하지 않음
        assertEquals(74.0, chart.sizes[1].measurements.lengthCm!!, 1e-9)
    }

    /** 실기기 1차 OCR: 헤더 "팔"을 놓쳤다. 순서만 보면 57 이 암홀로 밀려 들어갈 수 있지만 위치로 보면 칸이 겹친다. */
    @Test fun `missing header makes the table unreadable instead of shifting values`() {
        val lines = row(100, 0 to "SIZE", 1 to "어깨", 2 to "가슴", 4 to "암홀", 5 to "총기장") +
            mergedLine(140, 0 to "FREE", 1 to "58", 2 to "62", 3 to "57", 4 to "24", 5 to "70") +
            row(180, 0 to "1번", 1 to "62", 2 to "67", 3 to "63", 4 to "28", 5 to "74")
        val rows = TableGrid.rows(lines)!!
        assertTrue(rows.any { TableGrid.UNKNOWN_CELL in it.split("\t") })
        assertTrue(SizeChartTextParser.parse(rows) is SizeChartTextParser.Result.Unreadable)
    }

    /** 헤더 누락 + 같은 행의 값도 누락: 개수는 맞아 보여도 위치가 어긋나므로 읽지 않는다 */
    @Test fun `missing header and missing value do not silently realign`() {
        val lines = row(100, 0 to "SIZE", 1 to "어깨", 2 to "가슴", 4 to "암홀", 5 to "총기장") +
            row(140, 0 to "FREE", 1 to "58", 3 to "57", 4 to "24", 5 to "70")
        val r = SizeChartTextParser.parse(TableGrid.rows(lines)!!)
        assertTrue(r is SizeChartTextParser.Result.Unreadable)
    }

    @Test fun `description line with measure words is not used as header`() {
        val lines = listOf(word("어깨 가슴 총장 기준으로 측정", 300, 40), word("상세 설명", 300, 70)) +
            row(100, 0 to "사이즈", 1 to "어깨", 2 to "가슴", 5 to "총장") +
            row(140, 0 to "M", 1 to "46", 2 to "52", 5 to "70")
        val chart = (SizeChartTextParser.parse(TableGrid.rows(lines)!!) as SizeChartTextParser.Result.Found).chart
        assertEquals(70.0, chart.sizes.single().measurements.lengthCm!!, 1e-9)
    }

    /** 실기기 캡처: 세로형 표(위에 사이즈, 왼쪽에 항목). OCR 이 "L(100)"을 "니100)", "XXL(110)"을 "XXL(11o)"로 읽음 */
    @Test fun `vertical table from real capture`() {
        val cols = listOf(80, 230, 380, 530, 680)
        fun r(y: Int, vararg t: String) = t.mapIndexed { i, s -> word(s, cols[i], y) }
        val lines = listOf(word("실측사이", 60, 20), word("단위 : Cm", 60, 50)) +
            r(100, "사이즈", "M(95)", "니100)", "XL(105)", "XXL(11o)") +
            r(140, "가슴둘레", "111", "116", "121", "126") +
            r(180, "밑단둘레", "107", "112", "117", "122") +
            r(220, "소매길이", "63", "64", "65", "66") +
            r(260, "소매통", "45.5", "47", "48.5", "50") +
            r(300, "소매밑단너비", "20", "21", "22", "23") +
            r(340, "어깨너비", "46.5", "48", "49.5", "51") +
            r(380, "총기장", "67.5", "69", "70.5", "72") +
            word("* 사이즈는 측정 방법과 생산 과정에 따라 약간의 오차가 발생할", 300, 430)
        val chart = (SizeChartTextParser.parse(TableGrid.rows(lines)!!) as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("M(95)", "L(100)", "XL(105)", "XXL(110)"), chart.sizes.map { it.label })
        val l = chart.sizes[1].measurements
        assertEquals(48.0, l.shoulderCm!!, 1e-9)
        assertEquals(116.0, l.chestCircumferenceCm!!, 1e-9)
        assertEquals(null, l.chestFlatCm) // 둘레를 단면으로 바꾸지 않는다
        assertEquals(64.0, l.sleeveCm!!, 1e-9)
        assertEquals(69.0, l.lengthCm!!, 1e-9)
        assertEquals(72.0, chart.sizes[3].measurements.lengthCm!!, 1e-9)
    }

    @Test fun `vertical table with a missing value is unreadable`() {
        val cols = listOf(80, 230, 380, 530)
        fun r(y: Int, vararg t: Pair<Int, String>) = t.map { (i, s) -> word(s, cols[i], y) }
        val lines = r(100, 0 to "사이즈", 1 to "M", 2 to "L", 3 to "XL") +
            r(140, 0 to "어깨", 1 to "46", 3 to "50") + // L 값 누락 — 순서로 맞추면 50 이 L 로 밀린다
            r(180, 0 to "총장", 1 to "68", 2 to "70", 3 to "72")
        assertTrue(SizeChartTextParser.parse(TableGrid.rows(lines)!!) is SizeChartTextParser.Result.Unreadable)
    }

    @Test fun `no header gives null`() {
        assertEquals(null, TableGrid.rows(listOf(word("무료배송", 100, 10))))
    }
}
