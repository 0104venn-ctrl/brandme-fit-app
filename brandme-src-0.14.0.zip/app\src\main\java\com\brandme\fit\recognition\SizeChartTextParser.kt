package com.brandme.fit.recognition

import com.brandme.fit.data.model.ChestMeasureMethod
import com.brandme.fit.data.model.MeasureItem
import com.brandme.fit.data.model.Measurements
import com.brandme.fit.data.model.MeasurementRules
import com.brandme.fit.data.model.ProductSize
import com.brandme.fit.data.model.SizeChart
import com.brandme.fit.data.model.SizeChartSource
import com.brandme.fit.data.model.VerificationStatus

/**
 * 화면 텍스트(행 단위)에서 상의 실측 사이즈표를 찾는다.
 *
 * 지원하는 배치:
 *  1) 가로형: 헤더 행에 항목명(어깨/가슴/총장/소매), 아래 행마다 "사이즈 값 값 …"
 *  2) 세로형: 헤더 행에 사이즈 라벨(S M L), 아래 행마다 "항목명 값 값 …"
 *  3) 한 줄형: "M 어깨 46 가슴 52 총장 70" / "M : 어깨너비46 / 가슴단면52"
 *
 * 컬럼명 휴리스틱:
 *  - 어깨 / 가슴단면 / 총장 / 소매 를 인식
 *  - 소매밑단, 밑단, 소매통, 암홀, 허리, 밑위, 허벅지, 화장 등과 알 수 없는 항목은 비교하지 않고 건너뜀
 *    (값 개수가 헤더와 정확히 맞을 때만 위치로 건너뛰므로 다른 칸의 값을 끌어오지 않는다)
 *  - "가슴둘레"는 단면과 별개 항목(CHEST_CIRCUMFERENCE)으로 둔다
 * 값을 추측하지 않는다. 행/열이 맞지 않으면 Unreadable 로 돌려준다.
 */
object SizeChartTextParser {

    sealed interface Result {
        data class Found(val chart: SizeChart) : Result
        /** 표로 보이는 헤더가 없음 */
        data object NotFound : Result
        /** 표 헤더는 있지만 값을 정확히 읽지 못함 */
        data class Unreadable(val reason: String) : Result
        /** 같은 사이즈에 서로 다른 값 */
        data class Conflicting(val sizeLabel: String) : Result
    }

    enum class Column(val label: String) {
        SIZE("사이즈"), IGNORE("제외"), SHOULDER("어깨"), CHEST_FLAT("가슴 단면"),
        CHEST_CIRC("가슴 둘레"), LENGTH("총장"), SLEEVE("소매"),
        /** 바스트: 둘레인지 단면인지 값으로 판단해야 함 */
        BUST("바스트"),
        /** 하의 전용 항목(엉덩이, 밑위, 허벅지 …) */
        BOTTOM("하의 항목"),
    }

    /** OCR 결과의 보이지 않는 문자(줄바꿈 없는 공백, 폭 없는 공백 등)와 한글 조합 차이를 없앤다 */
    private val INVISIBLE = Regex("""[\s\p{Z}\p{Cf}]""")

    private fun normalizeText(raw: String): String =
        java.text.Normalizer.normalize(raw, java.text.Normalizer.Form.NFC).replace(INVISIBLE, "")

    private val MEASURE_COLUMNS = setOf(Column.SHOULDER, Column.CHEST_FLAT, Column.CHEST_CIRC, Column.LENGTH, Column.SLEEVE)

    private val PARENTHETICAL = Regex("""^\(.{1,8}\)$""")

    /** 앞 토큰에 붙여 읽어야 하는 수식어 (예: "가슴 둘레", "소매 밑단", "어깨 너비") */
    private val MODIFIERS = setOf("너비", "넓이", "단면", "길이", "기장", "둘레", "밑단", "통", "폭", "단", "length")

    private val SIZE_LABEL = Regex(
        """^(XXS|XS|S|M|L|XL|XXL|XXXL|[2-5]XL|FREE|F|FREESIZE|ONESIZE|OS|프리|\d{1,3}|\d{1,2}호|\d{1,2}번)(\([A-Z0-9~\-]{1,9}\))?$""",
    )
    private val NUMBER = Regex("""^\d{1,3}([.,]\d{1,2})?$""")
    /** 깨진 사이즈 라벨로 보이는 짧은 조각("3번)", "X3", "?") */
    private val DAMAGED_LABEL = Regex("""^[(\[]?[A-Za-z0-9]{0,4}(번|호)?[)\]]?$|^\?$""")
    /** 값이 없는 칸 */
    private val EMPTY_CELL = setOf("-", "–", "—", "x", "X")
    private val INCH = Regex("""\b(inch|inches)\b|인치""", RegexOption.IGNORE_CASE)
    private val KEY_VALUE = Regex("""([가-힣A-Za-z]+(?:\s?[가-힣]+)?)\s*[:：]?\s*(\d{1,3}(?:[.,]\d{1,2})?)\s*(?:cm)?""")

    /**
     * 항목명 → 항목. [SizeTerms] 사전에 있는 이름만 인정한다(글자 포함 여부로 추측하지 않음).
     * 사전에 없으면 OCR 오타 보정을 시도하고, 그래도 없으면 null(모르는 항목).
     */
    fun classifyHeader(raw: String): Column? {
        val h = SizeTerms.normalize(raw)
        if (h.isEmpty()) return null
        SizeTerms.TERMS[h]?.let { return it }
        return fuzzyHeader(h)
    }

    /**
     * OCR 이 헤더 글자를 조금 틀리게 읽은 경우("어개"→어깨, "층걸이"→총길이)를 자모 단위 편집 거리로 보정한다.
     * 사전 단어 중 가장 가까운 것이 한 종류의 항목일 때만, 첫 자음이 같고 거리가 충분히 작으면 인정한다.
     */
    private fun fuzzyHeader(h: String): Column? {
        if (h.length !in 2..7 || h.any { it !in '가'..'힣' }) return null
        val src = jamo(h)
        // 보정 허용 조건을 먼저 거른 뒤 가장 가까운 단어를 고른다(첫 자음이 다른 단어가 더 가깝다고 이기지 않도록)
        val candidates = SizeTerms.TERMS.filterKeys { k -> k.all { it in '가'..'힣' } }.mapNotNull { (name, col) ->
            val target = jamo(name)
            val d = editDistance(src, target)
            val ok = d <= 1 || (d <= 3 && d <= target.size * 0.45 && src.first() == target.first())
            if (ok) Triple(name, col, d) else null
        }
        if (candidates.isEmpty()) return null
        val best = candidates.minOf { it.third }
        val winners = candidates.filter { it.third == best }
        return winners.map { it.second }.distinct().singleOrNull()
    }

    private fun jamo(s: String): List<Int> = s.flatMap { c ->
        if (c in '가'..'힣') {
            val i = c - '가'
            listOfNotNull(i / 588, 100 + (i % 588) / 28, (i % 28).takeIf { it > 0 }?.plus(200))
        } else listOf(c.code + 1000)
    }

    private fun editDistance(a: List<Int>, b: List<Int>): Int {
        var prev = IntArray(b.size + 1) { it }
        for (i in 1..a.size) {
            val cur = IntArray(b.size + 1)
            cur[0] = i
            for (j in 1..b.size) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.size]
    }

    private fun rawTokens(row: String): List<String> {
        val clean = java.text.Normalizer.normalize(row, java.text.Normalizer.Form.NFC).replace(Regex("""\p{Cf}"""), "")
        val tokens = clean.split('\t', '|').flatMap { it.trim().split(Regex("""[\s\p{Z}]+""")) }.map { it.trim() }.filter { it.isNotEmpty() }
        val out = mutableListOf<String>()
        tokens.forEach { t ->
            val prev = out.lastOrNull()
            when {
                // "FREE SIZE", "ONE SIZE" 는 한 라벨
                (prev?.uppercase() == "FREE" || prev?.uppercase() == "ONE") && t.uppercase() == "SIZE" ->
                    out[out.size - 1] = prev.uppercase() + "SIZE"
                // "XL (95)", "체중 (kg)" — 괄호 부분은 앞 칸에 붙인다
                prev != null && PARENTHETICAL.matches(t) && !PARENTHETICAL.matches(prev) -> out[out.size - 1] = prev + t
                // OCR 이 소수점 뒤에 공백을 넣은 경우: "76. 6" → "76.6"
                prev != null && Regex("""^\d{1,3}\.$""").matches(prev) && Regex("""^\d{1,2}$""").matches(t) -> out[out.size - 1] = prev + t
                else -> out += t
            }
        }
        return out
    }

    /** 헤더 행을 컬럼 이름 단위로 나눈다. 수식어는 앞 토큰과 합친다. */
    fun splitHeader(row: String): List<String> {
        val out = mutableListOf<String>()
        rawTokens(row).forEach { t ->
            val prev = out.lastOrNull()
            val merge = prev != null && (
                // "사이즈 표"
                (classifyHeader(prev) == Column.SIZE && classifyHeader(prev + t) == Column.SIZE) ||
                    (classifyHeader(prev) != Column.SIZE &&
                        (t.lowercase() in MODIFIERS || (classifyHeader(prev) == null && isWordFragment(prev) && classifyHeader(prev + t) != null)))
                )
            if (merge) out[out.size - 1] = prev + t else out += t
        }
        return out
    }

    /** OCR 이 단어를 쪼갠 조각("총" + "장")만 앞에 붙인다. 기호·숫자나 긴 단어는 별도 컬럼으로 둔다. */
    private fun isWordFragment(s: String) = s.length <= 2 && s.all { it in '가'..'힣' }

    private fun splitData(row: String): List<String> =
        rawTokens(row).map { it.removeSuffix("cm").removeSuffix("CM") }.filter { it.isNotEmpty() }

    /** "M(1번)", "L2번" 처럼 옵션 번호가 붙은 라벨 */
    private val NUMBERED_OPTION = Regex("""^([A-Z0-9]+)\(?\d{1,2}번\)?$""")

    fun normalizeLabel(raw: String): String? {
        // 숫자 옆의 O 는 0 (OCR 이 "11O" 처럼 읽음)
        val l = normalizeText(raw).uppercase().replace(Regex("""(?<=\d)O|O(?=\d)"""), "0")
        if (SIZE_LABEL.matches(l)) return l
        NUMBERED_OPTION.matchEntire(l)?.groupValues?.get(1)?.let { base -> return base.takeIf { SIZE_LABEL.matches(it) } }
        return repairLabel(l)?.takeIf { SIZE_LABEL.matches(it) }
    }

    /**
     * OCR 이 사이즈 라벨 글자를 흔히 틀리는 경우만 고친다.
     *  - "니100)" → "L(100)" (L 과 괄호를 한글 '니'로 읽음)
     *  - "XXL(11O)" → "XXL(110)" (숫자 사이의 O 를 0 으로)
     *  - "L100)" / "L(100" → "L(100)" (괄호 한쪽 누락)
     */
    private fun repairLabel(l: String): String? {
        var s = l.replace(Regex("""^니"""), "L(").replace(Regex("""^ㄴ"""), "L")
        s = s.replace(Regex("""(?<=\d)O|O(?=\d)"""), "0")
        s = Regex("""^([A-Z]{1,4})(\d{2,3})\)$""").replace(s, "$1($2)")
        s = Regex("""^([A-Z]{1,4})\((\d{2,3})$""").replace(s, "$1($2)")
        return s.takeIf { it != l }
    }

    /** 표 칸 단위로 나눈 조각("XL (95)" → "XL(95)", "76. 6" → "76.6") */
    fun cellTokens(row: String): List<String> = rawTokens(row)

    private fun parseValue(text: String): Double? = text.replace(',', '.').toDoubleOrNull()

    private fun Measurements.with(col: Column, v: Double?): Measurements = when (col) {
        Column.SHOULDER -> copy(shoulderCm = v)
        Column.CHEST_FLAT -> copy(chestFlatCm = v)
        Column.CHEST_CIRC -> copy(chestCircumferenceCm = v)
        Column.LENGTH -> copy(lengthCm = v)
        Column.SLEEVE -> copy(sleeveCm = v)
        Column.SIZE, Column.IGNORE, Column.BUST, Column.BOTTOM -> this
    }

    /**
     * 표 후보를 위에서부터 차례로 시도한다. 하나라도 읽히면 그것을 쓰고,
     * 모두 실패하면 가장 구체적인 실패(값 충돌 > 읽지 못함 > 없음)를 돌려준다.
     */
    fun parse(rows: List<String>, source: SizeChartSource = SizeChartSource.SCREEN_CAPTURE): Result {
        var failure: Result = Result.NotFound
        fun rank(r: Result) = when (r) { is Result.Conflicting -> 2; is Result.Unreadable -> 1; else -> 0 }
        fun remember(r: Result) { if (rank(r) > rank(failure)) failure = r }
        for (index in rows.indices) {
            for (attempt in listOf(::parseRowHeader, ::parseColumnHeader)) {
                when (val r = attempt(rows, index)) {
                    null -> Unit
                    is Result.Found -> return r.withSource(source)
                    else -> remember(r)
                }
            }
        }
        val inline = parseInline(rows)
        if (inline is Result.Found) return inline.withSource(source)
        remember(inline)
        return failure
    }

    private fun Result.Found.withSource(source: SizeChartSource) = copy(chart = chart.copy(source = source))

    /** 가로형: 항목명 헤더 + 사이즈별 행. 헤더가 아니면 null */
    private fun parseRowHeader(rows: List<String>, index: Int): Result? {
        val row = rows[index]
        val columns = splitHeader(row).map { classifyHeader(it) }
        if (columns.count { it in MEASURE_COLUMNS } < 2) return null
        if (INCH.containsMatchIn(row)) return Result.Unreadable("cm 단위가 아닌 표(인치)")

        // 첫 칸이 사이즈 라벨 컬럼("사이즈", "(cm)", 빈칸 등)이면 제외한다. 없으면 라벨이 각 행 맨 앞에 있다고 본다.
        val names = splitHeader(row)
        val dropFirst = columns.first() == null || columns.first() == Column.SIZE
        val headerNames = if (dropFirst) names.drop(1) else names
        // 사전에 없는 항목명은 비교에서 빼고 결과에 알린다(값은 위치대로 건너뛰므로 다른 칸으로 밀리지 않는다).
        val skipped = mutableListOf<String>()
        val headerColumns: List<Column> = (if (dropFirst) columns.drop(1) else columns).mapIndexed { i, c ->
            c ?: Column.IGNORE.also { skipped += headerNames[i] }
        }
        if (Column.SIZE in headerColumns) return Result.Unreadable("헤더 구조를 알 수 없음")
        bottomTable(headerColumns)?.let { return it }
        headerColumns.forEachIndexed { i, c -> if (c == Column.BUST) skipped += "${headerNames[i]}(둘레/단면 구분 불가)" }

        val sizes = linkedMapOf<String, Measurements>()
        for (dataRow in rows.drop(index + 1)) {
            val cells = splitData(dataRow)
            if (cells.isEmpty()) continue
            val label = normalizeLabel(cells.first())
            if (label == null) {
                // 숫자가 여러 개 있는데 라벨을 못 읽은 행: 표의 한 행을 잃은 것이므로 일부 사이즈만으로 결과를 내지 않는다.
                val numbers = cells.count { NUMBER.matches(it) }
                val damagedLabel = DAMAGED_LABEL.matches(cells.first())
                if (numbers >= 2 || (sizes.isNotEmpty() && numbers >= 1 && damagedLabel)) {
                    return Result.Unreadable("사이즈 라벨을 읽지 못한 행이 있음")
                }
                if (sizes.isNotEmpty()) break // 표가 끝남
                continue // 두 줄 헤더의 둘째 줄 등
            }
            val values = cells.drop(1)
            // 비교하지 않는 칸(체중 "65-75" 등)은 형식을 따지지 않고 개수만 맞춘다.
            // "?" 는 위치로 칸을 맞출 때 값이 겹치거나 빈 칸(TableGrid). 비교하지 않는 칸이라도 표 구조가 어긋났다는 뜻이다.
            if (values.size != headerColumns.size || TableGrid.UNKNOWN_CELL in values ||
                headerColumns.zip(values).any { (col, v) -> col in MEASURE_COLUMNS && !NUMBER.matches(v) && v !in EMPTY_CELL }
            ) {
                return Result.Unreadable("$label 행의 값 개수/형식이 헤더와 다름")
            }
            // 빈 칸("-")은 한 행에 하나까지만 인정한다. 그보다 많으면 OCR 이 표 선을 값으로 읽었을 가능성이 크다.
            if (headerColumns.zip(values).count { (col, v) -> col in MEASURE_COLUMNS && v in EMPTY_CELL } > 1) {
                return Result.Unreadable("$label 행에 빈 칸이 많음")
            }
            var m = Measurements()
            headerColumns.zip(values).forEach { (col, text) -> m = m.with(col, parseValue(text)) }
            val r = addSize(sizes, label, m)
            if (r != null) return r
        }
        if (sizes.isEmpty()) return Result.Unreadable("헤더는 있으나 사이즈 행이 없음")
        return found(sizes, headerColumns, skipped)
    }

    /** 세로형: 사이즈 라벨 헤더 + 항목별 행. 헤더가 아니면 null */
    private fun parseColumnHeader(rows: List<String>, index: Int): Result? {
        val tokens = splitData(rows[index])
        if (tokens.isEmpty()) return null
        val lead = tokens.first()
        val hasLead = normalizeLabel(lead) == null
        if (hasLead && classifyHeader(lead) != Column.SIZE && lead.lowercase().trim('(', ')') != "cm") return null
        val labels = (if (hasLead) tokens.drop(1) else tokens).map { normalizeLabel(it) ?: return null }
        if (labels.size < 2 || labels.toSet().size != labels.size) return null
        // 숫자만 늘어선 행(값 행)을 사이즈 헤더로 오인하지 않도록, 숫자 라벨만 있으면 "사이즈" 같은 머리말을 요구한다.
        if (!hasLead && labels.all { it.first().isDigit() }) return null

        val perSize = labels.map { Measurements() }.toMutableList()
        val usedColumns = mutableListOf<Column>()
        val seenColumns = mutableListOf<Column>()
        val skipped = mutableListOf<String>()
        for (dataRow in rows.drop(index + 1)) {
            val cells = splitData(dataRow)
            if (cells.isEmpty()) continue
            val nameTokens = cells.takeWhile { !it.first().isDigit() && it !in EMPTY_CELL }
            val values = cells.drop(nameTokens.size)
            val name = nameTokens.joinToString("")
            val col = classifyHeader(name)
            // 사전에 없는 이름이지만 사이즈 수만큼 숫자가 있는 줄: 표의 한 줄이므로 비교에서 빼고 알린다
            val tableRow = values.size == labels.size && values.all { NUMBER.matches(it) || it in EMPTY_CELL }
            if (nameTokens.isNotEmpty() && col == null && tableRow) { skipped += name; continue }
            if (nameTokens.isEmpty() || col == null || col == Column.SIZE) {
                if (usedColumns.isNotEmpty()) break
                continue
            }
            seenColumns += col
            if (col == Column.BUST) { skipped += "$name(둘레/단면 구분 불가)"; continue }
            if (col == Column.IGNORE || col == Column.BOTTOM) continue
            if (INCH.containsMatchIn(dataRow)) return Result.Unreadable("cm 단위가 아닌 표(인치)")
            if (values.size != labels.size || values.any { !NUMBER.matches(it) && it !in EMPTY_CELL }) {
                return Result.Unreadable("$name 행의 값 개수/형식이 사이즈 헤더와 다름")
            }
            if (col in usedColumns) return Result.Conflicting(labels.first())
            usedColumns += col
            values.forEachIndexed { i, text -> perSize[i] = perSize[i].with(col, parseValue(text)) }
        }
        bottomTable(seenColumns)?.let { return it }
        if (usedColumns.count { it in MEASURE_COLUMNS } < 2) {
            return if (usedColumns.isEmpty()) null else Result.Unreadable("사이즈 헤더 아래 비교 항목이 부족함")
        }
        val sizes = linkedMapOf<String, Measurements>()
        labels.zip(perSize).forEach { (label, m) -> addSize(sizes, label, m)?.let { return it } }
        return found(sizes, usedColumns, skipped)
    }

    /** 한 줄형: "M 어깨 46 가슴 52 총장 70" */
    private fun parseInline(rows: List<String>): Result {
        val sizes = linkedMapOf<String, Measurements>()
        val usedColumns = mutableSetOf<Column>()
        for (row in rows) {
            val text = row.replace('\t', ' ').trim()
            val first = text.split(Regex("""[\s:：/]+"""), limit = 2)
            if (first.size < 2) continue
            val label = normalizeLabel(first[0]) ?: continue
            var m = Measurements()
            var count = 0
            for (match in KEY_VALUE.findAll(first[1])) {
                val col = classifyHeader(match.groupValues[1]) ?: continue
                if (col !in MEASURE_COLUMNS) continue
                if (m[col.toItem()!!] != null) return Result.Unreadable("$label 행에 같은 항목이 두 번 있음")
                m = m.with(col, parseValue(match.groupValues[2]))
                usedColumns += col
                count++
            }
            if (count < 2) continue
            if (INCH.containsMatchIn(row)) return Result.Unreadable("cm 단위가 아닌 표(인치)")
            addSize(sizes, label, m)?.let { return it }
        }
        if (sizes.isEmpty()) return Result.NotFound
        return found(sizes, usedColumns.toList())
    }

    /** 표 셀 값(숫자)인지 */
    fun isValue(s: String): Boolean = NUMBER.matches(s.removeSuffix("cm").removeSuffix("CM"))

    fun isEmptyCell(s: String): Boolean = s in EMPTY_CELL

    fun isInch(s: String): Boolean = INCH.containsMatchIn(s)

    /**
     * 사이즈별 (항목 → 값) 으로 이미 정리된 표로 SizeChart 를 만든다(NumberGrid 용).
     * 값 범위·중복·빈 칸 검사는 다른 경로와 같다.
     */
    fun chartFromTable(
        sizes: List<Pair<String, Map<Column, Double?>>>,
        columns: List<Column>,
        skipped: List<String> = emptyList(),
    ): Result {
        val map = linkedMapOf<String, Measurements>()
        sizes.forEach { (label, values) ->
            var m = Measurements()
            values.forEach { (col, v) -> m = m.with(col, v) }
            addSize(map, label, m)?.let { return it }
        }
        if (map.isEmpty()) return Result.Unreadable("사이즈 행이 없음")
        return found(map, columns, skipped)
    }

    private fun addSize(sizes: MutableMap<String, Measurements>, label: String, m: Measurements): Result? {
        if (MeasurementRules.invalidItems(m).isNotEmpty()) return Result.Unreadable("$label 행에 비정상 값")
        val previous = sizes[label]
        if (previous != null && previous != m) return Result.Conflicting(label)
        sizes[label] = m
        return null
    }

    /** 하의 전용 항목이 있고 어깨·소매가 없으면 하의 표로 본다(상의 기준 옷과 비교하지 않음) */
    fun bottomTable(columns: List<Column>): Result? =
        if (Column.BOTTOM in columns && Column.SHOULDER !in columns && Column.SLEEVE !in columns) {
            Result.Unreadable("하의 사이즈표로 보여요(지금은 상의만 비교해요)")
        } else null

    private fun found(sizes: Map<String, Measurements>, columns: List<Column>, skipped: List<String> = emptyList()): Result {
        if (sizes.values.all { m -> MeasureItem.entries.all { m[it] == null } }) return Result.Unreadable("값이 모두 비어 있음")
        // 어느 배치로 읽었든, 헤더에 있던 항목이 통째로 비었거나 한 사이즈에 빈 칸이 2개 이상이면
        // OCR 이 표 일부만 읽은 것으로 보고 결과를 내지 않는다.
        val items = columns.filter { it in MEASURE_COLUMNS }.distinct().mapNotNull { it.toItem() }
        items.firstOrNull { item -> sizes.size >= 2 && sizes.values.all { it[item] == null } }?.let {
            return Result.Unreadable("${it.label} 칸 값을 하나도 읽지 못함")
        }
        sizes.entries.firstOrNull { (_, m) -> items.count { m[it] == null } > 1 }?.let {
            return Result.Unreadable("${it.key} 행에 빈 칸이 많음")
        }
        val chestMethod = when {
            Column.CHEST_FLAT in columns -> ChestMeasureMethod.FLAT
            Column.CHEST_CIRC in columns -> ChestMeasureMethod.CIRCUMFERENCE
            else -> ChestMeasureMethod.UNKNOWN
        }
        return Result.Found(
            SizeChart(
                sizes = sizes.map { (k, v) -> ProductSize(k, v) },
                unit = "cm",
                source = SizeChartSource.SCREEN_CAPTURE,
                verification = VerificationStatus.UNVERIFIED,
                sourceDetail = "현재 화면에서 읽은 표",
                chestMethod = chestMethod,
                skippedItems = skipped.distinct(),
            ),
        )
    }

    private fun Column.toItem(): MeasureItem? = when (this) {
        Column.SHOULDER -> MeasureItem.SHOULDER
        Column.CHEST_FLAT -> MeasureItem.CHEST_FLAT
        Column.CHEST_CIRC -> MeasureItem.CHEST_CIRCUMFERENCE
        Column.LENGTH -> MeasureItem.LENGTH
        Column.SLEEVE -> MeasureItem.SLEEVE
        else -> null
    }

    /** 헤더 한 줄에서 인식한 비교 항목 (테스트/디버깅용) */
    fun recognizedItems(header: String): List<MeasureItem> = splitHeader(header).mapNotNull { classifyHeader(it)?.toItem() }
}
