package com.brandme.fit.comparison

import com.brandme.fit.body3d.HumanBodyModel
import com.brandme.fit.body3d.MannequinDims
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.BodyShapeBase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** 앱에 넣은 사람 형태 모형 자산(MakeHuman CC0 가공)을 그대로 읽어 확인한다 */
class HumanBodyModelTest {
    private val model by lazy {
        val dir = listOf(File("src/main/assets/body"), File("app/src/main/assets/body")).first { it.exists() }
        HumanBodyModel.load(File(dir, "body_model.bin").readBytes(), File(dir, "body_model.json").readText())
    }

    @Test fun `built body has entered height and valid geometry`() {
        val r = model.build(MannequinDims.from(BodyProfile(heightCm = 181.0, shoulderCm = 46.0, chestCm = 100.0, waistCm = 84.0, hipCm = 98.0, armCm = 60.0)))
        val (min, max) = r.mesh.bounds()
        assertEquals(181.0, (max[1] - min[1]).toDouble(), 0.5)
        assertEquals(0.0, min[1].toDouble(), 0.01)
        assertTrue(r.mesh.vertexCount < Short.MAX_VALUE)
        assertTrue(r.mesh.normals.none { it.isNaN() })
        assertEquals(setOf("chest", "waist", "hip", "shoulder", "arm", "height"), r.anchors.keys)
        // 왼쪽/오른쪽 기준점은 서로 반대편
        val chest = r.anchors.getValue("chest")
        assertTrue(chest.first[0] * chest.second[0] < 0)
    }

    @Test fun `bigger measurements give bigger body weights`() {
        fun w(chest: Double, waist: Double) = model.solveWeights(
            MannequinDims.from(BodyProfile(heightCm = 175.0, chestCm = chest, waistCm = waist, hipCm = 96.0, shoulderCm = 43.0, armCm = 58.0)),
        )
        val slim = w(88.0, 70.0)
        val big = w(110.0, 98.0)
        assertTrue(big.getValue("bust") + big.getValue("weight") > slim.getValue("bust") + slim.getValue("weight"))
        assertTrue(big.getValue("waist") + big.getValue("weight") > slim.getValue("waist") + slim.getValue("weight"))
        (slim.values + big.values).forEach { assertTrue(it in -1.0..1.0) }
    }

    @Test fun `female base builds`() {
        val r = model.build(MannequinDims.from(BodyProfile(heightCm = 160.0, shapeBase = BodyShapeBase.FEMALE)))
        val (min, max) = r.mesh.bounds()
        assertEquals(160.0, (max[1] - min[1]).toDouble(), 0.5)
    }
}
