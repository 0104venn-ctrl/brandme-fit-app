package com.brandme.fit.body3d

import android.content.Context
import android.graphics.PointF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.brandme.fit.data.model.BodyItem
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.Measurements
import com.brandme.fit.data.model.PreferredFit
import com.brandme.fit.data.model.SkinTone
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** 사람 형태 모형 자산은 한 번만 읽는다. 읽지 못하면 null(단순 마네킹으로 대체). */
object HumanBodyModelHolder {
    @Volatile private var model: HumanBodyModel? = null
    @Volatile private var failed = false

    fun get(context: Context): HumanBodyModel? {
        model?.let { return it }
        if (failed) return null
        return runCatching {
            val am = context.assets
            HumanBodyModel.load(
                am.open("body/body_model.bin").use { it.readBytes() },
                am.open("body/body_model.json").use { it.readBytes().decodeToString() },
            )
        }.onFailure { failed = true }.getOrNull()?.also { model = it }
    }
}

/** 치수 표시선 항목: 이름, 표시 쪽(왼쪽 열/오른쪽 열), 몸 치수 항목 */
private data class Callout(val key: String, val label: String, val left: Boolean, val item: BodyItem)

private val CALLOUTS = listOf(
    Callout("shoulder", "어깨너비", true, BodyItem.SHOULDER),
    Callout("chest", "가슴둘레", true, BodyItem.CHEST),
    Callout("waist", "허리둘레", true, BodyItem.WAIST),
    Callout("hip", "엉덩이둘레", true, BodyItem.HIP),
    Callout("height", "키", false, BodyItem.HEIGHT),
    Callout("arm", "팔길이", false, BodyItem.ARM),
)

/**
 * 치수로 만든 하얀 사람 모형 + 부위별 치수 표시선. 좌우로 끌어 돌려 볼 수 있다.
 * showCallouts = false 면 모형만 그리고 천천히 돈다.
 */
@Composable
fun Mannequin3D(
    profile: BodyProfile,
    modifier: Modifier = Modifier,
    showCallouts: Boolean = false,
    /** 입혀 볼 옷의 실측(사이즈표 한 사이즈). null 이면 몸만 */
    garment: Measurements? = null,
    /** true 면 핏 색상 지도, false 면 단색 옷 */
    heatMap: Boolean = true,
) {
    val context = LocalContext.current
    var view by remember { mutableStateOf<MannequinView?>(null) }
    var projected by remember { mutableStateOf<Map<String, Pair<PointF, PointF>>>(emptyMap()) }
    var builtBody by remember { mutableStateOf<Pair<HumanBodyModel.Result, MannequinDims>?>(null) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    DisposableEffect(lifecycle, view) {
        val v = view
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> v?.onResume()
                Lifecycle.Event.ON_PAUSE -> v?.onPause()
                else -> Unit
            }
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(profile.skinTone, view) { view?.setSkinColor(profile.skinTone.rgb) }

    // 색·선호 핏만 바뀐 경우에는 모형을 다시 만들지 않는다
    LaunchedEffect(profile.copy(skinTone = SkinTone.MANNEQUIN, preferredFit = PreferredFit.REGULAR, updatedAt = 0), view) {
        val v = view ?: return@LaunchedEffect
        val dims = MannequinDims.from(profile)
        val built = withContext(Dispatchers.Default) {
            HumanBodyModelHolder.get(context)?.build(dims)
        }
        if (built != null) {
            v.setMesh(built.mesh, profile.heightCm.toFloat(), built.anchors)
            builtBody = built to dims
        } else {
            v.setMesh(withContext(Dispatchers.Default) { MannequinMesh.build(dims) }, profile.heightCm.toFloat())
            builtBody = null
        }
    }

    // 옷 입히기: 몸·옷·색 모드가 바뀔 때만 다시 만든다
    LaunchedEffect(builtBody, garment, heatMap, view) {
        val v = view ?: return@LaunchedEffect
        val b = builtBody
        if (garment == null || b == null) { v.setGarment(null, null); return@LaunchedEffect }
        val fitted = withContext(Dispatchers.Default) {
            runCatching {
                // 실제 옷 틀(반팔: 티셔츠, 긴팔: 스웨터)이 있으면 그것을 입히고, 없으면 단순 형태로 만든다
                val shortSleeve = (garment.sleeveCm ?: 0.0) < b.second.arm * 0.6
                val tpl = ClothesLibraryHolder.get(context)?.pick(b.second.shape, shortSleeve)
                if (tpl != null) TemplateDresser.dress(b.first, b.second, garment, tpl) else GarmentFitter.fit(b.first, b.second, garment)
            }.getOrNull()
        }
        if (fitted == null) v.setGarment(null, null)
        else v.setGarment(fitted.mesh, if (heatMap) fitted.heatColors else fitted.plainColors)
    }

    BoxWithConstraints(modifier) {
        val density = LocalDensity.current
        AndroidView(
            factory = { ctx ->
                MannequinView(ctx).also {
                    it.setAutoSpin(!showCallouts)
                    if (showCallouts) it.onAnchorsProjected = { p -> projected = p }
                    view = it
                }
            },
            modifier = Modifier.fillMaxSize(),
        )
        if (showCallouts && projected.isNotEmpty()) {
            val wPx = with(density) { maxWidth.toPx() }
            val hPx = with(density) { maxHeight.toPx() }
            val labelW = with(density) { 84.dp.toPx() }
            val labelH = with(density) { 38.dp.toPx() }
            val margin = with(density) { 8.dp.toPx() }
            // 각 열에서 기준점 높이 순서대로 놓고, 겹치지 않게 간격을 둔다
            val placed = HashMap<String, Pair<Offset, Offset>>() // label 위치(좌상단), 기준점
            for (left in listOf(true, false)) {
                val items = CALLOUTS.filter { it.left == left }.mapNotNull { c ->
                    val pair = projected[c.key] ?: return@mapNotNull null
                    val anchor = if (left) (if (pair.first.x < pair.second.x) pair.first else pair.second)
                    else (if (pair.first.x >= pair.second.x) pair.first else pair.second)
                    c to Offset(anchor.x, anchor.y)
                }.sortedBy { it.second.y }
                var nextMinY = margin
                for ((c, a) in items) {
                    val y = maxOf(nextMinY, (a.y - labelH / 2)).coerceAtMost(hPx - labelH - margin)
                    nextMinY = y + labelH + margin
                    val x = if (left) margin else wPx - labelW - margin
                    placed[c.key] = Offset(x, y) to a
                }
            }
            val lineColor = Color.White.copy(alpha = 0.75f)
            Canvas(Modifier.fillMaxSize()) {
                for ((key, pos) in placed) {
                    val left = CALLOUTS.first { it.key == key }.left
                    val start = Offset(if (left) pos.first.x + labelW else pos.first.x, pos.first.y + labelH / 2)
                    val end = pos.second
                    val path = Path().apply {
                        moveTo(start.x, start.y)
                        val midX = (start.x + end.x) / 2
                        cubicTo(midX, start.y, midX, end.y, end.x, end.y)
                    }
                    drawPath(path, lineColor, style = Stroke(width = 1.5.dp.toPx()))
                    drawCircle(Color.White, radius = 3.dp.toPx(), center = end)
                }
            }
            for ((key, pos) in placed) {
                val c = CALLOUTS.first { it.key == key }
                val value = profile[c.item]
                Column(
                    Modifier
                        .offset { IntOffset(pos.first.x.roundToInt(), pos.first.y.roundToInt()) }
                        .width(84.dp)
                        .background(Color(0xE6FFFFFF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                ) {
                    Text(c.label, fontSize = 10.sp, color = Color(0xFF6B6F76))
                    Text(
                        value?.let { "${fmt(it)} ${c.item.unit}" } ?: "미입력",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (value != null) Color(0xFF111111) else Color(0xFF9AA0A6),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
    }
}

private fun fmt(v: Double): String = if (v == v.toLong().toDouble()) v.toLong().toString() else "%.1f".format(v)
