package com.brandme.fit.recognition

import com.brandme.fit.recognition.SizeChartTextParser.Column

/**
 * 사이즈표 항목명 사전.
 *
 * 이름에 특정 글자가 "포함"됐는지로 판단하지 않는다("소매통"이 "소매"로 잡히는 문제).
 * 아래 목록에 있는 이름만 그 항목으로 인정하고, OCR 오타는 이 목록의 단어로만 보정한다.
 * 목록에 없는 이름은 "모르는 항목"으로 돌려준다(호출자가 비교에서 빼고 사용자에게 알린다).
 *
 * 국내 쇼핑몰 상의/하의 실측표에서 쓰이는 이름을 정리했다. 새 이름은 해당 목록에 추가한다.
 */
object SizeTerms {

    /** 사이즈 라벨이 놓인 줄/칸의 머리말 */
    private val SIZE_HEADER = listOf("사이즈", "사이즈표", "size", "sizes", "구분", "옵션", "단위", "호수", "치수")

    // ---- 비교에 쓰는 항목(상의) ----
    private val SHOULDER = listOf("어깨", "어깨너비", "어깨넓이", "어깨단면", "어깨폭", "shoulder", "shoulderwidth")
    private val CHEST_FLAT = listOf(
        "가슴", "가슴단면", "가슴너비", "가슴넓이", "가슴폭", "품", "가슴품", "chest", "chestwidth",
    )
    private val CHEST_CIRC = listOf("가슴둘레", "흉위", "chestcircumference")
    /** 쇼핑몰마다 둘레/단면이 달라 값으로 판단해야 하는 이름 */
    private val BUST = listOf("바스트", "bust")
    private val LENGTH = listOf(
        "총장", "총기장", "총길이", "기장", "전체기장", "전체길이", "옷길이", "뒷총장", "뒤총장", "뒷기장", "뒤기장",
        "length", "totallength",
    )
    private val SLEEVE = listOf(
        "소매", "소매길이", "소매기장", "소매장", "팔길이", "팔기장", "팔", "sleeve", "sleevelength",
    )

    // ---- 표에 있지만 비교하지 않는 항목(상의) ----
    private val IGNORE = listOf(
        // 팔 둘레/너비
        "소매통", "소매너비", "소매폭", "소매단면", "팔통", "팔너비", "팔뚝단면", "팔뚝둘레", "상완둘레", "소매둘레",
        // 소매 끝
        "소매밑단", "소매단", "소매끝", "소매끝단", "소매부리", "소매밑단너비", "소매밑단둘레", "소매밑단단면",
        "소매단폭", "소매단너비", "커프스", "소매커프스", "cuff",
        // 겨드랑이
        "암홀", "암홀단면", "암홀둘레", "진동", "진동둘레", "진동단면", "겨드랑이", "armhole",
        // 밑단·허리
        "밑단", "밑단단면", "밑단너비", "밑단둘레", "허리", "허리단면", "허리둘레", "hem", "waist",
        // 목·칼라
        "목너비", "목둘레", "목깊이", "넥", "넥라인", "카라", "칼라", "앞목깊이", "neck",
        // 후드
        "후드길이", "후드높이", "후드너비", "모자",
        // 재는 위치가 달라 비교하지 않는 길이/너비
        "화장", "어깨길이", "앞기장", "앞총장", "등길이", "등너비", "앞품", "뒤품", "트임", "포켓",
        // 착용 정보
        "체중", "몸무게", "키", "권장", "추천", "권장체중", "추천체중", "권장키", "추천키", "모델",
        "두께", "무게", "신축성", "비침", "weight", "height",
    )

    // ---- 하의 전용 항목(상의 기준 옷과 비교하지 않는 표) ----
    private val BOTTOM = listOf(
        "엉덩이", "엉덩이둘레", "엉덩이단면", "힙", "밑위", "앞밑위", "뒷밑위", "뒤밑위",
        "허벅지", "허벅지단면", "허벅지둘레", "무릎", "무릎단면", "인심", "아웃심", "바지총장", "바지기장",
        "hip", "rise", "thigh", "knee", "inseam", "outseam",
    )

    val TERMS: Map<String, Column> = buildMap {
        SIZE_HEADER.forEach { put(it, Column.SIZE) }
        SHOULDER.forEach { put(it, Column.SHOULDER) }
        CHEST_FLAT.forEach { put(it, Column.CHEST_FLAT) }
        CHEST_CIRC.forEach { put(it, Column.CHEST_CIRC) }
        BUST.forEach { put(it, Column.BUST) }
        LENGTH.forEach { put(it, Column.LENGTH) }
        SLEEVE.forEach { put(it, Column.SLEEVE) }
        IGNORE.forEach { put(it, Column.IGNORE) }
        BOTTOM.forEach { put(it, Column.BOTTOM) }
    }

    private val INVISIBLE = Regex("""[\s\p{Z}\p{Cf}]""")
    private val PUNCT = Regex("""[()\[\]{}:：*·.,'"]""")
    private val NUMBERING = Regex("""^(\d{1,2}[.)]?|[①-⑳])+""")
    /** 단위 표기. 인치 여부는 분류 전에 원문으로 따로 검사한다. */
    private val UNIT_SUFFIX = Regex("""(cm|mm|kg|㎝|㎏|inches|inch|인치)+$""")

    /** "1. 가슴 (단면)", "체중 (kg)", "어깨​너비" → "가슴단면", "체중", "어깨너비" */
    fun normalize(raw: String): String {
        var h = java.text.Normalizer.normalize(raw, java.text.Normalizer.Form.NFC).replace(INVISIBLE, "").lowercase()
        h = h.replace(NUMBERING, "")
        h = h.replace(PUNCT, "")
        h = h.replace(UNIT_SUFFIX, "")
        return h
    }
}
