package com.brandme.fit.recognition

/**
 * 결제·계정·메시지 화면으로 보이면 분석을 멈춘다(온디바이스 텍스트 기준, 외부 전송 전에 검사).
 * 쇼핑 앱 상단의 "로그인하고 쿠폰 받기" 같은 문구로 오탐하지 않도록 강한 신호만 쓴다.
 */
object SensitiveScreenDetector {
    private val STRONG = listOf(
        "카드번호", "비밀번호", "계좌번호", "cvc", "보안카드", "주민등록번호", "인증번호", "유효기간mm",
        "결제비밀번호", "간편결제비밀번호", "otp", "메시지입력", "채팅방", "메시지를입력",
    )
    private val PAYMENT_PAIR = listOf("결제수단", "최종결제금액", "결제하기", "주문결제")

    fun isSensitive(screenText: String): Boolean {
        val t = screenText.lowercase().replace(" ", "").replace("\n", "")
        if (STRONG.any { t.contains(it) }) return true
        // 결제 화면 신호는 2개 이상 함께 있을 때만
        return PAYMENT_PAIR.count { t.contains(it) } >= 2
    }
}
