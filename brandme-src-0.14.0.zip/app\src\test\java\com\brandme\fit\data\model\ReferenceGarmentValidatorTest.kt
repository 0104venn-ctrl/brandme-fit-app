package com.brandme.fit.data.model

import com.brandme.fit.data.model.ReferenceGarmentValidator.Field
import com.brandme.fit.data.model.ReferenceGarmentValidator.Input
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ReferenceGarmentValidatorTest {
    private fun input(
        name: String = "자주 입는 티", category: GarmentCategory? = GarmentCategory.SHORT_SLEEVE_TEE,
        s: String = "46", c: String = "52", l: String = "70", sl: String = "",
    ) = Input(name, category, s, c, l, sl)

    @Test fun `valid input builds garment`() {
        val r = ReferenceGarmentValidator.validate(input(sl = "21.5"))
        assertTrue(r.isValid)
        assertEquals(21.5, r.garment!!.measurements.sleeveCm!!, 1e-9)
        assertTrue(r.warnings.isEmpty())
    }

    @Test fun `name and category are required`() {
        val r = ReferenceGarmentValidator.validate(input(name = "  ", category = null))
        assertTrue(Field.NAME in r.errors)
        assertTrue(Field.CATEGORY in r.errors)
        assertFalse(r.isValid)
    }

    @Test fun `at least one core item required`() {
        val r = ReferenceGarmentValidator.validate(input(s = "", c = "", l = "", sl = "60"))
        assertTrue(Field.CORE in r.errors)
    }

    @Test fun `zero negative non numeric and abnormal values rejected`() {
        assertTrue(Field.SHOULDER in ReferenceGarmentValidator.validate(input(s = "0")).errors)
        assertTrue(Field.SHOULDER in ReferenceGarmentValidator.validate(input(s = "-3")).errors)
        assertTrue(Field.CHEST_FLAT in ReferenceGarmentValidator.validate(input(c = "abc")).errors)
        assertTrue(Field.LENGTH in ReferenceGarmentValidator.validate(input(l = "700")).errors)
        assertTrue(Field.CHEST_FLAT in ReferenceGarmentValidator.validate(input(c = "5")).errors)
    }

    @Test fun `comma decimal and cm suffix accepted`() {
        val r = ReferenceGarmentValidator.validate(input(s = "46,5", c = "52cm"))
        assertTrue(r.isValid)
        assertEquals(46.5, r.garment!!.measurements.shoulderCm!!, 1e-9)
        assertEquals(52.0, r.garment!!.measurements.chestFlatCm!!, 1e-9)
    }

    @Test fun `warns when too few items`() {
        val r = ReferenceGarmentValidator.validate(input(s = "46", c = "", l = ""))
        assertTrue(r.isValid)
        assertEquals(listOf(ReferenceGarmentValidator.FEW_ITEMS_WARNING), r.warnings)
    }
}
