package com.brandme.fit.photo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.sin

class PoseCheckTest {
    /** 정규화 좌표(0..1)의 서 있는 사람: 코 y=0.12, 발 y=0.88. armDeg = 아래 방향 기준 팔 벌린 각도 */
    private fun body(
        armDeg: Double = 45.0, shoulderHalf: Double = 0.07, shift: Double = 0.0, scale: Double = 1.0,
    ): Map<Int, Pt> {
        fun p(x: Double, y: Double) = Pt(0.5 + (x - 0.5) * scale + shift, 0.5 + (y - 0.5) * scale)
        val arm = 0.25
        val dx = arm * sin(Math.toRadians(armDeg)); val dy = arm * cos(Math.toRadians(armDeg))
        return mapOf(
            PoseCheck.NOSE to p(0.5, 0.12),
            PoseCheck.L_SHOULDER to p(0.5 + shoulderHalf, 0.24), PoseCheck.R_SHOULDER to p(0.5 - shoulderHalf, 0.24),
            PoseCheck.L_HIP to p(0.55, 0.50), PoseCheck.R_HIP to p(0.45, 0.50),
            PoseCheck.L_WRIST to p(0.5 + shoulderHalf + dx, 0.24 + dy), PoseCheck.R_WRIST to p(0.5 - shoulderHalf - dx, 0.24 + dy),
            PoseCheck.L_HEEL to p(0.54, 0.88), PoseCheck.R_HEEL to p(0.46, 0.88),
        )
    }

    private fun check(pose: PhotoPose, m: Map<Int, Pt>) = PoseCheck.evaluate(pose) { m[it] }

    @Test fun `a-pose front passes`() = assertTrue(check(PhotoPose.FRONT, body()).ok)

    @Test fun `arms hanging down ask to open them`() {
        val s = check(PhotoPose.FRONT, body(armDeg = 8.0))
        assertFalse(s.ok)
        assertTrue("벌려" in s.message)
    }

    @Test fun `t-pose asks to lower arms`() {
        val s = check(PhotoPose.FRONT, body(armDeg = 85.0))
        assertFalse(s.ok)
        assertTrue("내려" in s.message)
    }

    @Test fun `arm angle is measured outward from straight down`() {
        assertEquals(45.0, PoseCheck.armAngle(Pt(0.6, 0.2), Pt(0.7, 0.3), 0.5), 1e-9)
        assertEquals(-45.0, PoseCheck.armAngle(Pt(0.6, 0.2), Pt(0.5, 0.3), 0.5), 1e-9) // 몸 안쪽
        assertEquals(45.0, PoseCheck.armAngle(Pt(0.4, 0.2), Pt(0.3, 0.3), 0.5), 1e-9)  // 왼쪽 팔
    }

    @Test fun `too far and too close are flagged`() {
        assertTrue("가까이" in check(PhotoPose.FRONT, body(scale = 0.6)).message)
        assertTrue("물러나" in check(PhotoPose.FRONT, body(scale = 1.2)).message)
    }

    @Test fun `off center is flagged`() = assertTrue("가운데" in check(PhotoPose.FRONT, body(shift = 0.25)).message)

    @Test fun `side pose needs narrow shoulders`() {
        assertFalse(check(PhotoPose.SIDE, body()).ok)
        assertTrue(check(PhotoPose.SIDE, body(shoulderHalf = 0.01)).ok)
    }

    @Test fun `missing feet asks for full body`() {
        val m = body().filterKeys { it != PoseCheck.L_HEEL && it != PoseCheck.R_HEEL }
        assertEquals(false, check(PhotoPose.FRONT, m).ok)
    }

    @Test fun `steadiness needs small movement`() {
        assertTrue(PoseCheck.isSteady(listOf(Pt(0.5, 0.5), Pt(0.501, 0.5), Pt(0.502, 0.501))))
        assertFalse(PoseCheck.isSteady(listOf(Pt(0.5, 0.5), Pt(0.55, 0.5), Pt(0.5, 0.5))))
    }
}
