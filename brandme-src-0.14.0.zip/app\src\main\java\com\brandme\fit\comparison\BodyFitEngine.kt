package com.brandme.fit.comparison

import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.ChestMeasureMethod
import com.brandme.fit.data.model.PreferredFit
import com.brandme.fit.data.model.SizeChart
import kotlin.math.abs
import kotlin.math.roundToInt

/** 몸 기준 비교 항목 */
enum class BodyFitItem(val label: String) {
    CHEST("가슴"),
    SHOULDER("어깨"),
    /** 드롭숄더 옷에서만: 옷 어깨 − 내 어깨 바깥너비 */
    SHOULDER_OUTER("어깨 바깥"),
    SLEEVE("소매"),
}

/** 여유분 구간별 핏 판단. 기준값은 아래 BodyFitEngine.RULES 에 공개한다. */
enum class FitLevel(val label: String) {
    TOO_SMALL("작음"),
    TIGHT("타이트"),
    REGULAR("레귤러"),
    RELAXED("여유"),
    OVERSIZED("오버핏"),
    SHORT("짧음"),
    GOOD("맞음"),
    LONG("김"),
    /** 어깨선이 팔 쪽으로 내려오도록 만든 디자인 — 어깨 여유로 핏을 판단하지 않는다 */
    DROP_SHOULDER("드롭숄더"),
}

data class ItemEase(
    val item: BodyFitItem,
    /** 여유분(cm) = 옷 − 몸. 가슴은 둘레 기준 */
    val easeCm: Double,
    val level: FitLevel,
)

data class SizeBodyFit(
    val sizeLabel: String,
    val eases: List<ItemEase>,
    /** 선호 핏 목표와의 거리. 낮을수록 선호 핏에 가깝다. 비교 항목이 없으면 null */
    val score: Double?,
)

data class BodyFitResult(
    val algorithmVersion: String,
    val preferredFit: PreferredFit,
    val sizes: List<SizeBodyFit>,
    /** 선호 핏에 가장 가까운 사이즈(동점이면 여러 개) */
    val recommended: List<String>,
    /** 비교에 쓴 항목 */
    val items: Set<BodyFitItem>,
    val notes: List<String>,
) {
    val isSuccess: Boolean get() = recommended.isNotEmpty()
}

/**
 * 내 몸 치수와 사이즈표를 비교해 "여유분"(옷 − 몸)을 계산한다.
 *
 * - 가슴: 옷 가슴 둘레(표가 둘레면 그대로, 단면이면 × 2) − 내 가슴둘레
 * - 어깨: 옷 어깨 − 내 어깨너비
 * - 소매: 옷 소매 − 내 팔길이
 * 총장은 몸 치수와 직접 비교할 기준이 없어 비교하지 않는다.
 * 핏 구간 기준은 일반적인 상의 여유분 관례에서 정한 참고값이며, 소재·신축성은 반영하지 않는다.
 */
object BodyFitEngine {
    const val ALGORITHM_VERSION = "body-1.1.0"

    /** 가슴 둘레 여유분 구간(cm): 미만이면 해당 단계 */
    val CHEST_RULES = listOf(0.0 to FitLevel.TOO_SMALL, 6.0 to FitLevel.TIGHT, 14.0 to FitLevel.REGULAR, 24.0 to FitLevel.RELAXED)
    /** 어깨 여유분 구간(cm) */
    val SHOULDER_RULES = listOf(-2.0 to FitLevel.TOO_SMALL, 2.0 to FitLevel.REGULAR, 6.0 to FitLevel.RELAXED)
    /** 소매 여유분 구간(cm) */
    val SLEEVE_RULES = listOf(-3.0 to FitLevel.SHORT, 3.0 to FitLevel.GOOD)

    /** 선호 핏별 목표 여유분(cm) */
    fun target(fit: PreferredFit, item: BodyFitItem): Double = when (item) {
        BodyFitItem.CHEST -> when (fit) {
            PreferredFit.SLIM -> 4.0
            PreferredFit.REGULAR -> 10.0
            PreferredFit.RELAXED -> 18.0
            PreferredFit.OVERSIZED -> 28.0
        }
        BodyFitItem.SHOULDER -> when (fit) {
            PreferredFit.SLIM -> 0.0
            PreferredFit.REGULAR -> 1.0
            PreferredFit.RELAXED -> 4.0
            PreferredFit.OVERSIZED -> 9.0
        }
        BodyFitItem.SHOULDER_OUTER, BodyFitItem.SLEEVE -> 0.0
    }

    /** 사람이 읽을 수 있는 기준 설명(결과 화면에 그대로 보여 준다) */
    val RULES_TEXT = listOf(
        "가슴 여유(둘레): 0 미만 작음 · 0~6 타이트 · 6~14 레귤러 · 14~24 여유 · 24 이상 오버핏",
        "어깨 여유: -2 미만 작음 · -2~2 레귤러 · 2~6 여유 · 6 이상 오버핏(드롭숄더)",
        "소매 여유: -3 미만 짧음 · -3~3 맞음 · 3 이상 김 (목 뒤 중심~소매 끝 길이로 비교)",
        "어깨가 몸보다 ${DROP_SHOULDER_CM.toInt()}cm 이상 넓으면 어깨선이 팔로 내려오는 드롭숄더 디자인으로 보고, 어깨는 순위에 쓰지 않아요",
        "드롭숄더 옷은 내 어깨 바깥너비와도 비교해요: 옷 어깨가 ${-OUTER_TIGHT_CM.toInt()}cm 넘게 좁으면 어깨·팔 위쪽이 낄 수 있어요",
    )

    /** 옷 어깨 − 몸 어깨가 이 값 이상이면 드롭숄더 디자인으로 본다 */
    const val DROP_SHOULDER_CM = 8.0
    /** 드롭숄더 옷의 어깨가 내 어깨 바깥너비보다 이만큼 이상 좁으면 낄 수 있다고 본다 */
    const val OUTER_TIGHT_CM = -2.0

    private fun level(ease: Double, rules: List<Pair<Double, FitLevel>>, last: FitLevel) =
        rules.firstOrNull { ease < it.first }?.second ?: last

    fun evaluate(body: BodyProfile, chart: SizeChart): BodyFitResult {
        val notes = mutableListOf<String>()
        val circChart = chart.chestMethod == ChestMeasureMethod.CIRCUMFERENCE
        if (body.chestCm != null && chart.sizes.any { it.measurements.chestFlatCm != null }) {
            notes += "옷 가슴은 단면 × 2 를 둘레로 보고 내 가슴둘레와 비교했어요."
        }
        // 가슴·어깨로 비교할 수 없으면 소매 길이로만 순위를 매긴다(가장 덜 확실한 기준이라 안내)
        val canRankByBody = (body.chestCm != null && chart.sizes.any { it.measurements.chestFlatCm != null || it.measurements.chestCircumferenceCm != null }) ||
            (body.shoulderCm != null && chart.sizes.any { it.measurements.shoulderCm != null })
        val sizes = chart.sizes.map { s ->
            val m = s.measurements
            val eases = buildList {
                val garmentChest = m.chestCircumferenceCm ?: m.chestFlatCm?.let { it * 2 }
                if (body.chestCm != null && garmentChest != null) {
                    val e = garmentChest - body.chestCm
                    add(ItemEase(BodyFitItem.CHEST, e, level(e, CHEST_RULES, FitLevel.OVERSIZED)))
                }
                if (body.shoulderCm != null && m.shoulderCm != null) {
                    val e = m.shoulderCm - body.shoulderCm
                    val lv = if (e >= DROP_SHOULDER_CM) FitLevel.DROP_SHOULDER else level(e, SHOULDER_RULES, FitLevel.OVERSIZED)
                    add(ItemEase(BodyFitItem.SHOULDER, e, lv))
                }
                // 드롭숄더 옷은 어깨선이 팔 위에 놓이므로 팔 바깥 너비와 비교한다: 옷이 더 좁으면 어깨·팔 위쪽이 낄 수 있다
                val outer = body.shoulderOuterCm
                if (outer != null && m.shoulderCm != null && body.shoulderCm != null && m.shoulderCm - body.shoulderCm >= DROP_SHOULDER_CM) {
                    val e = m.shoulderCm - outer
                    add(ItemEase(BodyFitItem.SHOULDER_OUTER, e, if (e < OUTER_TIGHT_CM) FitLevel.TOO_SMALL else FitLevel.GOOD))
                }
                if (body.armCm != null && m.sleeveCm != null && m.sleeveCm >= body.armCm * 0.6) {
                    // 반팔(소매가 팔길이의 60% 미만)은 팔길이와 비교하지 않는다.
                    // 어깨선 위치가 옷마다 달라(드롭숄더 등) 소매만 비교하면 틀리므로,
                    // 목 뒤 중심~소매 끝(어깨 절반 + 소매)과 목 뒤 중심~손목(어깨 절반 + 팔길이)을 비교한다.
                    val e = if (body.shoulderCm != null && m.shoulderCm != null) {
                        (m.shoulderCm / 2 + m.sleeveCm) - (body.shoulderCm / 2 + body.armCm)
                    } else m.sleeveCm - body.armCm
                    add(ItemEase(BodyFitItem.SLEEVE, e, level(e, SLEEVE_RULES, FitLevel.LONG)))
                }
            }
            // 선호 핏 목표와의 거리. 가슴을 가장 중요하게, 어깨를 그다음으로 본다(소매는 순위에 쓰지 않음).
            val weights = if (canRankByBody) mapOf(BodyFitItem.CHEST to 1.0, BodyFitItem.SHOULDER to 0.8) else mapOf(BodyFitItem.SLEEVE to 1.0)
            val scored = eases.filter { it.item in weights && it.level != FitLevel.DROP_SHOULDER }
            val score = if (scored.isEmpty()) null else
                scored.sumOf { abs(it.easeCm - target(body.preferredFit, it.item)) * weights.getValue(it.item) } / scored.sumOf { weights.getValue(it.item) }
            SizeBodyFit(s.label, eases, score)
        }
        if (circChart) notes += "이 표는 가슴 둘레 기준이라 그대로 내 가슴둘레와 비교했어요."
        if (sizes.any { s -> s.eases.any { it.level == FitLevel.DROP_SHOULDER } }) {
            notes += "어깨선이 팔 쪽으로 내려오는 드롭숄더 디자인이라 어깨 여유가 크게 나와요. 어깨는 순위에 쓰지 않고 가슴으로 골랐어요."
        }
        if (sizes.any { s -> s.eases.any { it.item == BodyFitItem.SHOULDER_OUTER && it.level == FitLevel.TOO_SMALL } }) {
            notes += "일부 사이즈는 옷 어깨가 내 어깨 바깥너비보다 좁아 어깨·팔 위쪽이 낄 수 있어요."
        }
        if (body.shoulderOuterCm == null && sizes.any { s -> s.eases.any { it.level == FitLevel.DROP_SHOULDER } }) {
            notes += "어깨 바깥너비를 입력하면 드롭숄더 옷이 어깨에서 끼는지도 확인할 수 있어요."
        }
        if (body.shoulderCm != null && sizes.any { s -> s.eases.any { it.item == BodyFitItem.SLEEVE } }) {
            notes += "소매는 목 뒤 중심부터 소매 끝까지 길이(어깨 절반 + 소매)로 비교했어요."
        }
        if (body.chestCm == null) notes += "가슴둘레를 입력하면 가슴 여유분도 비교할 수 있어요."
        if (body.shoulderCm == null) notes += "어깨너비를 입력하면 어깨 여유분도 비교할 수 있어요."

        // 같은 항목 구성끼리만 순위를 매긴다
        val rankable = sizes.filter { it.score != null }
        val keySet = rankable.groupBy { s -> s.eases.filter { !canRankByBody || it.item != BodyFitItem.SLEEVE }.map { it.item }.toSet() }
            .maxByOrNull { it.value.size }?.value.orEmpty()
        val best = keySet.minOfOrNull { it.score!! }
        val recommended = if (best == null) emptyList() else keySet.filter { abs(it.score!! - best) < 0.05 }.map { it.sizeLabel }
        if (!canRankByBody && recommended.isNotEmpty()) {
            notes += "가슴둘레·어깨너비가 없어 소매 길이로만 골랐어요. 내 몸 치수에 가슴둘레나 어깨너비를 넣으면 더 정확해요."
        }
        if (recommended.isEmpty()) {
            notes += if (body.chestCm == null && body.shoulderCm == null) "내 몸 치수에 가슴둘레나 어깨너비가 없어 추천 사이즈를 정하지 못했어요. 앱에서 입력하거나 사진으로 재 주세요."
            else "몸 치수와 사이즈표에 함께 있는 항목(가슴·어깨)이 없어 추천하지 못했어요."
        }

        return BodyFitResult(
            algorithmVersion = ALGORITHM_VERSION,
            preferredFit = body.preferredFit,
            sizes = sizes,
            recommended = recommended,
            items = sizes.flatMap { s -> s.eases.map { it.item } }.toSet(),
            notes = notes,
        )
    }

    fun formatEase(v: Double): String {
        val r = (v * 10).roundToInt() / 10.0
        val s = if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
        return if (r > 0) "+$s" else s
    }
}
