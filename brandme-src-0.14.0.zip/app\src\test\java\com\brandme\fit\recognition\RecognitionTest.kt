package com.brandme.fit.recognition

import com.brandme.fit.catalog.CatalogSize
import com.brandme.fit.catalog.DemoCatalog
import com.brandme.fit.data.model.ComparisonWarning
import com.brandme.fit.data.model.GarmentCategory
import com.brandme.fit.data.model.IdentificationStatus
import com.brandme.fit.data.model.Measurements
import com.brandme.fit.data.model.ReferenceGarment
import com.brandme.fit.data.model.SizeChartSource
import com.brandme.fit.data.model.VerificationStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class RecognitionTest {
    private val catalog = DemoCatalog.parse(File("src/main/assets/demo_products.json").readText())
    private val matcher = ProductMatcher(catalog.products)
    private val pipeline = AnalysisPipeline(catalog, textReader = { error("not used") })
    private val reference = ReferenceGarment(name = "기준 티", category = GarmentCategory.SHORT_SLEEVE_TEE,
        measurements = Measurements(46.0, 52.0, 70.0, 20.0))

    private fun screen(vararg rows: String) = ScreenText(rows.mapIndexed { i, t -> TextLine(t, 0, i * 40, 500, i * 40 + 30) })

    @Test fun `exact match needs brand and name`() {
        val m = matcher.match("데모브랜드 노스필드\n베이직 코튼 반팔 티셔츠\n19,900원")
        assertEquals(IdentificationStatus.EXACT_MATCH, m.status)
        assertEquals("demo-001", m.product!!.id)
    }

    @Test fun `brand only is not confirmed`() {
        val m = matcher.match("데모브랜드 노스필드 기획전")
        assertTrue(m.status != IdentificationStatus.EXACT_MATCH)
    }

    @Test fun `conflicting product code is not confirmed`() {
        val m = matcher.match("데모브랜드 노스필드 베이직 코튼 반팔 티셔츠 품번 DM-T002")
        assertTrue(m.status != IdentificationStatus.EXACT_MATCH)
    }

    @Test fun `several exact products on one screen are ambiguous`() {
        val m = matcher.match("데모브랜드 노스필드 베이직 코튼 반팔 티셔츠\n데모브랜드 노스필드 헤비웨이트 오버핏 반팔 티셔츠")
        assertEquals(IdentificationStatus.AMBIGUOUS, m.status)
        assertTrue(m.candidates.size >= 2)
    }

    @Test fun `unknown screen is not found`() {
        assertEquals(IdentificationStatus.NOT_FOUND, matcher.match("오늘의 추천 상품 랭킹").status)
    }

    @Test fun `sensitive screens are detected`() {
        assertTrue(SensitiveScreenDetector.isSensitive("카드번호 입력\n유효기간"))
        assertTrue(SensitiveScreenDetector.isSensitive("결제수단 선택\n최종 결제금액 29,000원"))
        assertTrue(SensitiveScreenDetector.isSensitive("비밀번호를 입력하세요"))
        assertFalse(SensitiveScreenDetector.isSensitive("로그인하고 쿠폰 받기\n베이직 반팔 티셔츠"))
    }

    @Test fun `demo catalog exact match result is labeled demo`() {
        val out = pipeline.analyzeText(screen("데모브랜드 노스필드", "베이직 코튼 반팔 티셔츠"), FitBasis(reference, null))
        out as AnalysisOutcome.Success
        assertEquals(SizeChartSource.LOCAL_CATALOG, out.chart.source)
        assertEquals(VerificationStatus.DEMO, out.chart.verification)
        assertTrue(out.product.isDemo)
        assertTrue(ComparisonWarning.DEMO_DATA in out.result!!.warnings)
        assertEquals(listOf("M"), out.result!!.closestSizes)
    }

    @Test fun `screen size table result is unverified not demo`() {
        val out = pipeline.analyzeText(screen("어느 쇼핑몰 상품", "사이즈\t어깨\t가슴단면\t총장", "M\t47\t53\t71", "L\t49\t56\t73"), FitBasis(reference, null))
        out as AnalysisOutcome.Success
        assertEquals(SizeChartSource.SCREEN_CAPTURE, out.chart.source)
        assertEquals(VerificationStatus.UNVERIFIED, out.chart.verification)
        assertFalse(out.product.isDemo)
        assertTrue(ComparisonWarning.PRODUCT_NOT_CONFIRMED in out.result!!.warnings)
        assertTrue(ComparisonWarning.UNVERIFIED_DATA in out.result!!.warnings)
    }

    @Test fun `no product and no chart fails without inventing sizes`() {
        val out = pipeline.analyzeText(screen("오늘의 추천", "무료배송"), FitBasis(reference, null))
        assertEquals(AnalysisError.NO_PRODUCT_NO_CHART, (out as AnalysisOutcome.Failure).error)
    }

    @Test fun `candidates require user choice`() {
        val out = pipeline.analyzeText(screen("데모브랜드 노스필드 반팔 티셔츠 모음"), FitBasis(reference, null))
        assertTrue(out is AnalysisOutcome.NeedsCandidateChoice || out is AnalysisOutcome.Failure)
        assertFalse(out is AnalysisOutcome.Success)
    }

    @Test fun `catalog and screen disagreement is conflicting`() {
        val out = pipeline.analyzeText(screen("데모브랜드 노스필드", "베이직 코튼 반팔 티셔츠",
            "사이즈\t어깨\t가슴단면\t총장", "M\t40\t45\t60"), FitBasis(reference, null))
        assertEquals(AnalysisError.CONFLICTING_VALUES, (out as AnalysisOutcome.Failure).error)
    }

    @Test fun `remote identified product without chart is size chart not found`() {
        val out = pipeline.mapRemote(AnalyzeScreenResponse(status = "EXACT_MATCH",
            product = RemoteProduct(brand = "B", name = "N"), failureReason = "SIZE_CHART_NOT_VISIBLE"), FitBasis(reference, null))
        out as AnalysisOutcome.Failure
        assertEquals(AnalysisError.SIZE_CHART_NOT_FOUND, out.error)
        assertEquals("상품은 확인했지만 정확한 실측 정보를 찾지 못했어요.", out.error.message)
    }

    @Test fun `remote conflicting charts are rejected`() {
        val a = RemoteSizeChart(sizes = listOf(CatalogSize("M", 46.0, 52.0, null, 70.0)))
        val b = RemoteSizeChart(sizes = listOf(CatalogSize("M", 48.0, 54.0, null, 72.0)))
        val out = pipeline.mapRemote(AnalyzeScreenResponse(status = "EXACT_MATCH", sizeChartCandidates = listOf(a, b)), FitBasis(reference, null))
        assertEquals(AnalysisError.CONFLICTING_VALUES, (out as AnalysisOutcome.Failure).error)
    }

    @Test fun `remote chart is compared on client and marked unverified`() {
        val a = RemoteSizeChart(sizes = listOf(CatalogSize("M", 46.0, 52.0, null, 70.0), CatalogSize("L", 48.0, 55.0, null, 72.0)))
        val out = pipeline.mapRemote(AnalyzeScreenResponse(status = "EXACT_MATCH", sizeChartCandidates = listOf(a)), FitBasis(reference, null))
        out as AnalysisOutcome.Success
        assertEquals(SizeChartSource.AI_SERVER, out.chart.source)
        assertEquals(VerificationStatus.UNVERIFIED, out.chart.verification)
        assertEquals(listOf("M"), out.result!!.closestSizes)
    }

    @Test fun `remote invalid values do not produce a result`() {
        val a = RemoteSizeChart(sizes = listOf(CatalogSize("M", 0.0, 52.0, null, 70.0)))
        val out = pipeline.mapRemote(AnalyzeScreenResponse(status = "EXACT_MATCH", sizeChartCandidates = listOf(a)), FitBasis(reference, null))
        assertEquals(AnalysisError.COMPARISON_IMPOSSIBLE, (out as AnalysisOutcome.Failure).error)
    }

    @Test fun `row assembler joins cells on same line`() {
        val rows = RowAssembler.assemble(listOf(
            TextLine("어깨", 100, 10, 140, 30), TextLine("사이즈", 0, 12, 60, 30), TextLine("총장", 200, 11, 240, 31),
            TextLine("M", 0, 50, 20, 70), TextLine("46", 100, 51, 130, 70), TextLine("70", 200, 50, 230, 69),
        ))
        assertEquals(listOf("사이즈\t어깨\t총장", "M\t46\t70"), rows)
    }
}
