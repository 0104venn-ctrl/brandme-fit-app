package com.brandme.fit.overlay

import android.animation.ValueAnimator
import android.app.AppOpsManager
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.brandme.fit.BrandmeFitApp
import com.brandme.fit.MainActivity
import com.brandme.fit.R
import com.brandme.fit.appContainer
import com.brandme.fit.capture.CaptureConsentActivity
import com.brandme.fit.capture.CaptureCoordinator
import com.brandme.fit.capture.CaptureResult
import com.brandme.fit.capture.ConsentEvent
import com.brandme.fit.capture.MediaProjectionService
import com.brandme.fit.recognition.AnalysisError
import com.brandme.fit.recognition.AnalysisOutcome
import com.brandme.fit.recognition.AnalysisPipeline
import com.brandme.fit.recognition.AnalysisStage
import com.brandme.fit.ui.result.OverlayPanel
import com.brandme.fit.ui.result.PanelState
import com.brandme.fit.ui.theme.BrandmeTheme
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import kotlin.math.abs
import kotlin.math.hypot

/**
 * 다른 앱 위에 떠 있는 brandme Fit 버튼과 결과 패널.
 *
 * - TYPE_APPLICATION_OVERLAY 창 두 개: 둥근 버튼, 하단 패널(안내/로딩/결과/오류).
 * - 패널은 화면 하단 일부만 차지하고 포커스를 가져가지 않아, 결과를 보면서 쇼핑 앱을 계속 쓸 수 있다.
 * - 오버레이 권한이 철회되면 창을 안전하게 제거하고 종료한다.
 * - 부팅 시 자동 시작하지 않는다(START_NOT_STICKY, BOOT 리시버 없음).
 */
class FloatingOverlayService : LifecycleService(), SavedStateRegistryOwner {

    private val savedStateController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panel: ComposeView? = null
    private val panelState = MutableStateFlow<PanelState>(PanelState.Hidden)

    private var analysisJob: Job? = null
    private var pendingAnalysisAfterConsent = false
    private var appOps: AppOpsManager? = null
    private var stopping = false

    private val opListener = AppOpsManager.OnOpChangedListener { _, pkg ->
        if (pkg == packageName) main.postDelayed({ checkPermissionStillGranted() }, 300)
    }

    override fun onCreate() {
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        appOps = getSystemService(AppOpsManager::class.java)
        appOps?.startWatchingMode(AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW, packageName, opListener)

        lifecycleScope.launch {
            CaptureCoordinator.events.collect { event ->
                when (event) {
                    ConsentEvent.Granted -> if (pendingAnalysisAfterConsent) {
                        pendingAnalysisAfterConsent = false
                        startAnalysis()
                    }
                    ConsentEvent.Denied -> if (pendingAnalysisAfterConsent) {
                        pendingAnalysisAfterConsent = false
                        showPanel(PanelState.Outcome(AnalysisOutcome.Failure(AnalysisError.PERMISSION_DENIED)))
                    }
                    is ConsentEvent.Ended -> Unit
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopEverything()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            CaptureCoordinator.reportError("오버레이 권한이 없어 버튼을 표시하지 않았어요.")
            stopEverything()
            return START_NOT_STICKY
        }
        try {
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            CaptureCoordinator.reportError("플로팅 버튼 서비스를 시작하지 못했어요.")
            stopEverything()
            return START_NOT_STICKY
        }
        if (bubble == null) lifecycleScope.launch { showBubble() }
        CaptureCoordinator.setOverlayRunning(true)
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- 버튼

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun screenBounds() = wm.currentWindowMetrics.bounds

    private suspend fun showBubble() {
        val size = dp(56)
        val saved = appContainer.settings.current()
        val bounds = screenBounds()
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (saved.bubbleX >= 0) saved.bubbleX else bounds.width() - size
            y = if (saved.bubbleY >= 0) saved.bubbleY else bounds.height() / 3
            title = "brandme Fit button"
        }
        clampToScreen(params, size)

        val view = TextView(this).apply {
            text = "Fit"
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            contentDescription = "brandme Fit 사이즈 비교 버튼"
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF4C3BCF.toInt())
                setStroke(dp(2), Color.WHITE)
            }
            elevation = dp(6).toFloat()
        }
        view.setOnTouchListener(BubbleTouchListener(params, size))
        try {
            wm.addView(view, params)
            bubble = view
            bubbleParams = params
        } catch (e: Exception) {
            // 권한이 막 철회된 경우 등 — 크래시 대신 안전 종료
            Log.e(TAG, "addView failed", e)
            stopEverything()
        }
    }

    private fun clampToScreen(p: WindowManager.LayoutParams, size: Int) {
        val b = screenBounds()
        p.x = p.x.coerceIn(0, (b.width() - size).coerceAtLeast(0))
        p.y = p.y.coerceIn(0, (b.height() - size).coerceAtLeast(0))
    }

    private inner class BubbleTouchListener(
        private val params: WindowManager.LayoutParams,
        private val size: Int,
    ) : View.OnTouchListener {
        private val slop = ViewConfiguration.get(this@FloatingOverlayService).scaledTouchSlop
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var dragging = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) dragging = true
                    if (dragging) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        clampToScreen(params, size)
                        safeUpdate(v, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) snapToEdge(v, params, size) else { v.performClick(); onBubbleTap() }
                }
                MotionEvent.ACTION_CANCEL -> if (dragging) snapToEdge(v, params, size)
            }
            return true
        }
    }

    private fun safeUpdate(v: View, p: WindowManager.LayoutParams) {
        if (v.isAttachedToWindow) runCatching { wm.updateViewLayout(v, p) }
    }

    /** 가까운 좌/우 가장자리로 붙이고 위치를 저장한다. */
    private fun snapToEdge(v: View, p: WindowManager.LayoutParams, size: Int) {
        val width = screenBounds().width()
        val target = if (p.x + size / 2 < width / 2) 0 else width - size
        ValueAnimator.ofInt(p.x, target).apply {
            duration = (abs(target - p.x) / 3L).coerceIn(80L, 250L)
            addUpdateListener { p.x = it.animatedValue as Int; safeUpdate(v, p) }
            start()
        }
        val y = p.y
        lifecycleScope.launch { appContainer.settings.setBubblePosition(target, y) }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // 회전 시 버튼이 화면 밖으로 나가지 않도록 다시 붙인다.
        val v = bubble ?: return
        val p = bubbleParams ?: return
        main.post {
            clampToScreen(p, v.width.takeIf { it > 0 } ?: dp(56))
            snapToEdge(v, p, v.width.takeIf { it > 0 } ?: dp(56))
        }
    }

    // ---------------------------------------------------------------- 패널

    private fun showPanel(state: PanelState) {
        panelState.value = state
        if (state == PanelState.Hidden) {
            removePanel()
            return
        }
        if (panel != null) return
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.BOTTOM
            title = "brandme Fit panel"
        }
        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingOverlayService)
            setViewTreeSavedStateRegistryOwner(this@FloatingOverlayService)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent {
                val s by panelState.collectAsState()
                BrandmeTheme {
                    OverlayPanel(
                        state = s,
                        onClose = { showPanel(PanelState.Hidden) },
                        onCancel = { cancelAnalysis() },
                        onContinueConsent = { requestCaptureConsent() },
                        onPickCandidate = { id -> pickCandidate(id) },
                        onOpenApp = { openApp() },
                    )
                }
            }
        }
        try {
            wm.addView(view, params)
            panel = view
        } catch (e: Exception) {
            Log.e(TAG, "panel addView failed", e)
            stopEverything()
        }
    }

    private fun removePanel() {
        panel?.let { runCatching { wm.removeViewImmediate(it) } }
        panel = null
    }

    // ---------------------------------------------------------------- 동작

    private fun onBubbleTap() {
        if (analysisJob?.isActive == true) return
        if (!Settings.canDrawOverlays(this)) { stopEverything(); return }
        lifecycleScope.launch {
            val reference = appContainer.fitBasis()
            if (!reference.isUsable) {
                showPanel(PanelState.Outcome(AnalysisOutcome.Failure(AnalysisError.REFERENCE_INCOMPLETE)))
                return@launch
            }
            if (!CaptureCoordinator.hasSession) {
                // 권한 요청 전에 목적을 먼저 설명한다.
                showPanel(PanelState.ConsentExplain)
            } else {
                startAnalysis()
            }
        }
    }

    private fun requestCaptureConsent() {
        showPanel(PanelState.Hidden)
        pendingAnalysisAfterConsent = true
        try {
            startActivity(
                Intent(this, CaptureConsentActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION),
            )
        } catch (e: Exception) {
            Log.e(TAG, "consent activity failed", e)
            pendingAnalysisAfterConsent = false
            showPanel(PanelState.Outcome(AnalysisOutcome.Failure(AnalysisError.CAPTURE_FAILED, detail = "동의 화면을 열지 못했어요.")))
        }
    }

    private fun startAnalysis() {
        if (analysisJob?.isActive == true) return
        analysisJob = lifecycleScope.launch {
            CaptureCoordinator.setAnalyzing(true)
            var bitmap: android.graphics.Bitmap? = null
            try {
                val reference = appContainer.fitBasis()
                val settings = appContainer.settings.current()

                // 캡처 직전에 우리 오버레이를 숨긴다.
                showPanel(PanelState.Hidden)
                bubble?.visibility = View.INVISIBLE
                val hiddenAt = System.nanoTime()
                delay(120)
                val capture = CaptureCoordinator.capture(hiddenAt)
                bubble?.visibility = View.VISIBLE

                val outcome: AnalysisOutcome = when (capture) {
                    is CaptureResult.Ok -> {
                        bitmap = capture.bitmap
                        showPanel(PanelState.Loading(AnalysisStage.RECOGNIZING))
                        try {
                            withTimeout(ANALYSIS_TIMEOUT_MS) {
                                appContainer.pipeline.analyze(
                                    capture.bitmap, reference,
                                    AnalysisPipeline.Options(settings.mode, settings.aiConsent, settings.serverUrl),
                                ) { stage -> panelState.value = PanelState.Loading(stage) }
                            }
                        } catch (e: TimeoutCancellationException) {
                            AnalysisOutcome.Failure(AnalysisError.TIMEOUT)
                        }
                    }
                    CaptureResult.ProtectedOrBlank -> AnalysisOutcome.Failure(AnalysisError.PROTECTED_SCREEN)
                    is CaptureResult.Failed -> AnalysisOutcome.Failure(AnalysisError.CAPTURE_FAILED, detail = capture.reason)
                    CaptureResult.NoSession -> {
                        showPanel(PanelState.ConsentExplain)
                        return@launch
                    }
                }
                finish(outcome, reference.displayName)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "analysis failed", e)
                finish(AnalysisOutcome.Failure(AnalysisError.CAPTURE_FAILED, detail = e.javaClass.simpleName), null)
            } finally {
                // 원본 이미지는 분석 직후 메모리에서 해제한다(파일로 저장한 적 없음).
                // 취소된 경우엔 OCR 이 아직 bitmap 을 읽고 있을 수 있어 참조만 끊고 GC 에 맡긴다.
                if (isActive) bitmap?.recycle()
                bitmap = null
                bubble?.visibility = View.VISIBLE
                CaptureCoordinator.setAnalyzing(false)
            }
        }
    }

    private suspend fun finish(outcome: AnalysisOutcome, referenceName: String?) {
        CaptureCoordinator.reportError((outcome as? AnalysisOutcome.Failure)?.error?.title)
        if (referenceName != null) runCatching { appContainer.history.record(outcome, referenceName) }
        showPanel(PanelState.Outcome(outcome))
    }

    private fun cancelAnalysis() {
        analysisJob?.cancel()
        analysisJob = null
        showPanel(PanelState.Outcome(AnalysisOutcome.Failure(AnalysisError.CANCELLED)))
    }

    private fun pickCandidate(id: String) {
        lifecycleScope.launch {
            val reference = appContainer.fitBasis()
            val outcome = appContainer.pipeline.compareChosenCandidate(id, reference)
            finish(outcome, reference.displayName)
        }
    }

    private fun openApp() {
        showPanel(PanelState.Hidden)
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun checkPermissionStillGranted() {
        if (!Settings.canDrawOverlays(this)) {
            CaptureCoordinator.reportError("오버레이 권한이 철회되어 버튼을 제거했어요.")
            stopEverything()
        }
    }

    /** 버튼·패널·캡처 세션·포그라운드 서비스를 모두 정리한다. */
    private fun stopEverything() {
        if (stopping) return
        stopping = true
        analysisJob?.cancel()
        pendingAnalysisAfterConsent = false
        removePanel()
        bubble?.let { runCatching { wm.removeViewImmediate(it) } }
        bubble = null
        MediaProjectionService.stop(this)
        CaptureCoordinator.setOverlayRunning(false)
        CaptureCoordinator.setAnalyzing(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        appOps?.stopWatchingMode(opListener)
        removePanel()
        bubble?.let { runCatching { wm.removeViewImmediate(it) } }
        bubble = null
        CaptureCoordinator.setOverlayRunning(false)
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, FloatingOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        return Notification.Builder(this, BrandmeFitApp.CHANNEL_OVERLAY)
            .setSmallIcon(R.drawable.ic_stat_fit)
            .setContentTitle("brandme Fit 버튼이 켜져 있어요")
            .setContentText("쇼핑 앱에서 Fit 버튼을 누르면 사이즈를 비교해요.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "서비스 중지", stop).build())
            .build()
    }

    companion object {
        private const val TAG = "FloatingOverlayService"
        const val ACTION_STOP = "com.brandme.fit.overlay.STOP"
        private const val NOTIFICATION_ID = 2001
        private const val ANALYSIS_TIMEOUT_MS = 30_000L

        fun start(context: Context) {
            context.startForegroundService(Intent(context, FloatingOverlayService::class.java))
        }

        fun stop(context: Context) {
            runCatching {
                context.startService(Intent(context, FloatingOverlayService::class.java).setAction(ACTION_STOP))
            }.onFailure { context.stopService(Intent(context, FloatingOverlayService::class.java)) }
        }
    }
}
