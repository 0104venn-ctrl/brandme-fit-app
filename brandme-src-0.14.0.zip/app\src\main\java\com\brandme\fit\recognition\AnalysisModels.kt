package com.brandme.fit.recognition

import com.brandme.fit.comparison.BodyFitResult
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.ComparisonResult
import com.brandme.fit.data.model.ReferenceGarment
import com.brandme.fit.data.model.DetectedProduct
import com.brandme.fit.data.model.SizeChart

/** 분석 모드. 기본값은 DEMO(키·서버 없이 동작). */
enum class AnalysisMode(val label: String) {
    DEMO("Demo Mode (온디바이스 · 외부 전송 없음)"),
    AI("AI Mode (서버로 화면 이미지 전송)"),
}

enum class AnalysisStage(val label: String) {
    CAPTURING("화면 캡처"),
    RECOGNIZING("상품 인식"),
    FINDING_SIZE_CHART("사이즈표 확인"),
    COMPARING("사이즈 비교"),
}

/** SCR-08 오류/미지원 화면. 각 경우를 따로 다룬다. */
enum class AnalysisError(val title: String, val message: String) {
    PERMISSION_DENIED(
        "권한이 필요해요",
        "화면 캡처를 승인하지 않아 분석하지 않았어요. 다시 시도하려면 버튼을 눌러 승인해 주세요.",
    ),
    OVERLAY_PERMISSION_MISSING(
        "오버레이 권한이 필요해요",
        "다른 앱 위에 표시 권한이 꺼져 있어 플로팅 버튼을 표시할 수 없어요.",
    ),
    CAPTURE_FAILED("화면을 캡처하지 못했어요", "잠시 후 다시 시도해 주세요. 캡처 세션이 끝났다면 다시 승인이 필요해요."),
    PROTECTED_SCREEN(
        "보호된 화면이에요",
        "이 화면은 앱이 캡처를 막아 두었거나(보안 화면) 내용이 비어 있어 분석할 수 없어요. 우회하지 않아요.",
    ),
    SENSITIVE_SCREEN(
        "분석을 중단했어요",
        "결제·계정·메시지 화면으로 보여 분석을 멈췄어요. 캡처 이미지는 바로 삭제했어요.",
    ),
    PRODUCT_NOT_IDENTIFIED(
        "상품을 확인하지 못했어요",
        "화면에서 상품을 특정하지 못했어요. 상품 상세 화면이나 사이즈표가 보이는 상태에서 다시 시도해 주세요.",
    ),
    MULTIPLE_CANDIDATES(
        "여러 상품 후보가 있어요",
        "화면만으로는 상품을 하나로 확정할 수 없어요. 맞는 상품을 직접 고르거나 상세 화면에서 다시 시도해 주세요.",
    ),
    SIZE_CHART_NOT_FOUND(
        "실측 정보를 찾지 못했어요",
        "상품은 확인했지만 정확한 실측 정보를 찾지 못했어요.",
    ),
    NO_PRODUCT_NO_CHART(
        "분석할 수 없어요",
        "상품도, 화면 속 사이즈표도 확인하지 못했어요. 사이즈표(실측)가 보이도록 스크롤한 뒤 다시 시도해 주세요.",
    ),
    SIZE_CHART_UNREADABLE(
        "사이즈표를 읽지 못했어요",
        "사이즈표로 보이는 영역이 있지만 값을 정확히 읽지 못했어요. 표가 화면에 크게 보이도록 한 뒤 다시 시도해 주세요.",
    ),
    CONFLICTING_VALUES(
        "값이 서로 달라요",
        "같은 사이즈에 서로 다른 실측값이 있어 어느 쪽이 맞는지 알 수 없어요. 비교하지 않았어요.",
    ),
    API_CONNECTION_FAILED(
        "서버에 연결하지 못했어요",
        "AI 서버에 연결할 수 없어요. Demo Mode로 바꾸거나 서버 주소를 확인해 주세요.",
    ),
    AI_CONSENT_REQUIRED(
        "외부 전송 동의가 필요해요",
        "AI Mode는 화면 이미지를 서버로 보내요. 앱의 개인정보 설정에서 동의한 뒤 사용할 수 있어요.",
    ),
    TIMEOUT("시간이 초과됐어요", "분석이 너무 오래 걸려 중단했어요. 다시 시도해 주세요."),
    REFERENCE_INCOMPLETE(
        "내 몸 치수가 필요해요",
        "앱에서 내 몸 치수(어깨너비·가슴둘레·팔길이 중 1개 이상)를 먼저 저장해 주세요. 사진으로 잴 수도 있어요.",
    ),
    COMPARISON_IMPOSSIBLE("비교할 수 없어요", "기준 옷과 사이즈표에 공통 항목이 없거나 값이 올바르지 않아요."),
    CANCELLED("분석을 취소했어요", "캡처 이미지는 삭제했어요."),
}

sealed interface AnalysisOutcome {
    data class Success(
        val product: DetectedProduct,
        val chart: SizeChart,
        /** 기준 옷 비교 결과. 기준 옷이 없거나 비교할 수 없으면 null */
        val result: ComparisonResult?,
        /** 내 몸 치수 기준 비교 결과. 몸 치수가 없으면 null */
        val bodyFit: BodyFitResult? = null,
        /** 비교에 쓴 내 몸 치수(3D 입혀 보기용). 기록에는 저장하지 않는다 */
        val body: BodyProfile? = null,
        /** OCR 이 읽은 행. 디버그 빌드의 결과 패널에서만 보여 주며 기록에는 저장하지 않는다. */
        val screenRows: List<String>? = null,
    ) : AnalysisOutcome

    /** 후보가 여러 개 — 사용자가 고르기 전에는 어느 사이즈표도 쓰지 않는다. */
    data class NeedsCandidateChoice(val product: DetectedProduct) : AnalysisOutcome

    data class Failure(
        val error: AnalysisError,
        val product: DetectedProduct? = null,
        val detail: String? = null,
        /** OCR 이 읽은 행. 디버그 빌드의 결과 패널에서만 보여 주며 기록에는 저장하지 않는다. */
        val screenRows: List<String>? = null,
    ) : AnalysisOutcome
}

/** 비교 기준: 기준 옷과 내 몸 치수 중 저장된 것. 둘 중 하나라도 비교할 수 있으면 분석한다. */
data class FitBasis(val garment: ReferenceGarment?, val body: BodyProfile?) {
    val isUsable: Boolean get() = garment?.isComparable == true || body?.isComparable == true
    val displayName: String get() = listOfNotNull(body?.let { "내 몸" }, garment?.name).joinToString(" · ")
}
