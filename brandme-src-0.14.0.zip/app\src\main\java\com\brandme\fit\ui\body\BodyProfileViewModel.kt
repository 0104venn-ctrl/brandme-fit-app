package com.brandme.fit.ui.body

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.brandme.fit.data.local.BodyProfileStore
import com.brandme.fit.data.model.BodyItem
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.BodyProfileValidator
import com.brandme.fit.data.model.BodyShapeBase
import com.brandme.fit.data.model.PreferredFit
import com.brandme.fit.data.model.SkinTone
import com.brandme.fit.body3d.MannequinDims
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class BodyUiState(
    val loaded: Boolean = false,
    val inputs: Map<BodyItem, String> = emptyMap(),
    val shape: BodyShapeBase = BodyShapeBase.MALE,
    val fit: PreferredFit = PreferredFit.REGULAR,
    val skin: SkinTone = SkinTone.MANNEQUIN,
    val errors: Map<BodyItem, String> = emptyMap(),
    val saved: Boolean = false,
) {
    /** 3D 미리보기: 입력 중인 값 중 범위 안의 값만 쓰고, 키가 없으면 170cm 로 그린다 */
    val preview: BodyProfile
        get() {
            fun v(item: BodyItem) = BodyProfileValidator.parse(inputs[item].orEmpty())?.takeIf { it in item.range }
            return BodyProfile(
                heightCm = v(BodyItem.HEIGHT) ?: 170.0,
                weightKg = v(BodyItem.WEIGHT),
                shoulderCm = v(BodyItem.SHOULDER),
                shoulderOuterCm = v(BodyItem.SHOULDER_OUTER),
                chestCm = v(BodyItem.CHEST),
                waistCm = v(BodyItem.WAIST),
                hipCm = v(BodyItem.HIP),
                armCm = v(BodyItem.ARM),
                shapeBase = shape,
                preferredFit = fit,
                skinTone = skin,
            )
        }

    val estimatedParts: List<String> get() = MannequinDims.from(preview).estimated
}

class BodyProfileViewModel(private val store: BodyProfileStore) : ViewModel() {
    private val _state = MutableStateFlow(BodyUiState())
    val state: StateFlow<BodyUiState> = _state

    init {
        viewModelScope.launch {
            val p = store.get()
            _state.value = BodyUiState(
                loaded = true,
                inputs = BodyItem.entries.associateWith { item -> p?.get(item)?.let(::format).orEmpty() },
                shape = p?.shapeBase ?: BodyShapeBase.MALE,
                fit = p?.preferredFit ?: PreferredFit.REGULAR,
                skin = p?.skinTone ?: SkinTone.MANNEQUIN,
            )
        }
    }

    private fun format(v: Double) = if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()

    fun edit(item: BodyItem, value: String) = _state.update {
        it.copy(inputs = it.inputs + (item to value), errors = it.errors - item)
    }

    fun setShape(s: BodyShapeBase) = _state.update { it.copy(shape = s) }
    fun setFit(f: PreferredFit) = _state.update { it.copy(fit = f) }
    fun setSkin(t: SkinTone) = _state.update { it.copy(skin = t) }

    /** 사진 추정값을 입력칸에 채운다(저장은 사용자가 확인 후 직접) */
    fun applyEstimates(values: Map<BodyItem, Double>) = _state.update { s ->
        s.copy(inputs = s.inputs + values.mapValues { (_, v) -> format(Math.round(v * 10) / 10.0) }, errors = s.errors - values.keys)
    }

    fun save() {
        val s = _state.value
        val r = BodyProfileValidator.validate(s.inputs, s.shape, s.fit, skinTone = s.skin)
        if (!r.isValid) { _state.update { it.copy(errors = r.errors) }; return }
        viewModelScope.launch {
            store.save(r.profile!!)
            _state.update { it.copy(saved = true) }
        }
    }
}
