package com.brandme.fit.comparison

import com.brandme.fit.body3d.MannequinDims
import com.brandme.fit.body3d.MannequinMesh
import com.brandme.fit.data.model.BodyItem
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.BodyProfileValidator
import com.brandme.fit.data.model.BodyShapeBase
import com.brandme.fit.data.model.ChestMeasureMethod
import com.brandme.fit.data.model.Measurements
import com.brandme.fit.data.model.PreferredFit
import com.brandme.fit.data.model.ProductSize
import com.brandme.fit.data.model.SizeChart
import com.brandme.fit.data.model.SizeChartSource
import com.brandme.fit.data.model.VerificationStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class BodyFitEngineTest {

    private fun chart(vararg sizes: Pair<String, Measurements>, method: ChestMeasureMethod = ChestMeasureMethod.FLAT) = SizeChart(
        sizes = sizes.map { ProductSize(it.first, it.second) },
        source = SizeChartSource.SCREEN_CAPTURE,
        verification = VerificationStatus.UNVERIFIED,
        chestMethod = method,
    )

    /** 0.3.0 실기기에서 읽은 FREE / 1번 표 */
    private val freeChart = chart(
        "FREE" to Measurements(shoulderCm = 58.0, chestFlatCm = 62.0, lengthCm = 70.0, sleeveCm = 57.0),
        "1번" to Measurements(shoulderCm = 62.0, chestFlatCm = 67.0, lengthCm = 74.0, sleeveCm = 63.0),
    )

    @Test fun `ease is garment minus body with flat chest doubled`() {
        val body = BodyProfile(heightCm = 175.0, shoulderCm = 46.0, chestCm = 96.0, armCm = 60.0)
        val r = BodyFitEngine.evaluate(body, freeChart)
        val free = r.sizes.first { it.sizeLabel == "FREE" }
        assertEquals(124.0 - 96.0, free.eases.first { it.item == BodyFitItem.CHEST }.easeCm, 1e-9)
        assertEquals(12.0, free.eases.first { it.item == BodyFitItem.SHOULDER }.easeCm, 1e-9)
        assertEquals(FitLevel.DROP_SHOULDER, free.eases.first { it.item == BodyFitItem.SHOULDER }.level) // +12 → 드롭숄더
        // 소매: (58/2 + 57) − (46/2 + 60) = +3 (목 뒤 중심~소매 끝 기준)
        assertEquals(3.0, free.eases.first { it.item == BodyFitItem.SLEEVE }.easeCm, 1e-9)
        assertEquals(FitLevel.OVERSIZED, free.eases.first { it.item == BodyFitItem.CHEST }.level)
        assertTrue(r.notes.any { "단면 × 2" in it })
    }

    @Test fun `preferred fit changes the recommendation`() {
        val c = chart(
            "S" to Measurements(shoulderCm = 44.0, chestFlatCm = 50.0),
            "M" to Measurements(shoulderCm = 46.0, chestFlatCm = 53.0),
            "L" to Measurements(shoulderCm = 48.0, chestFlatCm = 56.0),
            "XL" to Measurements(shoulderCm = 51.0, chestFlatCm = 60.0),
        )
        fun rec(fit: PreferredFit) =
            BodyFitEngine.evaluate(BodyProfile(heightCm = 175.0, shoulderCm = 45.0, chestCm = 96.0, preferredFit = fit), c).recommended
        assertEquals(listOf("S"), rec(PreferredFit.SLIM))     // 가슴 여유 +4
        assertEquals(listOf("M"), rec(PreferredFit.REGULAR))  // +10
        assertEquals(listOf("L"), rec(PreferredFit.RELAXED))  // +16
        assertEquals(listOf("XL"), rec(PreferredFit.OVERSIZED)) // +24
    }

    /** 실기기 캡처: 드롭숄더 맨투맨(L 어깨 63.5) — 어깨 여유 +27 로 순위가 정해지면 안 된다 */
    @Test fun `drop shoulder garments are ranked by chest`() {
        val c = chart(
            "L(105)" to Measurements(shoulderCm = 63.5, chestFlatCm = 66.0, lengthCm = 73.5, sleeveCm = 54.5),
            "XL(110~115)" to Measurements(shoulderCm = 65.0, chestFlatCm = 68.0, lengthCm = 75.5, sleeveCm = 56.0),
            "XXL(120~125)" to Measurements(shoulderCm = 66.5, chestFlatCm = 70.0, lengthCm = 77.5, sleeveCm = 57.5),
        )
        val body = BodyProfile(heightCm = 176.0, shoulderCm = 42.0, chestCm = 100.0, armCm = 58.0, preferredFit = PreferredFit.OVERSIZED)
        val r = BodyFitEngine.evaluate(body, c)
        assertEquals(listOf("L(105)"), r.recommended)                // 가슴 여유 +32 가 오버핏 목표(+28)에 가장 가깝다
        assertTrue(r.sizes.all { s -> s.eases.first { it.item == BodyFitItem.SHOULDER }.level == FitLevel.DROP_SHOULDER })
        assertTrue(r.notes.any { "드롭숄더" in it })
        // 소매: (63.5/2 + 54.5) − (42/2 + 58) = 7.25
        assertEquals(7.25, r.sizes[0].eases.first { it.item == BodyFitItem.SLEEVE }.easeCm, 1e-9)
    }

    @Test fun `drop shoulder is checked against outer shoulder width`() {
        val c = chart(
            "M" to Measurements(shoulderCm = 50.0, chestFlatCm = 60.0),
            "L" to Measurements(shoulderCm = 54.0, chestFlatCm = 63.0),
        )
        val body = BodyProfile(heightCm = 176.0, shoulderCm = 41.0, shoulderOuterCm = 53.0, chestCm = 100.0)
        val r = BodyFitEngine.evaluate(body, c)
        val m = r.sizes[0].eases.first { it.item == BodyFitItem.SHOULDER_OUTER }
        assertEquals(-3.0, m.easeCm, 1e-9)
        assertEquals(FitLevel.TOO_SMALL, m.level)                 // 팔 바깥보다 3cm 좁음 → 낄 수 있음
        assertEquals(FitLevel.GOOD, r.sizes[1].eases.first { it.item == BodyFitItem.SHOULDER_OUTER }.level)
        assertTrue(r.notes.any { "낄 수" in it })
        // 일반 옷(드롭숄더 아님)에는 어깨 바깥 비교를 붙이지 않는다
        val normal = BodyFitEngine.evaluate(body, chart("M" to Measurements(shoulderCm = 44.0, chestFlatCm = 55.0)))
        assertTrue(normal.sizes[0].eases.none { it.item == BodyFitItem.SHOULDER_OUTER })
    }

    @Test fun `circumference chart is used directly`() {
        val c = chart("M(95)" to Measurements(shoulderCm = 46.5, chestCircumferenceCm = 111.0), method = ChestMeasureMethod.CIRCUMFERENCE)
        val r = BodyFitEngine.evaluate(BodyProfile(heightCm = 175.0, chestCm = 96.0), c)
        assertEquals(15.0, r.sizes.single().eases.single { it.item == BodyFitItem.CHEST }.easeCm, 1e-9)
    }

    @Test fun `short sleeves are not compared with arm length`() {
        val c = chart("M" to Measurements(shoulderCm = 46.0, chestFlatCm = 53.0, sleeveCm = 21.0))
        val r = BodyFitEngine.evaluate(BodyProfile(heightCm = 175.0, chestCm = 96.0, armCm = 60.0), c)
        assertTrue(r.sizes.single().eases.none { it.item == BodyFitItem.SLEEVE })
    }

    /** 0.12.0 실기기: 몸 치수에 가슴·어깨가 없어 모든 상품이 "비교할 수 없어요"로 나온 경우 */
    @Test fun `without chest and shoulder sleeves are used and the user is told`() {
        val c = chart(
            "95" to Measurements(shoulderCm = 54.0, chestFlatCm = 56.0, lengthCm = 70.0, sleeveCm = 56.0),
            "105" to Measurements(shoulderCm = 58.0, chestFlatCm = 60.0, lengthCm = 74.0, sleeveCm = 60.0),
        )
        val r = BodyFitEngine.evaluate(BodyProfile(heightCm = 176.0, armCm = 60.0, waistCm = 82.0), c)
        assertTrue(r.isSuccess)
        assertTrue(r.notes.any { "소매 길이로만" in it })
        val none = BodyFitEngine.evaluate(BodyProfile(heightCm = 176.0, waistCm = 82.0), c)
        assertFalse(none.isSuccess)
        assertTrue(none.notes.any { "가슴둘레나 어깨너비가 없어" in it })
    }

    @Test fun `no common items gives no recommendation`() {
        val c = chart("M" to Measurements(lengthCm = 70.0))
        val r = BodyFitEngine.evaluate(BodyProfile(heightCm = 175.0, chestCm = 96.0), c)
        assertFalse(r.isSuccess)
    }

    @Test fun `validator requires height and rejects out of range values`() {
        val ok = BodyProfileValidator.validate(mapOf(BodyItem.HEIGHT to "175", BodyItem.CHEST to "96,5"), BodyShapeBase.MALE, PreferredFit.REGULAR)
        assertTrue(ok.isValid)
        assertEquals(96.5, ok.profile!!.chestCm!!, 1e-9)
        val noHeight = BodyProfileValidator.validate(mapOf(BodyItem.CHEST to "96"), BodyShapeBase.MALE, PreferredFit.REGULAR)
        assertTrue(BodyItem.HEIGHT in noHeight.errors)
        val bad = BodyProfileValidator.validate(mapOf(BodyItem.HEIGHT to "175", BodyItem.SHOULDER to "460"), BodyShapeBase.MALE, PreferredFit.REGULAR)
        assertTrue(BodyItem.SHOULDER in bad.errors)
    }

    @Test fun `mannequin follows entered height and widths`() {
        val p = BodyProfile(heightCm = 180.0, shoulderCm = 48.0, chestCm = 100.0, waistCm = 84.0, hipCm = 98.0, armCm = 60.0)
        val dims = MannequinDims.from(p)
        assertTrue(dims.estimated.isEmpty())
        val mesh = MannequinMesh.build(dims)
        val (min, max) = mesh.bounds()
        assertEquals(180.0, max[1].toDouble(), 1.5)                  // 정수리 높이 = 키
        assertTrue(min[1] >= -0.5f)                                  // 바닥 아래로 내려가지 않음
        assertTrue(mesh.vertexCount < Short.MAX_VALUE)                // GLES2 16비트 인덱스
        assertEquals(mesh.indices.size % 3, 0)
        assertTrue(mesh.normals.all { !it.isNaN() })
        // 가슴 단면 타원 둘레가 입력 둘레와 같도록 만든다
        val a = MannequinMesh.ellipseHalfWidth(100.0, 0.66)
        val b = a * 0.66
        val perimeter = Math.PI * (3 * (a + b) - Math.sqrt((3 * a + b) * (a + 3 * b)))
        assertTrue(abs(perimeter - 100.0) < 1e-6)
    }

    @Test fun `missing measurements are drawn from average ratios and reported`() {
        val dims = MannequinDims.from(BodyProfile(heightCm = 160.0, shapeBase = BodyShapeBase.FEMALE))
        assertEquals(listOf("어깨너비", "가슴둘레", "허리둘레", "엉덩이둘레", "팔길이"), dims.estimated)
        val (_, max) = MannequinMesh.build(dims).bounds()
        assertEquals(160.0, max[1].toDouble(), 1.5)
    }
}
