plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.brandme.fit"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.brandme.fit"
        minSdk = 34
        targetSdk = 36
        versionCode = 26
        versionName = "0.14.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // ML Kit 모델의 네이티브 라이브러리가 CPU 종류별로 들어가 APK 가 커진다. 현재 휴대폰(64비트 ARM)용만 넣는다.
        // (x86 에뮬레이터에서 돌리려면 "x86_64" 를 추가)
        ndk { abiFilters += listOf("arm64-v8a") }

        // AI 모드 서버 기본 주소. 에뮬레이터에서 호스트 PC의 FastAPI(8000)를 가리킨다.
        // API 키는 절대 앱에 넣지 않는다 — 키는 backend/.env 에만 있다.
        buildConfigField("String", "DEFAULT_AI_SERVER_URL", "\"http://10.0.2.2:8000/\"")
    }

    // MediaPipe 모델(.task)은 압축하지 않아야 바로 읽을 수 있다
    androidResources {
        noCompress += "task"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // 릴리스 서명은 README의 "릴리스 서명" 절차를 따른다 (키는 저장소에 포함하지 않음).
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.service)
    implementation(libs.androidx.navigation.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    debugImplementation(libs.androidx.compose.ui.tooling)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.datastore.preferences)

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.retrofit)
    implementation(libs.retrofit.kotlinx.serialization)
    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)

    // 온디바이스 한국어 OCR (모델이 APK에 포함됨, 네트워크/키 불필요)
    implementation(libs.mlkit.text.korean)

    // 사진으로 몸 치수 추정: 카메라 + 기기 안 전신 자세 인식(MediaPipe, 관절 + 몸 윤곽) — 사진은 저장·전송하지 않음
    implementation(libs.androidx.camera.camera2)
    implementation(libs.androidx.camera.lifecycle)
    implementation(libs.androidx.camera.view)
    implementation(libs.mediapipe.tasks.vision)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
}
