package com.brandme.fit.recognition

import kotlin.math.abs

/** OCR 한 줄과 그 위치(px). 표 재구성을 위해 좌표를 유지한다. */
data class TextLine(
    val text: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    /** 줄 안의 단어별 위치(ML Kit element). 표 칸을 위치로 맞출 때 쓴다. 없으면 빈 목록 */
    val words: List<TextLine> = emptyList(),
) {
    val centerY: Float get() = (top + bottom) / 2f
    val height: Int get() = bottom - top
}

/** 캡처 한 장에서 읽은 텍스트. 원본 이미지는 보관하지 않고 이 텍스트만 분석에 쓴다. */
data class ScreenText(val lines: List<TextLine>) {
    val fullText: String by lazy { lines.joinToString("\n") { it.text } }

    /**
     * 같은 높이에 있는 줄을 하나의 행으로 묶는다(표의 셀이 따로 인식되는 경우 대비).
     * 각 행은 왼쪽→오른쪽 순서로 탭 문자로 연결된다.
     */
    fun rows(): List<String> = RowAssembler.assemble(lines)
}

/** 사이즈표가 작게 보여 OCR 이 값을 놓쳤을 때, 표 부분만 잘라 확대해 다시 읽기 위한 영역 */
data class TableRegion(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val scale: Float,
    /** 헤더 행의 OCR 줄(원본 좌표). 칸별로 나눠 다시 읽을 때 쓴다. */
    val header: List<TextLine> = emptyList(),
) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top

    companion object {
        private const val TARGET_TEXT_PX = 40f
        private const val MAX_PIXELS = 12_000_000f
        private const val MAX_SIDE = 4000f

        /** 비교 항목이 2개 이상 있는 첫 헤더 행을 기준으로 그 아래 영역을 잡는다. 확대 이득이 없으면 null */
        fun find(screen: ScreenText, imageWidth: Int, imageHeight: Int): TableRegion? {
            val header = RowAssembler.groups(screen.lines).firstOrNull { row ->
                SizeChartTextParser.recognizedItems(row.joinToString("\t") { it.text }).size >= 2
            } ?: return null
            val textHeight = header.map { it.height }.sorted()[header.size / 2].coerceAtLeast(1)
            val marginX = (imageWidth * 0.05f).toInt()
            val left = (header.minOf { it.left } - marginX).coerceAtLeast(0)
            val right = (header.maxOf { it.right } + marginX).coerceAtMost(imageWidth)
            val top = (header.minOf { it.top } - textHeight * 2).coerceAtLeast(0)
            // 표 행은 보통 10줄 이내. 너무 크게 자르면 확대 후 이미지가 커져 OCR 이 다시 축소해 버릴 수 있다.
            val bottom = (top + minOf(imageHeight * 0.35f, textHeight * 30f).toInt()).coerceAtMost(imageHeight)
            if (right - left < 10 || bottom - top < 10) return null
            var scale = (TARGET_TEXT_PX / textHeight).coerceIn(1f, 4f)
            val pixels = (right - left).toFloat() * (bottom - top) * scale * scale
            if (pixels > MAX_PIXELS) scale *= kotlin.math.sqrt(MAX_PIXELS / pixels)
            scale = minOf(scale, MAX_SIDE / maxOf(right - left, bottom - top))
            if (scale < 1.3f) return null
            return TableRegion(left, top, right, bottom, scale, header)
        }
    }
}

object RowAssembler {
    fun assemble(lines: List<TextLine>): List<String> =
        groups(lines).map { row -> row.joinToString("\t") { it.text.trim() } }

    /** 같은 높이의 줄 묶음(왼쪽→오른쪽 정렬) */
    fun groups(lines: List<TextLine>): List<List<TextLine>> {
        if (lines.isEmpty()) return emptyList()
        val medianHeight = lines.map { it.height }.sorted()[lines.size / 2].coerceAtLeast(1)
        val tolerance = medianHeight * 0.6f
        val rows = mutableListOf<MutableList<TextLine>>()
        lines.sortedBy { it.centerY }.forEach { line ->
            val row = rows.lastOrNull()
            if (row != null && abs(row.map { it.centerY }.average().toFloat() - line.centerY) <= tolerance) {
                row += line
            } else {
                rows += mutableListOf(line)
            }
        }
        return rows.map { row -> row.sortedBy { it.left } }
    }
}
