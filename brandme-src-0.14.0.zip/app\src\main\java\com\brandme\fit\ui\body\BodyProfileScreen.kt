package com.brandme.fit.ui.body

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.brandme.fit.data.model.BodyProfileValidator
import com.brandme.fit.data.model.SkinTone
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.brandme.fit.appContainer
import com.brandme.fit.body3d.Mannequin3D
import com.brandme.fit.data.model.BodyItem
import com.brandme.fit.data.model.BodyShapeBase
import com.brandme.fit.data.model.PreferredFit

/** 내 몸 치수 입력 + 치수로 만든 3D 모형 미리보기 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BodyProfileScreen(onSaved: () -> Unit, onBack: (() -> Unit)?) {
    val container = LocalContext.current.appContainer
    val vm: BodyProfileViewModel = viewModel(factory = viewModelFactory { initializer { BodyProfileViewModel(container.body) } })
    val state by vm.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.saved) { if (state.saved) onSaved() }

    var photoMode by remember { mutableStateOf(false) }
    if (photoMode) {
        BackHandler { photoMode = false }
        BodyPhotoScreen(
            heightCm = state.preview.heightCm.takeIf { BodyProfileValidator.parse(state.inputs[BodyItem.HEIGHT].orEmpty()) != null },
            onApply = { vm.applyEstimates(it); photoMode = false },
            onClose = { photoMode = false },
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("내 몸 치수") },
                navigationIcon = { if (onBack != null) TextButton(onClick = onBack) { Text("뒤로") } },
            )
        },
    ) { padding ->
        if (!state.loaded) return@Scaffold
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Mannequin3D(
                state.preview,
                Modifier.fillMaxWidth().height(440.dp).clip(RoundedCornerShape(16.dp)),
                showCallouts = true,
            )
            val est = state.estimatedParts
            Text(
                if (est.isEmpty()) "입력한 치수에 맞춰 그린 모형이에요(근사). 좌우로 끌어 돌려 볼 수 있어요."
                else "입력하지 않은 ${est.joinToString(", ")}은(는) 평균 비율로 그렸어요. 사이즈 비교에는 입력한 값만 써요.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Text("모형 색", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SkinTone.entries.forEach { t ->
                    val selected = state.skin == t
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF000000.toInt() or t.rgb))
                            .border(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else Color(0x33000000), CircleShape)
                            .clickable { vm.setSkin(t) },
                    )
                }
            }

            Text("모형 체형", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BodyShapeBase.entries.forEach { s ->
                    FilterChip(selected = state.shape == s, onClick = { vm.setShape(s) }, label = { Text(s.label) })
                }
            }

            Text("치수", style = MaterialTheme.typography.labelLarge)
            OutlinedButton(onClick = { photoMode = true }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Text("정면·옆면 사진으로 재기 (키 먼저 입력)")
            }
            Text(
                "줄자로 속옷이나 얇은 옷 위에서 재 주세요. 키만 필수이고, 어깨너비·가슴둘레·팔길이를 넣으면 사이즈를 비교할 수 있어요.",
                style = MaterialTheme.typography.bodySmall,
            )
            BodyItem.entries.forEach { item ->
                OutlinedTextField(
                    value = state.inputs[item].orEmpty(),
                    onValueChange = { v -> vm.edit(item, v.filter { it.isDigit() || it == '.' || it == ',' }.take(6)) },
                    label = { Text(item.label + if (item == BodyItem.HEIGHT) " (필수)" else " (선택)") },
                    suffix = { Text(item.unit) },
                    singleLine = true,
                    isError = item in state.errors,
                    supportingText = { Text(state.errors[item] ?: item.guide) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Text("선호 핏", style = MaterialTheme.typography.labelLarge)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PreferredFit.entries.forEach { f ->
                    FilterChip(selected = state.fit == f, onClick = { vm.setFit(f) }, label = { Text(f.label) })
                }
            }
            Text(
                "선호 핏에 맞는 여유분에 가장 가까운 사이즈를 추천해요.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(onClick = vm::save, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("저장") }
            Text(
                "치수는 이 기기에만 저장되고 외부로 보내지 않아요.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
