package com.brandme.fit.body3d

import android.content.Context
import com.brandme.fit.data.model.BodyShapeBase
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * 몸에 묶인 옷 틀(MakeHuman CC0 "Shirts 01" 의 티셔츠·스웨터를 몸 메시에 다시 묶은 것).
 * 옷 정점 = 몸 삼각형 세 정점의 가중합 + 그 지점 법선 방향으로 offset.
 * 그래서 사용자의 체형으로 몸이 바뀌면 옷도 따라 바뀐다.
 */
class ClothesTemplate(
    val name: String,
    val gender: BodyShapeBase,
    val indices: IntArray,
    /** 정점마다 몸 정점 3개 */
    val bindVerts: IntArray,
    val bindWeights: FloatArray,
    val bindOffset: FloatArray,
) {
    val vertexCount: Int get() = bindOffset.size
}

class ClothesLibrary(val templates: Map<String, ClothesTemplate>) {

    /** 반팔이면 티셔츠(체형별), 긴팔이면 스웨터 */
    fun pick(gender: BodyShapeBase, shortSleeve: Boolean): ClothesTemplate? =
        if (shortSleeve) templates[if (gender == BodyShapeBase.FEMALE) "tee_female" else "tee_male"] ?: templates["tee_male"]
        else templates["sweater"]

    companion object {
        fun load(bin: ByteArray): ClothesLibrary {
            val buf = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN)
            val magic = ByteArray(4).also { buf.get(it) }
            require(String(magic) == "BMCL") { "not a clothes model" }
            require(buf.int == 1) { "unsupported version" }
            val count = buf.int
            val out = LinkedHashMap<String, ClothesTemplate>()
            repeat(count) {
                val nameBytes = ByteArray(buf.int).also { buf.get(it) }
                val gender = if (buf.int == 0) BodyShapeBase.MALE else BodyShapeBase.FEMALE
                val v = buf.int; val t = buf.int
                val idx = IntArray(t * 3) { buf.short.toInt() and 0xFFFF }
                val bv = IntArray(v * 3) { buf.short.toInt() and 0xFFFF }
                val bw = FloatArray(v * 3) { buf.float }
                val bd = FloatArray(v) { buf.float }
                val name = String(nameBytes)
                out[name] = ClothesTemplate(name, gender, idx, bv, bw, bd)
            }
            return ClothesLibrary(out)
        }
    }
}

object ClothesLibraryHolder {
    @Volatile private var lib: ClothesLibrary? = null
    @Volatile private var failed = false

    fun get(context: Context): ClothesLibrary? {
        lib?.let { return it }
        if (failed) return null
        return runCatching { ClothesLibrary.load(context.assets.open("body/clothes_model.bin").use { it.readBytes() }) }
            .onFailure { failed = true }.getOrNull()?.also { lib = it }
    }
}
