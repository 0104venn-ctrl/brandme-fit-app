package com.brandme.fit.comparison

import com.brandme.fit.data.model.ChestMeasureMethod
import com.brandme.fit.data.model.ComparisonError
import com.brandme.fit.data.model.ComparisonResult
import com.brandme.fit.data.model.ComparisonWarning
import com.brandme.fit.data.model.MeasureItem
import com.brandme.fit.data.model.MeasurementRules
import com.brandme.fit.data.model.ReferenceGarment
import com.brandme.fit.data.model.SizeChart
import com.brandme.fit.data.model.SizeComparison
import com.brandme.fit.data.model.VerificationStatus
import kotlin.math.abs
import kotlin.math.roundToLong

/**
 * 기준 옷 실측과 상품 사이즈표 실측을 비교한다.
 *
 * - 항목별 차이 diff = 상품 − 기준 옷
 * - 점수 = 양쪽 모두 값이 있는 항목들의 |diff| 평균 (낮을수록 가까움)
 * - 누락 항목은 건너뛴다. 비교 가능한 항목이 없으면 결과를 내지 않는다.
 * - 항목 구성이 다른 점수끼리는 순위를 매기지 않는다.
 * - 동점은 공동으로 가장 가까운 사이즈로 표시한다.
 * - 신축성, 소재, 핏 효과는 추정하지 않는다. 가슴 둘레 ↔ 단면 환산도 하지 않는다.
 */
object FitComparisonEngine {
    const val ALGORITHM_VERSION = "1.0.0"

    /** 기준 옷에서 비교에 쓰는 항목 (기준 옷은 가슴 둘레를 받지 않는다) */
    private val REFERENCE_ITEMS = listOf(
        MeasureItem.SHOULDER, MeasureItem.CHEST_FLAT, MeasureItem.LENGTH, MeasureItem.SLEEVE,
    )

    fun compare(
        reference: ReferenceGarment,
        chart: SizeChart,
        now: Long = System.currentTimeMillis(),
    ): ComparisonResult {
        fun fail(error: ComparisonError) = ComparisonResult(
            algorithmVersion = ALGORITHM_VERSION,
            referenceName = reference.name,
            source = chart.source,
            verification = chart.verification,
            closestSizes = emptyList(),
            rankedSizes = emptyList(),
            unrankedSizes = emptyList(),
            comparedItems = emptySet(),
            warnings = emptyList(),
            error = error,
            createdAt = now,
        )

        // 입력 검증 — 잘못된 값은 조용히 건너뛰지 않고 오류로 처리한다.
        val refItems = REFERENCE_ITEMS.filter { reference.measurements[it] != null }
        if (refItems.isEmpty() || MeasurementRules.invalidItems(reference.measurements).isNotEmpty()) {
            return fail(ComparisonError.REFERENCE_INCOMPLETE)
        }
        if (!chart.unit.equals("cm", ignoreCase = true)) return fail(ComparisonError.UNIT_NOT_CM)
        if (chart.sizes.isEmpty()) return fail(ComparisonError.NO_SIZES)
        val labels = chart.sizes.map { it.label.trim().uppercase() }
        if (labels.toSet().size != labels.size) return fail(ComparisonError.DUPLICATE_SIZE_LABELS)
        if (chart.sizes.any { MeasurementRules.invalidItems(it.measurements).isNotEmpty() }) {
            return fail(ComparisonError.INVALID_CHART_VALUES)
        }

        val comparisons = chart.sizes.map { size ->
            val items = refItems.filter { size.measurements[it] != null }.toSet()
            val diffs = items.associateWith { item ->
                round1(size.measurements[item]!! - reference.measurements[item]!!)
            }
            val score = if (items.isEmpty()) null else diffs.values.sumOf { abs(it) } / items.size
            SizeComparison(size.label, diffs, items, score)
        }

        // 가장 많은 항목으로 비교된 그룹만 순위를 매긴다. (항목 수가 같으면 사이즈 수가 많은 그룹)
        val groups = comparisons.filter { it.comparedItems.isNotEmpty() }.groupBy { it.comparedItems }
        if (groups.isEmpty()) return fail(ComparisonError.NO_COMPARABLE_ITEMS)
        val primaryItems = groups.keys.maxWith(
            compareBy<Set<MeasureItem>> { it.size }
                .thenBy { groups.getValue(it).size }
                .thenBy { set -> -set.sumOf { it.ordinal } }
        )
        val ranked = groups.getValue(primaryItems).sortedBy { it.score }
        val unranked = comparisons.filter { it.comparedItems != primaryItems }

        val best = scoreKey(ranked.first().score!!)
        val closest = ranked.filter { scoreKey(it.score!!) == best }.map { it.sizeLabel }

        val chestNotComparable = MeasureItem.CHEST_FLAT in refItems &&
            MeasureItem.CHEST_FLAT !in primaryItems &&
            (chart.chestMethod == ChestMeasureMethod.CIRCUMFERENCE ||
                chart.sizes.any { it.measurements.chestCircumferenceCm != null })

        val warnings = buildList {
            if (primaryItems.size == 1) add(ComparisonWarning.SINGLE_ITEM)
            if (unranked.isNotEmpty()) add(ComparisonWarning.MIXED_ITEM_SETS)
            if (chestNotComparable) add(ComparisonWarning.CHEST_METHOD_MISMATCH)
            if (refItems.any { it !in primaryItems && !(it == MeasureItem.CHEST_FLAT && chestNotComparable) }) {
                add(ComparisonWarning.REFERENCE_ITEM_MISSING_IN_CHART)
            }
            when (chart.verification) {
                VerificationStatus.DEMO -> add(ComparisonWarning.DEMO_DATA)
                VerificationStatus.UNVERIFIED -> add(ComparisonWarning.UNVERIFIED_DATA)
                VerificationStatus.VERIFIED -> Unit
            }
        }

        return ComparisonResult(
            algorithmVersion = ALGORITHM_VERSION,
            referenceName = reference.name,
            source = chart.source,
            verification = chart.verification,
            closestSizes = closest,
            rankedSizes = ranked,
            unrankedSizes = unranked,
            comparedItems = primaryItems,
            warnings = warnings,
            error = null,
            createdAt = now,
        )
    }

    private fun round1(v: Double): Double = (v * 10).roundToLong() / 10.0

    /** 부동소수 오차로 동점이 갈리지 않도록 0.001 단위로 비교 */
    private fun scoreKey(score: Double): Long = (score * 1000).roundToLong()
}
