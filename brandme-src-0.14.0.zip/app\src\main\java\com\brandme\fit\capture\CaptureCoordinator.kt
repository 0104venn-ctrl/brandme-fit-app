package com.brandme.fit.capture

import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ProjectionState { INACTIVE, AWAITING_CONSENT, ACTIVE }

sealed interface CaptureResult {
    /** 호출자가 bitmap 을 사용 후 recycle 해야 한다. 파일로 저장하지 않는다. */
    data class Ok(val bitmap: Bitmap) : CaptureResult
    /** 화면이 거의 전부 검정 — FLAG_SECURE 보호 화면이거나 빈 화면. 우회하지 않는다. */
    data object ProtectedOrBlank : CaptureResult
    data class Failed(val reason: String) : CaptureResult
    data object NoSession : CaptureResult
}

sealed interface ConsentEvent {
    data object Granted : ConsentEvent
    data object Denied : ConsentEvent
    data class Ended(val reason: String) : ConsentEvent
}

fun interface ScreenCapturer {
    suspend fun capture(requestedAtNanos: Long): CaptureResult
}

/** 오버레이 서비스 ↔ 캡처 서비스 ↔ 홈 화면 사이의 상태 공유 지점 (프로세스 내 싱글톤). */
object CaptureCoordinator {
    private val _projection = MutableStateFlow(ProjectionState.INACTIVE)
    val projection: StateFlow<ProjectionState> = _projection.asStateFlow()

    private val _overlayRunning = MutableStateFlow(false)
    val overlayRunning: StateFlow<Boolean> = _overlayRunning.asStateFlow()

    private val _analyzing = MutableStateFlow(false)
    val analyzing: StateFlow<Boolean> = _analyzing.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _events = MutableSharedFlow<ConsentEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<ConsentEvent> = _events.asSharedFlow()

    @Volatile
    private var capturer: ScreenCapturer? = null

    fun onAwaitingConsent() {
        _projection.value = ProjectionState.AWAITING_CONSENT
    }

    fun onConsentDenied() {
        _projection.value = ProjectionState.INACTIVE
        _lastError.value = "화면 캡처 승인이 거부되었어요."
        _events.tryEmit(ConsentEvent.Denied)
    }

    fun attach(c: ScreenCapturer) {
        capturer = c
        _projection.value = ProjectionState.ACTIVE
        _lastError.value = null
        _events.tryEmit(ConsentEvent.Granted)
    }

    fun detach(c: ScreenCapturer, reason: String) {
        if (capturer === c) capturer = null
        if (capturer == null) {
            _projection.value = ProjectionState.INACTIVE
            _events.tryEmit(ConsentEvent.Ended(reason))
        }
    }

    /** [overlayHiddenAtNanos] 이후에 그려진 프레임(오버레이가 없는 화면)을 우선 사용한다. */
    suspend fun capture(overlayHiddenAtNanos: Long): CaptureResult =
        capturer?.capture(overlayHiddenAtNanos) ?: CaptureResult.NoSession

    val hasSession: Boolean get() = capturer != null

    fun setOverlayRunning(running: Boolean) {
        _overlayRunning.value = running
    }

    fun setAnalyzing(analyzing: Boolean) {
        _analyzing.value = analyzing
    }

    fun reportError(message: String?) {
        _lastError.value = message
    }
}
