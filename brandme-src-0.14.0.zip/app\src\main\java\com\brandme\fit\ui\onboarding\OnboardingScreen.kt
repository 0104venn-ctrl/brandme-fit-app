package com.brandme.fit.ui.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.brandme.fit.Routes
import com.brandme.fit.appContainer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun Logo(size: Int = 96) {
    Box(
        Modifier.size(size.dp).background(MaterialTheme.colorScheme.primary, CircleShape),
        contentAlignment = Alignment.Center,
    ) { Text("Fit", color = Color.White, fontSize = (size / 3).sp, fontWeight = FontWeight.Bold) }
}

/** SCR-01: 로고 → 프로필 없으면 온보딩, 있으면 홈 */
@Composable
fun SplashScreen(onResolved: (String) -> Unit) {
    val container = LocalContext.current.appContainer
    LaunchedEffect(Unit) {
        delay(400)
        val hasBasis = container.body.get() != null
        onResolved(if (hasBasis) Routes.HOME else Routes.ONBOARDING)
    }
    Surface(Modifier.fillMaxSize()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Logo()
            Spacer(Modifier.height(16.dp))
            Text("brandme Fit", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}

/** SCR-02 */
@Composable
fun OnboardingScreen(onStart: () -> Unit) {
    val container = LocalContext.current.appContainer
    val scope = rememberCoroutineScope()
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.safeDrawingPadding().padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Spacer(Modifier.height(24.dp))
            Logo(64)
            Text(
                "쇼핑하던 그대로, 내 사이즈를 확인하세요.",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )
            Step(1, "내 몸 치수 저장", "키와 어깨너비·가슴둘레 등을 직접 입력하거나, 정면·옆면 사진으로 재요.")
            Step(2, "쇼핑 앱에서 버튼 누르기", "무신사·지그재그·에이블리 상품 화면에서 Fit 버튼을 눌러요.")
            Step(3, "내 몸에 맞는 사이즈 확인", "상품 사이즈표와 내 몸 치수를 비교해 선호 핏에 가까운 사이즈를 쇼핑 앱 위에서 보여 줘요.")
            Spacer(Modifier.weight(1f))
            Text(
                "실측 비교 결과이며 실제 착용감이나 사이즈 적합도를 보장하지 않습니다.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(
                onClick = { scope.launch { container.settings.setOnboardingDone(); onStart() } },
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("시작하기") }
        }
    }
}

@Composable
private fun Step(n: Int, title: String, body: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            Modifier.size(28.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
            contentAlignment = Alignment.Center,
        ) { Text("$n", fontWeight = FontWeight.Bold) }
        Column {
            Text(title, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
