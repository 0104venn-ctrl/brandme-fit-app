package com.brandme.fit.ui.home

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.brandme.fit.appContainer
import com.brandme.fit.capture.MediaProjectionService
import com.brandme.fit.capture.ProjectionState
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import com.brandme.fit.body3d.Mannequin3D
import com.brandme.fit.data.model.BodyItem
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.MeasureItem
import com.brandme.fit.overlay.FloatingOverlayService
import com.brandme.fit.recognition.AnalysisMode
import com.brandme.fit.ui.result.OutcomeContent
import com.brandme.fit.ui.result.ResultFormatter
import com.brandme.fit.ui.theme.DemoAmber
import com.brandme.fit.ui.theme.OkGreen
import com.brandme.fit.ui.theme.WarnRed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun homeViewModel(): HomeViewModel {
    val container = LocalContext.current.appContainer
    return viewModel(factory = viewModelFactory { initializer { HomeViewModel(container) } })
}

/** SCR-04 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onEditBody: () -> Unit, onPrivacy: () -> Unit) {
    val context = LocalContext.current
    val vm = homeViewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    val demo by vm.demoOutcome.collectAsStateWithLifecycle()
    val body by vm.body.collectAsStateWithLifecycle()
    var explainOverlay by remember { mutableStateOf(false) }
    var explainNotification by remember { mutableStateOf(false) }

    LifecycleResumeEffect(Unit) {
        vm.refreshPermission(Settings.canDrawOverlays(context))
        onPauseOrDispose { }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        // 거부해도 버튼은 동작한다(알림만 보이지 않음).
        FloatingOverlayService.start(context)
    }

    fun turnOn() {
        when {
            !Settings.canDrawOverlays(context) -> explainOverlay = true
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED ->
                explainNotification = true
            else -> FloatingOverlayService.start(context)
        }
    }

    if (explainOverlay) {
        AlertDialog(
            onDismissRequest = { explainOverlay = false },
            title = { Text("다른 앱 위에 표시 권한") },
            text = {
                Text(
                    "쇼핑 앱 위에 Fit 버튼과 비교 결과를 띄우려면 '다른 앱 위에 표시' 권한이 필요해요. " +
                        "설정 화면에서 brandme Fit을 허용한 뒤 돌아와 주세요. 이 권한으로 다른 앱의 내용을 읽지는 않아요.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    explainOverlay = false
                    openOverlaySettings(context)
                }) { Text("설정으로 이동") }
            },
            dismissButton = { TextButton(onClick = { explainOverlay = false }) { Text("나중에") } },
        )
    }
    if (explainNotification) {
        AlertDialog(
            onDismissRequest = { explainNotification = false },
            title = { Text("알림 권한") },
            text = { Text("버튼과 캡처가 켜져 있는 동안 알림으로 상태를 보여 주고, 알림에서 바로 중지할 수 있어요.") },
            confirmButton = {
                TextButton(onClick = {
                    explainNotification = false
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }) { Text("계속") }
            },
            dismissButton = {
                TextButton(onClick = {
                    explainNotification = false
                    FloatingOverlayService.start(context)
                }) { Text("알림 없이 켜기") }
            },
        )
    }
    demo?.let { outcome ->
        AlertDialog(
            onDismissRequest = vm::dismissDemo,
            confirmButton = {},
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Demo 체험 결과 (캡처 없이 Demo 카탈로그 사용)", color = DemoAmber, fontWeight = FontWeight.Bold)
                    OutcomeContent(outcome, onClose = vm::dismissDemo, onPickCandidate = {})
                }
            },
        )
    }

    Scaffold(topBar = { TopAppBar(title = { Text("brandme Fit") }) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            StatusCard(state, onToggle = { on -> if (on) turnOn() else FloatingOverlayService.stop(context) },
                onStopCapture = { MediaProjectionService.stop(context) },
                onFixOverlay = { explainOverlay = true },
                onClearError = vm::clearError)
            BodyCard(body, onEditBody)
            DemoCard(vm, state.settings.mode)
            HistoryCard(state)
            OutlinedButton(onClick = onPrivacy, modifier = Modifier.fillMaxWidth()) { Text("개인정보 · 분석 모드 · 데이터 삭제") }
        }
    }
}

fun openOverlaySettings(context: Context) {
    context.startActivity(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
    )
}

@Composable
private fun StatusCard(
    s: HomeUiState,
    onToggle: (Boolean) -> Unit,
    onStopCapture: () -> Unit,
    onFixOverlay: () -> Unit,
    onClearError: () -> Unit,
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val color = when (s.status) {
                HomeStatus.ERROR, HomeStatus.NEED_OVERLAY -> WarnRed
                HomeStatus.CAPTURE_ACTIVE, HomeStatus.READY -> OkGreen
                else -> MaterialTheme.colorScheme.primary
            }
            Text("상태: ${s.status.label}", color = color, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            s.lastError?.let {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    TextButton(onClick = onClearError) { Text("확인") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("플로팅 버튼", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Switch(checked = s.overlayRunning, onCheckedChange = onToggle)
            }
            StatusLine("오버레이 권한", if (s.overlayPermission) "허용됨" else "필요")
            if (!s.overlayPermission) TextButton(onClick = onFixOverlay) { Text("권한 설정하기") }
            StatusLine(
                "화면 캡처",
                when (s.projection) {
                    ProjectionState.ACTIVE -> "활성화 (세션 진행 중)"
                    ProjectionState.AWAITING_CONSENT -> "승인 대기"
                    ProjectionState.INACTIVE -> "버튼을 누를 때 승인 요청"
                },
            )
            if (s.projection == ProjectionState.ACTIVE) TextButton(onClick = onStopCapture) { Text("캡처 세션 종료") }
            StatusLine("서비스", if (s.overlayRunning) "실행 중" else "꺼짐")
            StatusLine("분석 모드", if (s.settings.mode == AnalysisMode.DEMO) "Demo Mode (외부 전송 없음)" else "AI Mode")
        }
    }
}

@Composable
private fun StatusLine(label: String, value: String) {
    Row {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun BodyCard(p: BodyProfile?, onEdit: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("내 몸 치수", style = MaterialTheme.typography.labelLarge)
            if (p == null) {
                Text("저장된 몸 치수가 없어요. 키와 어깨너비·가슴둘레를 넣으면 내 몸 기준으로 사이즈를 비교해요.")
            } else {
                Mannequin3D(p, Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(12.dp)))
                BodyItem.entries.forEach { item ->
                    p[item]?.let { StatusLine(item.label, "${ResultFormatter.cm(it)} ${item.unit}") }
                }
                StatusLine("선호 핏", p.preferredFit.label)
            }
            TextButton(onClick = onEdit) { Text(if (p == null) "몸 치수 입력" else "몸 치수 수정") }
        }
    }
}

@Composable
private fun DemoCard(vm: HomeViewModel, mode: AnalysisMode) {
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Demo 체험", style = MaterialTheme.typography.labelLarge)
            Text(
                "캡처 없이 Demo 카탈로그 상품으로 비교 흐름을 확인해요. 결과는 실제 상품 정보가 아닌 Demo로 표시돼요.",
                style = MaterialTheme.typography.bodySmall,
            )
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "목록 닫기" else "Demo 상품 고르기 (${vm.demoProducts.size}개)") }
            if (expanded) vm.demoProducts.forEach { p ->
                TextButton(onClick = { vm.runDemo(p.id) }) { Text("[DEMO] ${p.brand} ${p.name}") }
            }
        }
    }
}

@Composable
private fun HistoryCard(s: HomeUiState) {
    val fmt = remember { SimpleDateFormat("MM.dd HH:mm", Locale.KOREA) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("최근 비교 기록", style = MaterialTheme.typography.labelLarge)
            if (s.history.isEmpty()) Text("아직 기록이 없어요.", style = MaterialTheme.typography.bodySmall)
            s.history.take(10).forEach { h ->
                Column {
                    Row {
                        Text(h.productName, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        if (h.isDemo) Text("DEMO", color = DemoAmber, style = MaterialTheme.typography.labelSmall)
                    }
                    Text("${fmt.format(Date(h.createdAt))} · ${h.summary}", style = MaterialTheme.typography.bodySmall,
                        color = if (h.error != null) WarnRed else MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}
