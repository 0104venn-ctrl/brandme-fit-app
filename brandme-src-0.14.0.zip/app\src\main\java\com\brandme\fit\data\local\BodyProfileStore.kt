package com.brandme.fit.data.local

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.BodyShapeBase
import com.brandme.fit.data.model.PreferredFit
import com.brandme.fit.data.model.SkinTone
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.bodyStore by preferencesDataStore(name = "body_profile")

/** 내 몸 치수 1개를 기기 안에만 저장한다(외부 전송 없음). */
class BodyProfileStore(private val context: Context) {
    private object Keys {
        val HEIGHT = doublePreferencesKey("height")
        val WEIGHT = doublePreferencesKey("weight")
        val SHOULDER = doublePreferencesKey("shoulder")
        val SHOULDER_OUTER = doublePreferencesKey("shoulder_outer")
        val CHEST = doublePreferencesKey("chest")
        val WAIST = doublePreferencesKey("waist")
        val HIP = doublePreferencesKey("hip")
        val ARM = doublePreferencesKey("arm")
        val SHAPE = stringPreferencesKey("shape")
        val FIT = stringPreferencesKey("fit")
        val SKIN = stringPreferencesKey("skin")
        val UPDATED = longPreferencesKey("updated")
    }

    val profile: Flow<BodyProfile?> = context.bodyStore.data.map { it.toProfile() }

    suspend fun get(): BodyProfile? = profile.first()

    private fun Preferences.toProfile(): BodyProfile? {
        val height = this[Keys.HEIGHT] ?: return null
        return BodyProfile(
            heightCm = height,
            weightKg = this[Keys.WEIGHT],
            shoulderCm = this[Keys.SHOULDER],
            shoulderOuterCm = this[Keys.SHOULDER_OUTER],
            chestCm = this[Keys.CHEST],
            waistCm = this[Keys.WAIST],
            hipCm = this[Keys.HIP],
            armCm = this[Keys.ARM],
            shapeBase = this[Keys.SHAPE]?.let { runCatching { BodyShapeBase.valueOf(it) }.getOrNull() } ?: BodyShapeBase.MALE,
            preferredFit = this[Keys.FIT]?.let { runCatching { PreferredFit.valueOf(it) }.getOrNull() } ?: PreferredFit.REGULAR,
            skinTone = this[Keys.SKIN]?.let { runCatching { SkinTone.valueOf(it) }.getOrNull() } ?: SkinTone.MANNEQUIN,
            updatedAt = this[Keys.UPDATED] ?: 0L,
        )
    }

    suspend fun save(p: BodyProfile) = context.bodyStore.edit { e ->
        e.clear()
        e[Keys.HEIGHT] = p.heightCm
        p.weightKg?.let { e[Keys.WEIGHT] = it }
        p.shoulderCm?.let { e[Keys.SHOULDER] = it }
        p.shoulderOuterCm?.let { e[Keys.SHOULDER_OUTER] = it }
        p.chestCm?.let { e[Keys.CHEST] = it }
        p.waistCm?.let { e[Keys.WAIST] = it }
        p.hipCm?.let { e[Keys.HIP] = it }
        p.armCm?.let { e[Keys.ARM] = it }
        e[Keys.SHAPE] = p.shapeBase.name
        e[Keys.FIT] = p.preferredFit.name
        e[Keys.SKIN] = p.skinTone.name
        e[Keys.UPDATED] = p.updatedAt
    }

    suspend fun clear() = context.bodyStore.edit { it.clear() }
}
