package com.brandme.fit.data.model

/** 상품 식별 상태. 사이즈표 출처 검증과는 별개로 관리한다. */
enum class IdentificationStatus(val label: String) {
    EXACT_MATCH("상품 확인됨"),
    CANDIDATE_MATCH("후보 상품"),
    AMBIGUOUS("여러 후보"),
    NOT_FOUND("상품 미확인"),
}

/** 사이즈표를 어디서 얻었는지 */
enum class SizeChartSource(val label: String) {
    LOCAL_CATALOG("로컬 카탈로그"),
    SCREEN_CAPTURE("현재 화면의 사이즈표(온디바이스 OCR)"),
    AI_SERVER("AI 서버가 화면에서 추출"),
}

/**
 * 데이터 신뢰 상태.
 * VERIFIED 는 실제로 확인한 데이터에만 쓴다. 임의로 만든 데이터는 반드시 DEMO.
 */
enum class VerificationStatus(val label: String) {
    VERIFIED("검증됨"),
    DEMO("Demo 데이터 · 실제 상품 정보 아님"),
    UNVERIFIED("미검증 · 화면에서 읽은 값"),
}

enum class ChestMeasureMethod { FLAT, CIRCUMFERENCE, UNKNOWN }

data class ProductSize(val label: String, val measurements: Measurements)

data class SizeChart(
    val sizes: List<ProductSize>,
    val unit: String = "cm",
    val source: SizeChartSource,
    val verification: VerificationStatus,
    val sourceDetail: String? = null,
    val verifiedAt: String? = null,
    val chestMethod: ChestMeasureMethod = ChestMeasureMethod.UNKNOWN,
    /** 표에 있었지만 사전에 없거나 판단할 수 없어 비교에서 뺀 항목명 */
    val skippedItems: List<String> = emptyList(),
)

data class ProductCandidate(
    val id: String,
    val brand: String,
    val name: String,
    val shop: String?,
    val score: Double,
)

data class DetectedProduct(
    val id: String? = null,
    val brand: String? = null,
    val name: String? = null,
    val shop: String? = null,
    val productCode: String? = null,
    val status: IdentificationStatus,
    val candidates: List<ProductCandidate> = emptyList(),
    val isDemo: Boolean = false,
    /** 사용자가 후보 목록에서 직접 고른 경우 */
    val userConfirmed: Boolean = false,
) {
    val displayName: String
        get() = listOfNotNull(brand, name).joinToString(" ").ifBlank { "상품명 미확인" }
}
