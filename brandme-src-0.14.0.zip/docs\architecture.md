# 아키텍처

## 흐름

```
[쇼핑 앱 화면]
     ▲ (결과 패널: 화면 하단 일부, 포커스 안 가져감 → 쇼핑 계속 가능)
     │
FloatingOverlayService (FGS specialUse, TYPE_APPLICATION_OVERLAY)
  ├─ 버튼 탭 → 기준 옷 확인 → 캡처 세션 없으면 "캡처 목적 안내" 카드
  │      └─ 계속 → CaptureConsentActivity (투명) → MediaProjectionManager.createScreenCaptureIntent()
  │              └─ 승인 → MediaProjectionService 시작 (FGS mediaProjection)
  │                      └─ getMediaProjection → registerCallback → VirtualDisplay 1개 + ImageReader
  │                      └─ CaptureCoordinator.attach() → Granted 이벤트 → 분석 자동 시작
  ├─ 분석: 오버레이 숨김 → CaptureCoordinator.capture(숨긴 시각) → Bitmap(메모리)
  │      → AnalysisPipeline
  │          1. ML Kit 한국어 OCR (기기 내)
  │          2. SensitiveScreenDetector (결제/계정/메시지면 중단 — 외부 전송 전)
  │          3. ProductMatcher (로컬 카탈로그, EXACT 만 표 사용)
  │          4. SizeChartTextParser (화면에 보이는 표)
  │          5. [AI Mode + 동의] RemoteAnalyzer → backend /api/analyze-screen
  │          6. FitComparisonEngine (항상 기기에서)
  │      → Bitmap recycle, 결과 요약만 Room 에 기록
  └─ 결과/오류 패널 → 닫기 → 버튼만 남음
```

## 패키지

| 경로 | 역할 |
|---|---|
| `ui/onboarding` | SCR-01 스플래시, SCR-02 온보딩 |
| `ui/profile` | SCR-03 기준 옷 입력 (ViewModel + 검증) |
| `ui/home` | SCR-04 홈 상태/토글/기록/Demo 체험, 개인정보·모드·삭제 화면 |
| `ui/result` | SCR-06/07/08 오버레이 패널 Compose UI, `ResultFormatter`(문구) |
| `overlay/FloatingOverlayService.kt` | SCR-05 버튼(드래그·가장자리 스냅·위치 저장), 패널 창 관리 |
| `capture/CaptureCoordinator.kt` | 서비스 간 상태(StateFlow)·이벤트(SharedFlow) 공유 |
| `capture/MediaProjectionService.kt` | 캡처 세션, 회전/크기 변경, onStop, 자원 해제 |
| `capture/CaptureConsentActivity.kt` | 시스템 동의 창 결과 수신 |
| `recognition/` | OCR, 행 재구성, 사이즈표 파서, 상품 매칭, 민감 화면, 원격 분석, 파이프라인 |
| `catalog/` | `assets/demo_products.json` 모델·검증·로더 |
| `comparison/FitComparisonEngine.kt` | 비교 알고리즘 v1.0.0 (순수 Kotlin) |
| `data/model` | ReferenceGarment, DetectedProduct, ProductSize, SizeChart, ComparisonResult 등 |
| `data/local` | Room(기준 옷, 비교 기록), DataStore(설정·버튼 위치·모드·동의) |
| `data/repository` | 저장소 |

MVVM: 화면 상태는 ViewModel 의 `StateFlow` 로 노출하고 Compose 는 `collectAsStateWithLifecycle` 로 구독한다.
서비스는 ViewModel 대신 `AppContainer`(수동 DI)와 `CaptureCoordinator` 를 사용한다.

## 데이터 신뢰 구분

| 출처 (`SizeChartSource`) | 검증 상태 (`VerificationStatus`) | 결과 표시 |
|---|---|---|
| LOCAL_CATALOG, source=`demo` | DEMO | DEMO 배지 + "실제 상품 정보 아님" |
| LOCAL_CATALOG, source=`verified` + verifiedAt | VERIFIED | (현재 카탈로그에 없음) |
| SCREEN_CAPTURE (OCR) | UNVERIFIED | "화면에서 읽은 미검증 값" |
| AI_SERVER | UNVERIFIED | "화면에서 읽은 미검증 값" |

상품 식별 상태(`IdentificationStatus`)는 출처와 별도로 표시한다. 식별되지 않았지만 화면에 표가 보이면
"상품 미확인 · 화면 표 기준" 경고와 함께 비교한다. 후보 상품(CANDIDATE/AMBIGUOUS)의 카탈로그 표는
사용자가 직접 고르기 전에는 쓰지 않는다.

## 비교 알고리즘 v1.0.0

- 항목: 어깨, 가슴 단면, 총장, 소매. 가슴 둘레는 별도 항목이며 단면과 환산·비교하지 않는다.
- diff = 상품 − 기준 옷 (0.1cm 반올림), score = 공통 항목 |diff| 평균.
- 항목 구성이 같은 사이즈끼리만 순위. 가장 많은 항목 그룹(동률이면 사이즈가 많은 그룹)이 기준.
- 0.001 단위로 동점 판정 → 공동 1위.
- 입력에 0·음수·범위 밖·NaN·중복 라벨·cm 아닌 단위가 있으면 결과 없이 오류.
- 서버(`backend/app/compare.py`)에도 같은 알고리즘이 있지만 앱은 항상 기기에서 계산한다.
