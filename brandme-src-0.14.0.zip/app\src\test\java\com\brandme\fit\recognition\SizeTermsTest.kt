package com.brandme.fit.recognition

import com.brandme.fit.recognition.SizeChartTextParser.Column
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SizeTermsTest {

    private fun c(s: String) = SizeChartTextParser.classifyHeader(s)

    @Test fun `every dictionary term is stored in normalized form`() {
        SizeTerms.TERMS.keys.forEach { k -> assertEquals("term '$k'", k, SizeTerms.normalize(k)) }
    }

    @Test fun `every dictionary term classifies to its own column`() {
        SizeTerms.TERMS.forEach { (k, col) -> assertEquals("term '$k'", col, c(k)) }
    }

    /** "소매" 글자가 들어간 이름이 모두 소매가 되던 문제(0.4.x 실기기 실패) */
    @Test fun `sleeve-like names are not all sleeve`() {
        assertEquals(Column.SLEEVE, c("소매길이"))
        assertEquals(Column.SLEEVE, c("소매 기장"))
        assertEquals(Column.SLEEVE, c("팔길이"))
        listOf("소매통", "소매밑단너비", "소매 밑단", "소매단면", "소매둘레", "소매부리", "팔통", "화장").forEach {
            assertEquals(it, Column.IGNORE, c(it))
        }
    }

    @Test fun `decided items from the review`() {
        assertEquals(Column.CHEST_FLAT, c("가슴너비"))
        assertEquals(Column.CHEST_FLAT, c("가슴폭"))
        assertEquals(Column.CHEST_FLAT, c("가슴 (단면)"))
        assertEquals(Column.CHEST_CIRC, c("가슴둘레"))
        assertEquals(Column.BUST, c("바스트"))
        assertEquals(Column.LENGTH, c("기장"))
        assertEquals(Column.IGNORE, c("앞기장"))
        assertEquals(Column.IGNORE, c("앞품"))
        assertEquals(Column.IGNORE, c("어깨길이"))
        assertEquals(Column.BOTTOM, c("허벅지"))
        assertEquals(Column.BOTTOM, c("밑위"))
    }

    @Test fun `numbering units and invisible characters are removed`() {
        assertEquals(Column.LENGTH, c("7.총길이"))
        assertEquals(Column.CHEST_FLAT, c("② 가슴단면(cm)"))
        assertEquals(Column.IGNORE, c("체중 (kg)"))
        assertEquals(Column.IGNORE, c("소매​통"))
        assertEquals(Column.SHOULDER, c("Shoulder (cm)"))
    }

    @Test fun `ocr typos are corrected only toward dictionary words`() {
        assertEquals(Column.SHOULDER, c("어개"))
        assertEquals(Column.LENGTH, c("층걸이"))
        assertEquals(Column.LENGTH, c("종기장"))
        assertEquals(Column.CHEST_CIRC, c("가슴둘래"))
    }

    @Test fun `unrelated words stay unknown`() {
        listOf("배송", "색상", "상품번호", "제조국", "세탁").forEach { assertNull(it, c(it)) }
    }

    @Test fun `unknown table row is skipped and reported in vertical table`() {
        fun cell(t: String, col: Int, y: Int) = TextLine(t, 80 + col * 150 - 20, y, 80 + col * 150 + 20, y + 14)
        fun row(y: Int, vararg t: String) = t.mapIndexed { i, s -> cell(s, i, y) }
        val lines = row(100, "사이즈", "M", "L") +
            row(140, "어깨너비", "46", "48") +
            row(180, "가슴단면폭넓이", "55", "57") + // 사전에 없는 이름
            row(220, "총장", "68", "70")
        val chart = (NumberGrid.read(lines)!!.result as SizeChartTextParser.Result.Found).chart
        assertEquals(listOf("가슴단면폭넓이"), chart.skippedItems)
        assertEquals(null, chart.sizes[0].measurements.chestFlatCm)
        assertEquals(68.0, chart.sizes[0].measurements.lengthCm!!, 1e-9)
    }

    @Test fun `bust becomes circumference only when values are large`() {
        fun cell(t: String, col: Int, y: Int) = TextLine(t, 80 + col * 150 - 20, y, 80 + col * 150 + 20, y + 14)
        fun row(y: Int, vararg t: String) = t.mapIndexed { i, s -> cell(s, i, y) }
        val big = row(100, "사이즈", "어깨", "바스트", "총장") + row(140, "S", "40", "88", "60") + row(180, "M", "42", "92", "62")
        val bigChart = (NumberGrid.read(big)!!.result as SizeChartTextParser.Result.Found).chart
        assertEquals(88.0, bigChart.sizes[0].measurements.chestCircumferenceCm!!, 1e-9)

        val small = row(100, "사이즈", "어깨", "바스트", "총장") + row(140, "S", "40", "46", "60") + row(180, "M", "42", "48", "62")
        val smallChart = (NumberGrid.read(small)!!.result as SizeChartTextParser.Result.Found).chart
        assertEquals(null, smallChart.sizes[0].measurements.chestFlatCm)
        assertTrue(smallChart.skippedItems.single().startsWith("바스트"))
    }

    @Test fun `bottoms table is recognized and not compared`() {
        fun cell(t: String, col: Int, y: Int) = TextLine(t, 80 + col * 150 - 20, y, 80 + col * 150 + 20, y + 14)
        fun row(y: Int, vararg t: String) = t.mapIndexed { i, s -> cell(s, i, y) }
        val lines = row(100, "사이즈", "허리", "엉덩이", "허벅지", "밑위", "총장") +
            row(140, "S", "36", "50", "30", "28", "100") + row(180, "M", "38", "52", "31", "29", "101")
        val r = NumberGrid.read(lines)!!.result
        assertTrue(r is SizeChartTextParser.Result.Unreadable && r.reason.startsWith("하의"))
    }
}
