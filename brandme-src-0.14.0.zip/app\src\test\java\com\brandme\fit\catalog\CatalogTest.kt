package com.brandme.fit.catalog

import com.brandme.fit.data.model.SizeChartSource
import com.brandme.fit.data.model.VerificationStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class CatalogTest {

    private fun product(
        source: String = "demo", verifiedAt: String? = null, sourceDetail: String? = "detail",
        unit: String = "cm", sizes: List<CatalogSize> = listOf(CatalogSize("M", 46.0, 52.0, null, 70.0, 20.0)),
        options: List<String> = listOf("M"), chestMethod: String = "FLAT",
    ) = CatalogProduct("p1", "브랜드", "상품", "musinsa", "C1", options, unit, chestMethod, sizes, source, sourceDetail, verifiedAt)

    @Test fun `bundled demo catalog is valid and entirely demo`() {
        val text = File("src/main/assets/demo_products.json").readText()
        val catalog = DemoCatalog.parse(text)
        assertTrue("rejected: ${catalog.rejected}", catalog.rejected.isEmpty())
        assertTrue(catalog.products.size in 10..20)
        catalog.products.forEach { p ->
            // 임의로 만든 데이터는 절대 verified 가 아니어야 한다
            assertEquals(CatalogProduct.SOURCE_DEMO, p.source)
            assertTrue(p.isDemo)
            assertEquals(VerificationStatus.DEMO, p.toSizeChart().verification)
            assertEquals(SizeChartSource.LOCAL_CATALOG, p.toSizeChart().source)
            assertTrue(p.id.isNotBlank() && p.brand.isNotBlank() && p.name.isNotBlank() && p.shop.isNotBlank())
        }
        assertEquals(catalog.products.size, catalog.products.map { it.id }.toSet().size)
    }

    @Test fun `verified requires verifiedAt and sourceDetail`() {
        assertTrue(CatalogValidator.validate(product(source = "verified", verifiedAt = null)).isNotEmpty())
        assertTrue(CatalogValidator.validate(product(source = "verified", verifiedAt = "2026-10-01", sourceDetail = null)).isNotEmpty())
        assertTrue(CatalogValidator.validate(product(source = "verified", verifiedAt = "어제")).isNotEmpty())
        val ok = product(source = "verified", verifiedAt = "2026-10-01")
        assertTrue(CatalogValidator.validate(ok).isEmpty())
        assertEquals(VerificationStatus.VERIFIED, ok.toSizeChart().verification)
        assertFalse(ok.isDemo)
    }

    @Test fun `unknown source is rejected and never treated as verified`() {
        val p = product(source = "scraped")
        assertTrue(CatalogValidator.validate(p).isNotEmpty())
        assertEquals(VerificationStatus.DEMO, p.verification)
    }

    @Test fun `invalid values units and labels are rejected`() {
        assertTrue(CatalogValidator.validate(product(unit = "inch")).isNotEmpty())
        assertTrue(CatalogValidator.validate(product(sizes = listOf(CatalogSize("M", 0.0)))).isNotEmpty())
        assertTrue(CatalogValidator.validate(product(sizes = listOf(CatalogSize("M", -1.0)))).isNotEmpty())
        assertTrue(CatalogValidator.validate(product(sizes = listOf(CatalogSize("M")))).isNotEmpty())
        assertTrue(CatalogValidator.validate(product(sizes = emptyList())).isNotEmpty())
        assertTrue(CatalogValidator.validate(product(sizes = listOf(CatalogSize("M", 46.0), CatalogSize("M", 47.0)))).isNotEmpty())
        assertTrue(CatalogValidator.validate(product(options = listOf("S"))).isNotEmpty())
        assertTrue(CatalogValidator.validate(product(sizes = listOf(CatalogSize("M", 46.0, chestCircumference = 100.0)))).isNotEmpty())
    }

    @Test fun `parse drops invalid products`() {
        val json = """
            {"version":1,"products":[
              {"id":"ok","brand":"b","name":"n","shop":"s","options":["M"],"unit":"cm","sizeChart":[{"label":"M","shoulder":46}],"source":"demo"},
              {"id":"bad","brand":"b","name":"n","shop":"s","options":["M"],"unit":"cm","sizeChart":[{"label":"M","shoulder":0}],"source":"demo"}
            ]}
        """.trimIndent()
        val c = DemoCatalog.parse(json)
        assertEquals(listOf("ok"), c.products.map { it.id })
        assertTrue("bad" in c.rejected)
    }
}
