package com.brandme.fit.catalog

import android.content.Context
import android.util.Log
import kotlinx.serialization.json.Json

/** 로컬 카탈로그(우선순위 1). 검증을 통과한 상품만 노출한다. */
class DemoCatalog(val products: List<CatalogProduct>, val rejected: Map<String, List<String>>) {

    fun byId(id: String): CatalogProduct? = products.firstOrNull { it.id == id }

    companion object {
        const val ASSET_NAME = "demo_products.json"
        private val json = Json { ignoreUnknownKeys = true }

        fun parse(text: String): DemoCatalog {
            val file = json.decodeFromString(CatalogFile.serializer(), text)
            val accepted = mutableListOf<CatalogProduct>()
            val rejected = linkedMapOf<String, List<String>>()
            file.products.forEach { p ->
                val issues = CatalogValidator.validate(p)
                if (issues.isEmpty()) accepted += p else rejected[p.id] = issues
            }
            return DemoCatalog(accepted, rejected)
        }

        fun load(context: Context): DemoCatalog = runCatching {
            parse(context.assets.open(ASSET_NAME).bufferedReader(Charsets.UTF_8).use { it.readText() })
        }.onSuccess { c ->
            c.rejected.forEach { (id, issues) -> Log.w("DemoCatalog", "rejected $id: $issues") }
        }.getOrElse {
            Log.e("DemoCatalog", "catalog load failed", it)
            DemoCatalog(emptyList(), emptyMap())
        }
    }
}
