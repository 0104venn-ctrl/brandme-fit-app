package com.brandme.fit.data.model

/** SCR-03 기준 옷 입력 폼 검증. 단위는 cm 만 받는다. */
object ReferenceGarmentValidator {
    const val NAME_MAX = 40
    const val MEMO_MAX = 200

    data class Input(
        val name: String,
        val category: GarmentCategory?,
        val shoulder: String,
        val chestFlat: String,
        val length: String,
        val sleeve: String,
        val preferredFit: PreferredFit? = null,
        val memo: String = "",
    )

    enum class Field { NAME, CATEGORY, SHOULDER, CHEST_FLAT, LENGTH, SLEEVE, MEMO, CORE }

    data class Result(
        val errors: Map<Field, String>,
        val warnings: List<String>,
        val garment: ReferenceGarment?,
    ) {
        val isValid: Boolean get() = errors.isEmpty() && garment != null
    }

    const val FEW_ITEMS_WARNING = "비교 항목이 적어요. 어깨·가슴 단면·총장 중 2개 이상 입력하면 비교가 더 의미 있어요."

    fun validate(input: Input, existingId: Long = 0, now: Long = System.currentTimeMillis()): Result {
        val errors = linkedMapOf<Field, String>()

        val name = input.name.trim()
        if (name.isEmpty()) errors[Field.NAME] = "옷 이름을 입력하세요."
        else if (name.length > NAME_MAX) errors[Field.NAME] = "옷 이름은 ${NAME_MAX}자 이내로 입력하세요."

        if (input.category == null) errors[Field.CATEGORY] = "카테고리를 선택하세요."
        if (input.memo.length > MEMO_MAX) errors[Field.MEMO] = "메모는 ${MEMO_MAX}자 이내로 입력하세요."

        fun parse(field: Field, item: MeasureItem, raw: String): Double? {
            val text = raw.trim().removeSuffix("cm").removeSuffix("CM").trim()
            if (text.isEmpty()) return null
            val value = text.replace(',', '.').toDoubleOrNull()
            val range = MeasurementRules.range(item)
            when {
                value == null || value.isNaN() || value.isInfinite() ->
                    errors[field] = "숫자(cm)로 입력하세요."
                value <= 0.0 -> errors[field] = "0보다 큰 값을 입력하세요."
                value !in range ->
                    errors[field] = "${item.label} 값이 비정상이에요. ${range.start.toInt()}~${range.endInclusive.toInt()}cm 사이로 입력하세요."
                else -> return value
            }
            return null
        }

        val shoulder = parse(Field.SHOULDER, MeasureItem.SHOULDER, input.shoulder)
        val chest = parse(Field.CHEST_FLAT, MeasureItem.CHEST_FLAT, input.chestFlat)
        val length = parse(Field.LENGTH, MeasureItem.LENGTH, input.length)
        val sleeve = parse(Field.SLEEVE, MeasureItem.SLEEVE, input.sleeve)

        val coreFilled = listOf(input.shoulder, input.chestFlat, input.length).count { it.isNotBlank() }
        if (coreFilled == 0) errors[Field.CORE] = "어깨, 가슴 단면, 총장 중 최소 1개는 입력해야 해요."

        val coreValid = listOfNotNull(shoulder, chest, length).size
        val warnings = if (errors.isEmpty() && coreValid == 1) listOf(FEW_ITEMS_WARNING) else emptyList()

        val garment = if (errors.isEmpty()) {
            ReferenceGarment(
                id = existingId,
                name = name,
                category = input.category!!,
                measurements = Measurements(shoulder, chest, length, sleeve),
                preferredFit = input.preferredFit,
                memo = input.memo.trim().ifEmpty { null },
                updatedAt = now,
            )
        } else null

        return Result(errors, warnings, garment)
    }
}
