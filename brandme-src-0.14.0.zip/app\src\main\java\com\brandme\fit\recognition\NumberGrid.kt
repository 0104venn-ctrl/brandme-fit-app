package com.brandme.fit.recognition

import com.brandme.fit.recognition.SizeChartTextParser.Column
import com.brandme.fit.recognition.TableGrid.Token

/**
 * 숫자로 표를 먼저 만들고, 이름은 나중에 붙이는 사이즈표 인식.
 *
 * OCR 은 숫자는 잘 읽지만 헤더 글자는 자주 틀린다. 그래서 순서를 바꾼다.
 *  1. 화면에서 숫자만 모아, 높이가 같은 것끼리 행, 가로 위치가 같은 것끼리 열로 묶어 "숫자 블록"을 만든다.
 *  2. 각 행의 왼쪽 글자 = 행 이름, 블록 바로 위 줄에서 각 열 위에 있는 글자 = 열 이름.
 *  3. 사이즈 라벨(S, M, 1번, FREE…)이 행 이름 쪽에 있으면 가로형, 열 이름 쪽에 있으면 세로형.
 *     반대쪽 이름은 어깨/가슴/총장/소매 사전(오타 보정 포함)으로 항목에 연결한다.
 *  4. 같은 항목의 값이 사이즈 순서대로 한 방향(커지거나 작아지기)으로만 바뀌는지 검사한다.
 *
 * 숫자 칸에 이름이 없거나(헤더 누락), 한 칸에 숫자가 둘이거나, 값이 비거나, 순서가 어긋나면
 * 결과를 내지 않고 읽지 못함으로 돌려준다. 빈 값을 규칙으로 채우지 않는다.
 */
object NumberGrid {

    /** result: 표로 판단한 경우의 결과, debug: 결과 패널(디버그 빌드)에 보여 줄 재구성된 표 */
    data class Outcome(val result: SizeChartTextParser.Result, val debug: List<String>)

    private val MEASURES = setOf(Column.SHOULDER, Column.CHEST_FLAT, Column.CHEST_CIRC, Column.LENGTH, Column.SLEEVE)

    /** 표 방향을 정할 때 "항목명"으로 보는 것(하의 항목·바스트 포함) */
    private val NAMED_ITEMS = MEASURES + Column.BUST + Column.BOTTOM

    /** 숫자 표가 없거나 사이즈표로 볼 수 없으면 null (호출자가 다른 방식으로 시도) */
    fun read(lines: List<TextLine>): Outcome? {
        val groups = RowAssembler.groups(lines)
        val rowTokens = groups.map { g -> g.flatMap { TableGrid.tokens(it, SizeChartTextParser::cellTokens) } }
        val isNumberRow = rowTokens.map { toks -> toks.count { SizeChartTextParser.isValue(it.text) } >= 2 }

        // 숫자 행이 연속된 구간 = 표 본체 후보
        val runs = mutableListOf<IntRange>()
        var start = -1
        for (i in groups.indices) {
            if (isNumberRow[i] && start < 0) start = i
            if (!isNumberRow[i] && start >= 0) { runs += start until i; start = -1 }
        }
        if (start >= 0) runs += start until groups.size

        var failure: Outcome? = null
        for (run in runs.sortedByDescending { r -> r.sumOf { i -> rowTokens[i].count { SizeChartTextParser.isValue(it.text) } } }) {
            val o = readBlock(run, groups, rowTokens) ?: continue
            if (o.result is SizeChartTextParser.Result.Found) return o
            if (failure == null) failure = o
        }
        return failure
    }

    private fun median(xs: List<Float>): Float = xs.sorted().let { if (it.isEmpty()) 0f else it[it.size / 2] }

    private fun readBlock(run: IntRange, groups: List<List<TextLine>>, rowTokens: List<List<Token>>): Outcome? {
        val textHeight = median(run.flatMap { i -> groups[i].map { it.height.toFloat() } }).coerceAtLeast(1f)

        // 1) 숫자들의 가로 위치로 열을 만든다
        val xs = run.flatMap { i -> rowTokens[i].filter { SizeChartTextParser.isValue(it.text) }.map { it.center } }.sorted()
        val clusters = mutableListOf(mutableListOf(xs.first()))
        xs.drop(1).forEach { x -> if (x - clusters.last().last() > textHeight * 1.5f) clusters += mutableListOf(x) else clusters.last() += x }
        if (clusters.size < 2) return null
        var centers = clusters.map { c -> c.average().toFloat() }
        val spacing = median(centers.zipWithNext { a, b -> b - a })
        fun bounds(cs: List<Float>) = cs.indices.map { i ->
            val l = if (i == 0) cs[i] - spacing / 2 else (cs[i - 1] + cs[i]) / 2
            val r = if (i == cs.lastIndex) cs[i] + spacing / 2 else (cs[i] + cs[i + 1]) / 2
            l to r
        }
        var colBounds = bounds(centers)
        fun colOf(t: Token, b: List<Pair<Float, Float>>) = b.indexOfFirst { (l, r) -> t.center >= l && t.center < r }

        // 2) 숫자 블록 칸 채우기와 행 이름(블록 왼쪽 글자)
        var cells = run.map { i ->
            val slots = List(centers.size) { mutableListOf<String>() }
            rowTokens[i].forEach { t ->
                val c = colOf(t, colBounds)
                if (c >= 0 && (SizeChartTextParser.isValue(t.text) || SizeChartTextParser.isEmptyCell(t.text))) slots[c] += t.text
            }
            slots
        }
        // 행 이름: 블록 왼쪽 글자. 값이 없는 사이즈 칸의 "-"(예: M 열 전체가 "-")는 이름에 넣지 않는다.
        var rowNames = run.map { i ->
            rowTokens[i].filter { it.center < colBounds.first().first && !SizeChartTextParser.isEmptyCell(it.text) }
                .joinToString("") { it.text }
        }

        // 3) 열 이름: 블록 바로 위 1~2줄. 두 줄 머리글("L" 아래 "(105)")은 합친다.
        //    위 줄만 / 아래 줄만 / 두 줄 합침 중 사이즈 라벨·항목명으로 가장 많이 읽히는 것을 쓴다.
        val above = (1..3).mapNotNull { d -> (run.first - d).takeIf { it >= 0 } }
            .filter { i -> rowTokens[i].count { colOf(it, colBounds) >= 0 } >= maxOf(1, centers.size / 2) }
            .take(2)
        fun namesOf(lines: List<Int>) = centers.indices.map { c ->
            lines.sorted().joinToString("") { h -> rowTokens[h].filter { colOf(it, colBounds) == c }.joinToString("") { it.text } }
        }
        fun score(names: List<String>) = names.count {
            SizeChartTextParser.normalizeLabel(it) != null || SizeChartTextParser.classifyHeader(it) in NAMED_ITEMS
        }
        val headerOptions = buildList {
            if (above.size == 2) add(above)
            above.forEach { add(listOf(it)) }
        }
        val header = headerOptions.maxByOrNull { score(namesOf(it)) }.orEmpty()
        var colNames = if (header.isEmpty()) centers.map { "" } else namesOf(header)
        val corner = header.sorted().joinToString("") { h ->
            rowTokens[h].filter { it.center < colBounds.first().first }.joinToString("") { it.text }
        }

        // 숫자 사이즈(90, 95…)가 블록 안에 들어온 경우: "사이즈" 이름이 붙은 첫 열/첫 행을 라벨로 떼어 낸다
        if (colNames.isNotEmpty() && SizeChartTextParser.classifyHeader(colNames.first()) == Column.SIZE) {
            rowNames = cells.map { it.first().joinToString("") }
            cells = cells.map { it.drop(1) }
            colNames = colNames.drop(1)
            centers = centers.drop(1)
            colBounds = colBounds.drop(1)
        } else if (rowNames.isNotEmpty() && SizeChartTextParser.classifyHeader(rowNames.first()) == Column.SIZE) {
            colNames = cells.first().map { it.joinToString("") }
            cells = cells.drop(1)
            rowNames = rowNames.drop(1)
        }
        if (cells.isEmpty() || colNames.isEmpty()) return null

        val rowLabels = rowNames.count { SizeChartTextParser.normalizeLabel(it) != null }
        val colLabels = colNames.count { SizeChartTextParser.normalizeLabel(it) != null }
        val rowMeasures = rowNames.count { SizeChartTextParser.classifyHeader(it) in NAMED_ITEMS }
        val colMeasures = colNames.count { SizeChartTextParser.classifyHeader(it) in NAMED_ITEMS }
        val horizontal = colMeasures >= 1 && rowLabels * 2 >= rowNames.size && rowLabels >= colLabels
        val vertical = !horizontal && rowMeasures >= 1 && colLabels * 2 >= colNames.size
        if (!horizontal && !vertical) return null // 사이즈표가 아닌 숫자 묶음

        // 세로형이면 전치해서 (사이즈 행 × 항목 열) 로 맞춘다
        val sizeNames = if (horizontal) rowNames else colNames
        val measureNames = if (horizontal) colNames else rowNames

        val shape = "${if (horizontal) "가로형" else "세로형"} ${cells.size}행×${colNames.size}열"
        val mapping = "항목 판단: " + measureNames.joinToString(", ") { n ->
            "$n→" + when (val c = SizeChartTextParser.classifyHeader(n)) {
                null -> "모름"
                Column.IGNORE -> "제외"
                Column.SIZE -> "사이즈"
                else -> c.label
            }
        }
        val debug = listOf("[숫자 표: $shape]", (listOf(corner) + colNames).joinToString("\t")) +
            cells.mapIndexed { r, row -> (listOf(rowNames[r]) + row.map { it.joinToString("+").ifEmpty { "?" } }).joinToString("\t") } +
            mapping
        fun fail(reason: String) = Outcome(SizeChartTextParser.Result.Unreadable(reason), debug)
        fun cell(s: Int, m: Int): List<String> = if (horizontal) cells[s][m] else cells[m][s]

        if ((sizeNames + measureNames + corner).any { SizeChartTextParser.isInch(it) }) return fail("cm 단위가 아닌 표(인치)")
        val labels = sizeNames.map { n -> SizeChartTextParser.normalizeLabel(n) ?: return fail("사이즈 이름을 읽지 못함 '${n.ifEmpty { "빈칸" }}'") }
        val skipped = mutableListOf<String>()
        val columns = measureNames.mapIndexed { m, n ->
            if (n.isEmpty()) return fail("항목명이 없는 숫자 칸이 있음(헤더를 읽지 못함)")
            when (val c = SizeChartTextParser.classifyHeader(n)) {
                // 사전에 없는 이름: 그 줄만 비교에서 빼고 결과에 알린다. 값은 위치로 배정했으므로 다른 항목으로 밀리지 않는다.
                null -> Column.IGNORE.also { skipped += n }
                Column.SIZE -> return fail("표 구조를 알 수 없음")
                // 바스트: 값이 모두 80 이상이면 둘레로 본다. 아니면 단면인지 둘레인지 알 수 없어 뺀다.
                Column.BUST -> {
                    val vs = labels.indices.flatMap { s -> cell(s, m) }.mapNotNull { it.removeSuffix("cm").replace(',', '.').toDoubleOrNull() }
                    if (vs.isNotEmpty() && vs.all { it >= 80.0 }) Column.CHEST_CIRC
                    else Column.IGNORE.also { skipped += "$n(둘레/단면 구분 불가)" }
                }
                else -> c
            }
        }
        SizeChartTextParser.bottomTable(columns)?.let { return Outcome(it, debug) }

        columns.filter { it in MEASURES }.groupBy { it }.values.firstOrNull { it.size > 1 }?.let {
            return fail("같은 항목(${it.first().label})으로 판단한 줄이 두 개 있음")
        }

        val sizes = labels.mapIndexed { s, label ->
            val values = linkedMapOf<Column, Double?>()
            columns.forEachIndexed { m, col ->
                if (col !in MEASURES) return@forEachIndexed
                val texts = cell(s, m)
                values[col] = when {
                    texts.isEmpty() -> return fail("$label 의 ${measureNames[m]} 값이 비어 있음")
                    texts.size > 1 -> return fail("$label 의 ${measureNames[m]} 칸에 값이 여러 개")
                    SizeChartTextParser.isEmptyCell(texts.single()) -> null
                    else -> texts.single().removeSuffix("cm").replace(',', '.').toDouble()
                }
            }
            label to values
        }

        // 4) 같은 항목은 사이즈 순서대로 한 방향으로만 변해야 한다(OCR 오독·칸 밀림 감지)
        columns.distinct().filter { it in MEASURES }.forEach { col ->
            val seq = sizes.mapNotNull { it.second[col] }
            val up = seq.zipWithNext().all { (a, b) -> b >= a }
            val down = seq.zipWithNext().all { (a, b) -> b <= a }
            if (!up && !down) return fail("${measureNames[columns.indexOf(col)]} 값이 사이즈 순서와 맞지 않음")
        }

        return Outcome(SizeChartTextParser.chartFromTable(sizes, columns, skipped), debug)
    }
}
