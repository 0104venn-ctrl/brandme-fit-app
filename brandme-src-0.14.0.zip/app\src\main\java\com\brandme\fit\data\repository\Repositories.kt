package com.brandme.fit.data.repository

import com.brandme.fit.data.local.ComparisonHistoryDao
import com.brandme.fit.data.local.ComparisonHistoryEntity
import com.brandme.fit.data.local.ReferenceGarmentDao
import com.brandme.fit.data.local.ReferenceGarmentEntity
import com.brandme.fit.data.local.SettingsDataStore
import com.brandme.fit.data.model.GarmentCategory
import com.brandme.fit.data.model.Measurements
import com.brandme.fit.data.model.PreferredFit
import com.brandme.fit.data.model.ReferenceGarment
import com.brandme.fit.data.model.VerificationStatus
import com.brandme.fit.recognition.AnalysisOutcome
import com.brandme.fit.ui.result.ResultFormatter
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class GarmentRepository(private val dao: ReferenceGarmentDao) {
    val active: Flow<ReferenceGarment?> = dao.observeActive().map { it?.toModel() }

    suspend fun getActive(): ReferenceGarment? = dao.getActive()?.toModel()

    suspend fun save(g: ReferenceGarment): Long = dao.upsert(
        ReferenceGarmentEntity(
            id = g.id,
            name = g.name,
            category = g.category.name,
            shoulderCm = g.measurements.shoulderCm,
            chestFlatCm = g.measurements.chestFlatCm,
            lengthCm = g.measurements.lengthCm,
            sleeveCm = g.measurements.sleeveCm,
            preferredFit = g.preferredFit?.name,
            memo = g.memo,
            updatedAt = g.updatedAt,
        ),
    )

    suspend fun deleteAll() = dao.deleteAll()

    private fun ReferenceGarmentEntity.toModel() = ReferenceGarment(
        id = id,
        name = name,
        category = runCatching { GarmentCategory.valueOf(category) }.getOrDefault(GarmentCategory.SHORT_SLEEVE_TEE),
        measurements = Measurements(shoulderCm, chestFlatCm, lengthCm, sleeveCm),
        preferredFit = preferredFit?.let { runCatching { PreferredFit.valueOf(it) }.getOrNull() },
        memo = memo,
        updatedAt = updatedAt,
    )
}

data class HistoryItem(
    val id: Long,
    val createdAt: Long,
    val productName: String,
    val closestSizes: String,
    val summary: String,
    val isDemo: Boolean,
    val verification: String?,
    val error: String?,
)

class HistoryRepository(private val dao: ComparisonHistoryDao) {
    val recent: Flow<List<HistoryItem>> = dao.observeRecent(20).map { list ->
        list.map { HistoryItem(it.id, it.createdAt, it.productName, it.closestSizes, it.summary, it.isDemo, it.verification, it.error) }
    }

    /** 결과 요약만 저장한다(이미지·화면 텍스트 저장 안 함). */
    suspend fun record(outcome: AnalysisOutcome, referenceName: String) {
        val entity = when (outcome) {
            is AnalysisOutcome.Success -> ComparisonHistoryEntity(
                createdAt = outcome.result?.createdAt ?: System.currentTimeMillis(),
                algorithmVersion = listOfNotNull(outcome.result?.algorithmVersion, outcome.bodyFit?.algorithmVersion).joinToString("+"),
                referenceName = referenceName,
                productName = outcome.product.displayName,
                identificationStatus = outcome.product.status.name,
                source = outcome.chart.source.name,
                verification = outcome.chart.verification.name,
                closestSizes = (outcome.bodyFit?.recommended ?: outcome.result?.closestSizes.orEmpty()).joinToString(", "),
                summary = ResultFormatter.summary(outcome),
                isDemo = outcome.chart.verification == VerificationStatus.DEMO,
                error = null,
            )
            is AnalysisOutcome.Failure -> ComparisonHistoryEntity(
                createdAt = System.currentTimeMillis(),
                algorithmVersion = com.brandme.fit.comparison.FitComparisonEngine.ALGORITHM_VERSION,
                referenceName = referenceName,
                productName = outcome.product?.displayName ?: "상품명 미확인",
                identificationStatus = outcome.product?.status?.name ?: "NOT_FOUND",
                source = null,
                verification = null,
                closestSizes = "",
                summary = outcome.error.title,
                isDemo = outcome.product?.isDemo ?: false,
                error = outcome.error.name,
            )
            is AnalysisOutcome.NeedsCandidateChoice -> return
        }
        dao.insert(entity)
    }

    suspend fun deleteAll() = dao.deleteAll()
}

typealias SettingsRepository = SettingsDataStore
