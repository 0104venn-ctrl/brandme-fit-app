package com.brandme.fit.catalog

import com.brandme.fit.data.model.MeasurementRules

/** 카탈로그 상품 데이터 검증. 문제가 있는 상품은 로드하지 않는다. */
object CatalogValidator {
    private val ALLOWED_SOURCES = setOf(CatalogProduct.SOURCE_VERIFIED, CatalogProduct.SOURCE_DEMO)
    private val ALLOWED_CHEST = setOf("FLAT", "CIRCUMFERENCE", "UNKNOWN")
    private val ISO_DATE = Regex("""\d{4}-\d{2}-\d{2}""")

    fun validate(p: CatalogProduct): List<String> = buildList {
        if (p.id.isBlank()) add("id 없음")
        if (p.brand.isBlank()) add("brand 없음")
        if (p.name.isBlank()) add("name 없음")
        if (p.shop.isBlank()) add("shop 없음")
        if (p.unit != "cm") add("unit 은 cm 이어야 함 (현재: ${p.unit})")
        if (p.chestMethod !in ALLOWED_CHEST) add("chestMethod 값 오류: ${p.chestMethod}")
        if (p.source !in ALLOWED_SOURCES) add("source 는 verified 또는 demo (현재: ${p.source})")
        if (p.source == CatalogProduct.SOURCE_VERIFIED) {
            if (p.verifiedAt.isNullOrBlank() || !ISO_DATE.matches(p.verifiedAt)) add("verified 상품은 verifiedAt(YYYY-MM-DD) 필수")
            if (p.sourceDetail.isNullOrBlank()) add("verified 상품은 sourceDetail(확인 출처) 필수")
        }
        if (p.sizeChart.isEmpty()) add("sizeChart 비어 있음")

        val labels = p.sizeChart.map { it.label.trim().uppercase() }
        if (labels.any { it.isEmpty() }) add("빈 사이즈 라벨")
        if (labels.toSet().size != labels.size) add("중복 사이즈 라벨")
        val options = p.options.map { it.trim().uppercase() }.toSet()
        labels.filter { it !in options }.forEach { add("options 에 없는 사이즈: $it") }

        p.sizeChart.forEach { s ->
            val m = s.toProductSize().measurements
            if (m.presentItems().isEmpty()) add("${s.label}: 실측값 없음")
            MeasurementRules.invalidItems(m).forEach { add("${s.label}: ${it.label} 비정상 값 ${m[it]}") }
            if (p.chestMethod == "FLAT" && s.chestCircumference != null) add("${s.label}: FLAT 상품에 가슴 둘레 값")
            if (p.chestMethod == "CIRCUMFERENCE" && s.chestFlat != null) add("${s.label}: CIRCUMFERENCE 상품에 가슴 단면 값")
        }
    }
}
