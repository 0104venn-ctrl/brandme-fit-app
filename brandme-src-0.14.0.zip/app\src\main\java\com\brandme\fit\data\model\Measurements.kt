package com.brandme.fit.data.model

/** 비교 항목. 가슴 둘레(CHEST_CIRCUMFERENCE)는 가슴 단면과 별개 항목이며 서로 환산하지 않는다. */
enum class MeasureItem(val label: String, val widthLike: Boolean) {
    SHOULDER("어깨", true),
    CHEST_FLAT("가슴 단면", true),
    LENGTH("총장", false),
    SLEEVE("소매", false),
    CHEST_CIRCUMFERENCE("가슴 둘레", true);

    companion object {
        /** 기준 옷 프로필에서 "최소 1개 필수"인 핵심 항목 */
        val CORE = listOf(SHOULDER, CHEST_FLAT, LENGTH)
    }
}

/** 실측값(cm). null = 값 없음(누락). 0이나 음수는 허용하지 않는다(검증에서 거부). */
data class Measurements(
    val shoulderCm: Double? = null,
    val chestFlatCm: Double? = null,
    val lengthCm: Double? = null,
    val sleeveCm: Double? = null,
    val chestCircumferenceCm: Double? = null,
) {
    operator fun get(item: MeasureItem): Double? = when (item) {
        MeasureItem.SHOULDER -> shoulderCm
        MeasureItem.CHEST_FLAT -> chestFlatCm
        MeasureItem.LENGTH -> lengthCm
        MeasureItem.SLEEVE -> sleeveCm
        MeasureItem.CHEST_CIRCUMFERENCE -> chestCircumferenceCm
    }

    fun with(item: MeasureItem, value: Double?): Measurements = when (item) {
        MeasureItem.SHOULDER -> copy(shoulderCm = value)
        MeasureItem.CHEST_FLAT -> copy(chestFlatCm = value)
        MeasureItem.LENGTH -> copy(lengthCm = value)
        MeasureItem.SLEEVE -> copy(sleeveCm = value)
        MeasureItem.CHEST_CIRCUMFERENCE -> copy(chestCircumferenceCm = value)
    }

    fun presentItems(): Set<MeasureItem> = MeasureItem.entries.filter { get(it) != null }.toSet()
}

/** 상의 실측 허용 범위(cm). 범위를 벗어나면 비정상 값으로 보고 거부한다. */
object MeasurementRules {
    private val ranges = mapOf(
        MeasureItem.SHOULDER to 20.0..90.0,
        MeasureItem.CHEST_FLAT to 25.0..100.0,
        MeasureItem.LENGTH to 30.0..130.0,
        MeasureItem.SLEEVE to 5.0..110.0,
        MeasureItem.CHEST_CIRCUMFERENCE to 50.0..200.0,
    )

    fun range(item: MeasureItem): ClosedFloatingPointRange<Double> = ranges.getValue(item)

    fun isValid(item: MeasureItem, value: Double): Boolean =
        !value.isNaN() && !value.isInfinite() && value > 0.0 && value in range(item)

    /** 값이 있는 항목 중 비정상 값 목록 */
    fun invalidItems(m: Measurements): List<MeasureItem> =
        MeasureItem.entries.filter { item -> m[item]?.let { !isValid(item, it) } ?: false }
}
