package com.brandme.fit.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "reference_garment")
data class ReferenceGarmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val shoulderCm: Double?,
    val chestFlatCm: Double?,
    val lengthCm: Double?,
    val sleeveCm: Double?,
    val preferredFit: String?,
    val memo: String?,
    val updatedAt: Long,
)

/** 비교 기록. 캡처 이미지나 화면 텍스트는 저장하지 않고 결과 요약만 남긴다. */
@Entity(tableName = "comparison_history")
data class ComparisonHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long,
    val algorithmVersion: String,
    val referenceName: String,
    val productName: String,
    val identificationStatus: String,
    val source: String?,
    val verification: String?,
    val closestSizes: String,
    val summary: String,
    val isDemo: Boolean,
    val error: String?,
)

@Dao
interface ReferenceGarmentDao {
    @Query("SELECT * FROM reference_garment ORDER BY updatedAt DESC LIMIT 1")
    fun observeActive(): Flow<ReferenceGarmentEntity?>

    @Query("SELECT * FROM reference_garment ORDER BY updatedAt DESC LIMIT 1")
    suspend fun getActive(): ReferenceGarmentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ReferenceGarmentEntity): Long

    @Query("DELETE FROM reference_garment")
    suspend fun deleteAll()
}

@Dao
interface ComparisonHistoryDao {
    @Query("SELECT * FROM comparison_history ORDER BY createdAt DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<ComparisonHistoryEntity>>

    @Insert
    suspend fun insert(entity: ComparisonHistoryEntity): Long

    @Query("DELETE FROM comparison_history")
    suspend fun deleteAll()
}

@Database(
    entities = [ReferenceGarmentEntity::class, ComparisonHistoryEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun garmentDao(): ReferenceGarmentDao
    abstract fun historyDao(): ComparisonHistoryDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "brandme_fit.db").build()
    }
}
