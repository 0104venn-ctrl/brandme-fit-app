package com.brandme.fit.data.model

enum class GarmentCategory(val label: String) {
    SHORT_SLEEVE_TEE("반팔 티셔츠"),
    LONG_SLEEVE_TEE("긴팔 티셔츠"),
    SHIRT("셔츠"),
    KNIT("니트"),
    SWEATSHIRT("맨투맨/후디"),
    OUTER("아우터(상의)"),
}

enum class PreferredFit(val label: String) {
    SLIM("슬림"),
    REGULAR("정핏"),
    RELAXED("세미오버"),
    OVERSIZED("오버핏"),
}

/** 사용자가 저장한 기준 옷(상의만). 가슴은 단면만 입력받는다 — 둘레는 받지 않는다. */
data class ReferenceGarment(
    val id: Long = 0,
    val name: String,
    val category: GarmentCategory,
    val measurements: Measurements,
    val preferredFit: PreferredFit? = null,
    val memo: String? = null,
    val updatedAt: Long = System.currentTimeMillis(),
) {
    val coreItemCount: Int get() = MeasureItem.CORE.count { measurements[it] != null }
    val isComparable: Boolean
        get() = coreItemCount >= 1 && MeasurementRules.invalidItems(measurements).isEmpty()
}
