package com.brandme.fit.photo

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.ByteBufferExtractor
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import java.nio.ByteOrder

/**
 * 기기 안에서 MediaPipe 전신 자세 인식(heavy 모델)으로 관절 위치와 몸 윤곽 마스크를 한 번에 얻는다.
 * 관절과 윤곽이 같은 모델에서 나와 서로 어긋나지 않는다. 사진은 메모리에서만 쓰고 저장하지 않는다.
 */
object BodyAnalyzer {

    private const val MODEL = "mediapipe/pose_landmarker_heavy.task"

    // MediaPipe 관절 번호
    private const val L_SHOULDER = 11
    private const val R_SHOULDER = 12
    private const val L_WRIST = 15
    private const val R_WRIST = 16
    private const val L_HIP = 23
    private const val R_HIP = 24
    private const val NOSE = 0
    private const val L_HEEL = 29
    private const val R_HEEL = 30
    private const val L_ELBOW = 13
    private const val R_ELBOW = 14

    fun analyze(context: Context, bitmap: Bitmap): PhotoObservation {
        val options = PoseLandmarker.PoseLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath(MODEL).build())
            .setRunningMode(RunningMode.IMAGE)
            .setNumPoses(1)
            .setOutputSegmentationMasks(true)
            .build()
        PoseLandmarker.createFromOptions(context, options).use { landmarker ->
            val result = landmarker.detect(BitmapImageBuilder(bitmap).build())
            val maskImage = result.segmentationMasks().orElse(null)?.firstOrNull()
            val mask = if (maskImage != null) {
                val buf = ByteBufferExtractor.extract(maskImage).order(ByteOrder.nativeOrder())
                buf.rewind()
                val prob = FloatArray(maskImage.width * maskImage.height)
                buf.asFloatBuffer().get(prob)
                BodyMask.fromProbabilities(maskImage.width, maskImage.height, prob)
            } else {
                BodyMask(bitmap.width, bitmap.height, BooleanArray(bitmap.width * bitmap.height))
            }
            val lms = result.landmarks().firstOrNull()
            fun lm(i: Int): Pt? {
                val l = lms?.getOrNull(i) ?: return null
                val vis = l.visibility().orElse(1f)
                if (vis < 0.5f || l.x() !in 0f..1f || l.y() !in 0f..1f) return null
                return Pt(l.x().toDouble() * mask.width, l.y().toDouble() * mask.height)
            }
            return PhotoObservation(
                mask = mask,
                leftShoulder = lm(L_SHOULDER), rightShoulder = lm(R_SHOULDER),
                leftHip = lm(L_HIP), rightHip = lm(R_HIP),
                leftWrist = lm(L_WRIST), rightWrist = lm(R_WRIST),
                nose = lm(NOSE), leftHeel = lm(L_HEEL), rightHeel = lm(R_HEEL),
                leftElbow = lm(L_ELBOW), rightElbow = lm(R_ELBOW),
            )
        }
    }
}
