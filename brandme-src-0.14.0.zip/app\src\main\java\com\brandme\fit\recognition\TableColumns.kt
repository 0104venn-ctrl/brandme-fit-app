package com.brandme.fit.recognition

import kotlin.math.abs

/**
 * 표 전체를 한 번에 OCR 하면 띄엄띄엄 놓인 짧은 숫자 칸을 통째로 빠뜨리는 경우가 있다.
 * 그래서 헤더 칸 위치로 세로 띠(칸)를 나눠 칸마다 따로 읽고, 세로 위치로 다시 행을 맞춘다.
 * 어느 칸이든 값이 비면 그 행은 칸 수가 모자란 채로 남겨 파서가 "읽지 못함"으로 처리하게 한다(추측하지 않음).
 */
object TableColumns {

    private val VALUE = Regex("""^\d{1,3}([.,]\d{1,2})?(cm)?$""")

    /** 칸 하나: 헤더 이름과 원본 좌표의 가로 범위 */
    data class Column(val name: String, val left: Int, val right: Int)

    /**
     * 헤더 줄들로 칸 경계를 만든다. 한 줄에 헤더가 여러 개 붙어 인식됐으면 글자 수 비율로 나눈다.
     * 맨 앞 칸이 "사이즈" 헤더가 아니면 그 왼쪽에 라벨 칸을 하나 더 둔다.
     */
    fun columns(header: List<TextLine>, regionLeft: Int, regionRight: Int): List<Column> {
        val cells = mutableListOf<Triple<String, Int, Int>>() // name, left, right
        header.sortedBy { it.left }.forEach { line ->
            val names = SizeChartTextParser.splitHeader(line.text)
            if (names.isEmpty()) return@forEach
            val total = names.sumOf { it.length }.coerceAtLeast(1)
            var x = line.left.toFloat()
            names.forEach { n ->
                val w = (line.right - line.left) * n.length.toFloat() / total
                cells += Triple(n, x.toInt(), (x + w).toInt())
                x += w
            }
        }
        if (cells.isEmpty()) return emptyList()
        if (SizeChartTextParser.classifyHeader(cells.first().first) != SizeChartTextParser.Column.SIZE) {
            val first = cells.first()
            cells.add(0, Triple("사이즈", regionLeft, first.second))
        }
        val centers = cells.map { (it.second + it.third) / 2 }
        return cells.mapIndexed { i, (name, _, _) ->
            val l = if (i == 0) regionLeft else (centers[i - 1] + centers[i]) / 2
            val r = if (i == cells.lastIndex) regionRight else (centers[i] + centers[i + 1]) / 2
            Column(name, l, r)
        }
    }

    /**
     * 칸별 OCR 결과(원본 세로 좌표)를 행으로 맞춘다. 행 기준은 첫 칸(사이즈 라벨)이다.
     * 반환값의 첫 줄은 헤더, 이후는 "라벨\t값\t값…" 행.
     */
    data class Assembled(
        val rows: List<String>,
        /** 어느 라벨 행에도 붙지 않은 값 칸 수. 0 보다 크면 라벨을 못 읽은 행이 있다는 뜻 */
        val orphanCells: Int,
    )

    fun assemble(columns: List<Column>, cellsByColumn: List<List<TextLine>>): Assembled {
        require(columns.size == cellsByColumn.size)
        val header = columns.joinToString("\t") { it.name }
        // 표 선을 "-", "|" 같은 글자로 읽은 조각은 버린다(빈 칸으로 취급하지 않음).
        val cleaned = cellsByColumn.map { cells -> cells.filter { c -> c.text.any { it.isLetterOrDigit() } } }
        val labels = cleaned.first().sortedBy { it.centerY }
        val used = mutableSetOf<TextLine>()
        val rows = labels.map { label ->
            val tolerance = label.height.coerceAtLeast(1) * 0.7f
            val values = cleaned.drop(1).mapNotNull { cells ->
                cells.filter { abs(it.centerY - label.centerY) <= tolerance }
                    .minByOrNull { abs(it.centerY - label.centerY) }
                    ?.also { used += it }
                    ?.text?.trim()
            }
            (listOf(label.text.trim()) + values).joinToString("\t")
        }
        val orphans = cleaned.drop(1).sumOf { cells -> cells.count { it !in used && VALUE.matches(it.text.trim()) } }
        return Assembled(listOf(header) + rows, orphans)
    }
}
