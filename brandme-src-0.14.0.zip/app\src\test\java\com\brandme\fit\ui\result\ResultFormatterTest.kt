package com.brandme.fit.ui.result

import com.brandme.fit.comparison.FitComparisonEngine
import com.brandme.fit.data.model.GarmentCategory
import com.brandme.fit.data.model.MeasureItem
import com.brandme.fit.data.model.Measurements
import com.brandme.fit.data.model.ProductSize
import com.brandme.fit.data.model.ReferenceGarment
import com.brandme.fit.data.model.SizeChart
import com.brandme.fit.data.model.SizeChartSource
import com.brandme.fit.data.model.SizeComparison
import com.brandme.fit.data.model.VerificationStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class ResultFormatterTest {
    @Test fun `closest sentence uses required phrasing`() {
        val ref = ReferenceGarment(name = "t", category = GarmentCategory.SHIRT, measurements = Measurements(46.0, 52.0, 70.0))
        val chart = SizeChart(listOf(ProductSize("M", Measurements(48.0, 55.0, 70.0))), source = SizeChartSource.LOCAL_CATALOG,
            verification = VerificationStatus.DEMO)
        val r = FitComparisonEngine.compare(ref, chart)
        assertEquals("기준 옷과 실측이 가장 가까운 사이즈는 M입니다.", ResultFormatter.closestSentence(r))
        assertEquals("어깨는 2cm 넓고 가슴 단면은 3cm 넓고 총장은 같습니다.", ResultFormatter.diffSentence(r.rankedSizes.single()))
    }

    @Test fun `narrower and shorter wording`() {
        val s = SizeComparison("S", mapOf(MeasureItem.SHOULDER to -1.5, MeasureItem.LENGTH to -2.0, MeasureItem.SLEEVE to 1.0),
            setOf(MeasureItem.SHOULDER, MeasureItem.LENGTH, MeasureItem.SLEEVE), 1.5)
        assertEquals("어깨는 1.5cm 좁고 총장은 2cm 짧고 소매는 1cm 깁니다.", ResultFormatter.diffSentence(s))
    }

    @Test fun `no forbidden guarantee phrases`() {
        val texts = listOf(ResultFormatter.DISCLAIMER) +
            com.brandme.fit.recognition.AnalysisError.entries.flatMap { listOf(it.title, it.message) } +
            com.brandme.fit.data.model.ComparisonWarning.entries.map { it.message }
        texts.forEach { t -> ResultFormatter.FORBIDDEN_PHRASES.forEach { f -> assertFalse("'$t' contains '$f'", t.contains(f)) } }
        assertEquals("실측 비교 결과이며 실제 착용감이나 사이즈 적합도를 보장하지 않습니다.", ResultFormatter.DISCLAIMER)
    }
}
