package com.brandme.fit.recognition

import android.graphics.Bitmap
import com.brandme.fit.catalog.CatalogSize
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import kotlin.math.max

/** backend/app/schemas.py 와 같은 구조 */
@Serializable
data class AnalyzeScreenResponse(
    val status: String,
    val product: RemoteProduct? = null,
    val candidates: List<RemoteProduct> = emptyList(),
    val sizeChartCandidates: List<RemoteSizeChart> = emptyList(),
    val failureReason: String? = null,
    val model: String? = null,
)

@Serializable
data class RemoteProduct(
    val brand: String? = null,
    val name: String? = null,
    val shop: String? = null,
    val productCode: String? = null,
    val score: Double? = null,
)

@Serializable
data class RemoteSizeChart(
    val unit: String = "cm",
    val chestMethod: String = "UNKNOWN",
    val sizes: List<CatalogSize>,
    val evidence: String? = null,
)

interface BrandmeApi {
    @Multipart
    @POST("api/analyze-screen")
    suspend fun analyzeScreen(
        @Part image: MultipartBody.Part,
        @Part("consent") consent: RequestBody,
    ): AnalyzeScreenResponse
}

/** AI Mode 전용. 이미지는 메모리에서만 JPEG로 인코딩해 보내고 파일로 저장하지 않는다. */
class RemoteAnalyzer(baseUrl: String) {
    private val api: BrandmeApi = Retrofit.Builder()
        .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
        .client(
            OkHttpClient.Builder()
                .connectTimeout(8, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .build(),
        )
        .addConverterFactory(JSON.asConverterFactory("application/json".toMediaType()))
        .build()
        .create(BrandmeApi::class.java)

    suspend fun analyze(bitmap: Bitmap): AnalyzeScreenResponse {
        val jpeg = encode(bitmap)
        val part = MultipartBody.Part.createFormData(
            "image", "screen.jpg", jpeg.toRequestBody("image/jpeg".toMediaType()),
        )
        return api.analyzeScreen(part, "true".toRequestBody("text/plain".toMediaType()))
    }

    private fun encode(src: Bitmap): ByteArray {
        val longSide = max(src.width, src.height)
        val scaled = if (longSide > MAX_SIDE) {
            val r = MAX_SIDE.toFloat() / longSide
            Bitmap.createScaledBitmap(src, (src.width * r).toInt(), (src.height * r).toInt(), true)
        } else src
        return ByteArrayOutputStream().use { out ->
            scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
            if (scaled !== src) scaled.recycle()
            out.toByteArray()
        }
    }

    companion object {
        private const val MAX_SIDE = 1440
        private val JSON = Json { ignoreUnknownKeys = true }
    }
}
