# 권한과 개인정보

| 권한 | 왜 필요한가 | 언제 요청하나 |
|---|---|---|
| `SYSTEM_ALERT_WINDOW` (다른 앱 위에 표시) | 쇼핑 앱 위에 버튼·결과 표시 | 홈에서 "플로팅 버튼"을 켤 때. 목적 설명 대화상자 → `ACTION_MANAGE_OVERLAY_PERMISSION` |
| `POST_NOTIFICATIONS` | 서비스 상태 알림과 알림의 "중지" 버튼 | 버튼을 처음 켤 때 설명 후 요청. 거부해도 버튼은 동작 |
| `FOREGROUND_SERVICE` + `_SPECIAL_USE` | 버튼 서비스를 포그라운드로 유지 | 런타임 요청 없음 (매니페스트) |
| `FOREGROUND_SERVICE_MEDIA_PROJECTION` | 캡처 세션 동안 FGS 유지 | 런타임 요청 없음 |
| MediaProjection 동의 (시스템 창) | 현재 화면 1장 읽기 | 버튼을 눌렀는데 활성 세션이 없을 때만. 오버레이 안내 카드 → 시스템 동의 창 |
| `INTERNET` | AI Mode 서버 호출 | Demo Mode 에서는 네트워크를 쓰지 않음 |
| `CAMERA` | 내 몸 치수 "사진으로 재기"의 정면·옆면 촬영 | 사진으로 재기를 처음 누를 때. 사진은 분석 후 바로 메모리에서 지우고 저장·전송하지 않음 |

쓰지 않는 것: AccessibilityService, 루트, `RECEIVE_BOOT_COMPLETED`(부팅 자동 시작 없음), 저장소 권한.

## 캡처 규칙 (Android 14+)

- 캡처 세션마다 새 동의. 동의 결과 Intent 는 서비스에 한 번 넘기고 저장·재사용하지 않는다.
- `startForeground(..., FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)` 후 `getMediaProjection`.
- `registerCallback` 을 `createVirtualDisplay` 보다 먼저 호출. VirtualDisplay 는 세션당 1개.
- `onStop`(상태 표시줄 칩에서 중지, 화면 잠금 등) → VirtualDisplay/ImageReader/Projection 해제, 서비스 종료.
- `onCapturedContentResize` / `onConfigurationChanged` → `VirtualDisplay.resize` + ImageReader 교체.
- `onCapturedContentVisibilityChanged(false)`(단일 앱 공유 중 그 앱이 가려짐) → 캡처 거부.
- 세션은 사용자가 끝낼 때까지(홈 "캡처 세션 종료", 알림 "캡처 중지", 시스템 칩) 유지되며, 그동안 버튼을 누를 때만 프레임을 복사한다.
- 캡처 직전 버튼과 패널을 숨기고, 숨긴 시각 이후 프레임을 우선 사용한다.

## 개인정보

- 원본 이미지는 파일로 저장하지 않는다. 메모리 Bitmap 은 분석 후 `recycle()`(취소 시에는 참조 해제).
- 비교 기록에는 상품명, 가까운 사이즈, 요약 문장, 출처/검증 상태만 저장. 화면 텍스트·이미지는 저장 안 함.
- 외부 AI 전송은 별도 명시 동의(기본 꺼짐). 동의 철회 시 Demo Mode 로 돌아간다.
- 결제·계정·메시지 화면 신호(카드번호, 비밀번호, 계좌번호, 인증번호, 결제수단+최종결제금액 등)가 OCR 에서 보이면 **외부 전송 전에** 분석 중단.
- FLAG_SECURE 화면은 캡처가 검게 나오며, 이를 "보호된 화면"으로 안내하고 우회하지 않는다.
- 오버레이 권한 철회는 `AppOpsManager.startWatchingMode` 로 감지해 창을 제거하고 서비스를 종료한다.
- 개인정보 화면에서 기록 삭제 / 전체 삭제(기준 옷·기록·설정 + 서비스 중지) 가능.
- `allowBackup=false`.
- 릴리스 빌드는 HTTPS 만 허용(에뮬레이터용 10.0.2.2/localhost 예외). 디버그 빌드는 LAN 테스트를 위해 평문 허용.
