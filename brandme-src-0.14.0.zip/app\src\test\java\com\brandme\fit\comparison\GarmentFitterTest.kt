package com.brandme.fit.comparison

import com.brandme.fit.body3d.GarmentFitter
import com.brandme.fit.body3d.HeatLevel
import com.brandme.fit.body3d.HumanBodyModel
import com.brandme.fit.body3d.MannequinDims
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.Measurements
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class GarmentFitterTest {
    private val model by lazy {
        val dir = listOf(File("src/main/assets/body"), File("app/src/main/assets/body")).first { it.exists() }
        HumanBodyModel.load(File(dir, "body_model.bin").readBytes(), File(dir, "body_model.json").readText())
    }
    private val profile = BodyProfile(heightCm = 176.0, shoulderCm = 42.0, chestCm = 96.0, waistCm = 82.0, hipCm = 95.0, armCm = 58.0)
    private val dims = MannequinDims.from(profile)
    private val body by lazy { model.build(dims) }

    private fun share(colors: FloatArray, level: HeatLevel): Double {
        val r = ((level.rgb shr 16) and 0xFF) / 255f
        val n = colors.size / 3
        return (0 until n).count { kotlin.math.abs(colors[it * 3] - r) < 0.01f }.toDouble() / n
    }

    @Test fun `regular tee covers the torso down to its length`() {
        val g = GarmentFitter.fit(body, dims, Measurements(shoulderCm = 44.0, chestFlatCm = 53.0, lengthCm = 70.0, sleeveCm = 21.0))
        val ys = (0 until g.mesh.vertexCount).map { g.mesh.positions[it * 3 + 1] }
        assertTrue(ys.min() in 70f..90f)                             // 밑단: 목 옆점 − 총장, 가랑이 아래면 가랑이에서 자름
        assertTrue(ys.max() < 0.86 * 176)                           // 목 위로 올라가지 않음
        assertTrue(g.mesh.vertexCount > 1000)
        assertTrue(share(g.heatColors, HeatLevel.TIGHT) < 0.2)      // 가슴 +10 정핏: 대부분 끼지 않음
    }

    @Test fun `too small shirt shows tight areas`() {
        val g = GarmentFitter.fit(body, dims, Measurements(shoulderCm = 38.0, chestFlatCm = 42.0, lengthCm = 62.0, sleeveCm = 18.0))
        assertTrue(share(g.heatColors, HeatLevel.TIGHT) > 0.4)
    }

    @Test fun `drop shoulder sleeves start further down the arm`() {
        fun armVerts(shoulder: Double) = GarmentFitter.fit(body, dims, Measurements(shoulderCm = shoulder, chestFlatCm = 60.0, lengthCm = 70.0, sleeveCm = 20.0)).mesh.vertexCount
        assertTrue(armVerts(60.0) > armVerts(44.0))  // 어깨선이 팔로 내려오면 소매 끝도 더 아래 → 덮는 팔 면적 증가
    }

    @Test fun `long garment is cut at the crotch`() {
        val g = GarmentFitter.fit(body, dims, Measurements(shoulderCm = 44.0, chestFlatCm = 55.0, lengthCm = 110.0))
        assertTrue(g.hemCutAtCrotch)
        val short = GarmentFitter.fit(body, dims, Measurements(shoulderCm = 44.0, chestFlatCm = 55.0, lengthCm = 50.0))
        assertTrue(!short.hemCutAtCrotch)
    }

    @Test fun `short sleeves are not colored as too short`() {
        val g = GarmentFitter.fit(body, dims, Measurements(shoulderCm = 44.0, chestFlatCm = 53.0, lengthCm = 60.0, sleeveCm = 21.0))
        assertTrue(share(g.heatColors, HeatLevel.TIGHT) < 0.05)
    }
}
