package com.brandme.fit.ui.result

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.brandme.fit.BuildConfig
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.ui.draw.clip
import com.brandme.fit.body3d.HeatLevel
import com.brandme.fit.body3d.Mannequin3D
import com.brandme.fit.comparison.BodyFitEngine
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.comparison.BodyFitItem
import com.brandme.fit.comparison.BodyFitResult
import com.brandme.fit.data.model.ComparisonResult
import com.brandme.fit.data.model.ComparisonWarning
import com.brandme.fit.data.model.DetectedProduct
import com.brandme.fit.data.model.IdentificationStatus
import com.brandme.fit.data.model.MeasureItem
import com.brandme.fit.data.model.SizeChart
import com.brandme.fit.data.model.VerificationStatus
import com.brandme.fit.recognition.AnalysisError
import com.brandme.fit.recognition.AnalysisOutcome
import com.brandme.fit.recognition.AnalysisStage
import com.brandme.fit.ui.theme.DemoAmber
import com.brandme.fit.ui.theme.OkGreen
import com.brandme.fit.ui.theme.WarnRed

sealed interface PanelState {
    data object Hidden : PanelState
    data object ConsentExplain : PanelState
    data class Loading(val stage: AnalysisStage) : PanelState
    data class Outcome(val outcome: AnalysisOutcome) : PanelState
}

/** 오버레이 하단 패널 (SCR-06 로딩, SCR-07 결과, SCR-08 오류, 캡처 동의 전 안내) */
@Composable
fun OverlayPanel(
    state: PanelState,
    onClose: () -> Unit,
    onCancel: () -> Unit,
    onContinueConsent: () -> Unit,
    onPickCandidate: (String) -> Unit,
    onOpenApp: () -> Unit,
) {
    if (state == PanelState.Hidden) return
    Surface(
        modifier = Modifier.fillMaxWidth().padding(8.dp),
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 6.dp,
        shadowElevation = 12.dp,
    ) {
        Column(
            Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            when (state) {
                PanelState.ConsentExplain -> ConsentExplainContent(onContinueConsent, onClose)
                is PanelState.Loading -> LoadingContent(state.stage, onCancel)
                is PanelState.Outcome -> OutcomeContent(state.outcome, onClose, onPickCandidate, onOpenApp)
                PanelState.Hidden -> Unit
            }
        }
    }
}

@Composable
fun ConsentExplainContent(onContinue: () -> Unit, onCancel: () -> Unit) {
    Text("화면 캡처 승인이 필요해요", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Text(
        "지금 보고 있는 상품과 사이즈표를 읽기 위해 화면 캡처를 사용해요. " +
            "버튼을 누를 때만 한 장을 읽고, 원본 이미지는 저장하지 않으며 분석 후 바로 지워요. " +
            "Demo Mode에서는 외부로 아무것도 보내지 않아요.",
        style = MaterialTheme.typography.bodyMedium,
    )
    Text(
        "다음 화면에서 Android가 캡처 동의를 물어봐요. 세션마다 새로 동의를 받아요.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = onCancel) { Text("취소") }
        Button(onClick = onContinue) { Text("계속") }
    }
}

@Composable
fun LoadingContent(stage: AnalysisStage, onCancel: () -> Unit) {
    Text("현재 상품을 분석하고 있어요.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    val stages = listOf(AnalysisStage.RECOGNIZING, AnalysisStage.FINDING_SIZE_CHART, AnalysisStage.COMPARING)
    val current = stages.indexOf(stage).coerceAtLeast(0)
    stages.forEachIndexed { i, s ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            when {
                i < current -> Text("✓", color = OkGreen, modifier = Modifier.width(24.dp))
                i == current -> CircularProgressIndicator(Modifier.size(16.dp).padding(end = 0.dp), strokeWidth = 2.dp)
                else -> Text("·", modifier = Modifier.width(24.dp))
            }
            if (i == current) Spacer(Modifier.width(8.dp))
            Text(s.label, fontWeight = if (i == current) FontWeight.Bold else FontWeight.Normal)
        }
    }
    OutlinedButton(onClick = onCancel) { Text("분석 취소") }
}

@Composable
fun OutcomeContent(
    outcome: AnalysisOutcome,
    onClose: () -> Unit,
    onPickCandidate: (String) -> Unit,
    onOpenApp: (() -> Unit)? = null,
) {
    when (outcome) {
        is AnalysisOutcome.Success -> {
            SuccessContent(outcome.product, outcome.chart, outcome.result, outcome.bodyFit, outcome.body)
            if (BuildConfig.DEBUG && !outcome.screenRows.isNullOrEmpty()) ScreenRowsDebug(outcome.screenRows)
        }
        is AnalysisOutcome.NeedsCandidateChoice -> CandidateContent(outcome.product, onPickCandidate)
        is AnalysisOutcome.Failure -> FailureContent(outcome, onOpenApp)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Button(onClick = onClose) { Text("닫고 쇼핑 계속하기") }
    }
}

@Composable
private fun Badge(text: String, color: Color) {
    Text(
        text,
        color = Color.White,
        style = MaterialTheme.typography.labelSmall,
        modifier = Modifier.background(color, RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp),
    )
}

@Composable
private fun ProductHeader(product: DetectedProduct, chart: SizeChart?) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        val idColor = when (product.status) {
            IdentificationStatus.EXACT_MATCH -> OkGreen
            else -> DemoAmber
        }
        Badge(if (product.userConfirmed) "사용자가 선택한 상품" else product.status.label, idColor)
        if (product.isDemo || chart?.verification == VerificationStatus.DEMO) Badge("DEMO", DemoAmber)
    }
    Text(product.name ?: "상품명 미확인", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    product.brand?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
    if (chart != null) {
        Text(
            "사이즈표 출처: ${chart.source.label} · ${chart.verification.label}" +
                (chart.verifiedAt?.let { " · 확인일 $it" } ?: ""),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun SuccessContent(
    product: DetectedProduct,
    chart: SizeChart,
    result: ComparisonResult?,
    bodyFit: BodyFitResult? = null,
    body: BodyProfile? = null,
) {
    ProductHeader(product, chart)
    HorizontalDivider()
    if (bodyFit != null && body != null) TryOnSection(body, chart, bodyFit)
    if (bodyFit != null) BodyFitSection(bodyFit)
    if (result != null) {
        if (bodyFit != null) HorizontalDivider()
        Text("기준 옷: ${result.referenceName}", style = MaterialTheme.typography.bodySmall)
        Text(ResultFormatter.closestSentence(result), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        result.rankedSizes.filter { it.sizeLabel in result.closestSizes }.forEach { s ->
            Text(
                (if (result.closestSizes.size > 1) "${s.sizeLabel}: " else "") + ResultFormatter.diffSentence(s),
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        DiffTable(result)
    }
    ReadChartTable(chart)
    val warnings = result?.warnings ?: listOfNotNull(
        ComparisonWarning.DEMO_DATA.takeIf { chart.verification == VerificationStatus.DEMO },
        ComparisonWarning.UNVERIFIED_DATA.takeIf { chart.verification == VerificationStatus.UNVERIFIED },
    )
    warnings.forEach { w ->
        Text("• ${w.message}", style = MaterialTheme.typography.bodySmall,
            color = if (w.name.startsWith("DEMO")) DemoAmber else MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Text(
        ResultFormatter.DISCLAIMER,
        style = MaterialTheme.typography.bodySmall,
        fontWeight = FontWeight.SemiBold,
    )
    Text(
        listOfNotNull(
            bodyFit?.let { "몸 기준 v${it.algorithmVersion.removePrefix("body-")} · 여유 = 옷 − 몸" },
            result?.let { "기준 옷 v${it.algorithmVersion} · 차이 = 상품 − 기준 옷" },
        ).joinToString("  |  "),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

/**
 * 3D 입혀 보기: 내 몸 모형에 고른 사이즈의 옷을 입히고 부위별 핏을 색으로 보여 준다.
 * 사이즈 버튼으로 바꿔 보며 비교한다. 사이즈표 숫자로 만든 근사 모형이라 원단·주름·신축성은 반영하지 않는다.
 */
@Composable
private fun TryOnSection(body: BodyProfile, chart: SizeChart, fit: BodyFitResult) {
    var selected by remember(chart) { mutableStateOf(fit.recommended.firstOrNull() ?: chart.sizes.first().label) }
    var heat by remember { mutableStateOf(true) }
    var big by remember { mutableStateOf(false) }
    val garment = chart.sizes.firstOrNull { it.label == selected }?.measurements
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("내 몸에 입혀 보기", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Box {
            Mannequin3D(
                body, Modifier.fillMaxWidth().height(if (big) 520.dp else 320.dp).clip(RoundedCornerShape(12.dp)),
                garment = garment, heatMap = heat,
            )
            TextButton(onClick = { big = !big }, modifier = Modifier.align(Alignment.TopEnd)) {
                Text(if (big) "작게" else "크게 보기", color = Color.White)
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            chart.sizes.forEach { s ->
                val rec = s.label in fit.recommended
                FilterChip(
                    selected = s.label == selected,
                    onClick = { selected = s.label },
                    label = { Text(s.label + if (rec) " ★" else "") },
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("핏 색상", style = MaterialTheme.typography.bodySmall)
            Switch(checked = heat, onCheckedChange = { heat = it })
        }
        if (heat) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HeatLevel.entries.forEach { l ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(Color(0xFF000000.toInt() or l.rgb), RoundedCornerShape(2.dp)))
                        Spacer(Modifier.width(4.dp))
                        Text(l.label, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        fit.sizes.firstOrNull { it.sizeLabel == selected }?.let { s ->
            Text(
                "$selected: " + s.eases.joinToString(" · ") { "${it.item.label} ${BodyFitEngine.formatEase(it.easeCm)} ${it.level.label}" },
                style = MaterialTheme.typography.bodySmall,
            )
        }
        if (garment?.lengthCm != null && body.heightCm * 0.835 - garment.lengthCm < body.heightCm * 0.47) {
            Text("이 옷은 가랑이 아래까지 오는 길이라, 3D 에서는 밑단을 가랑이 높이에서 잘라 그렸어요.", style = MaterialTheme.typography.labelSmall)
        }
        Text(
            "사이즈표 숫자로 만든 근사 모형이에요. 원단 두께·주름·신축성은 반영하지 않아요.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** 내 몸 치수 기준 결과: 선호 핏에 가까운 사이즈와 사이즈별 여유분 */
@Composable
private fun BodyFitSection(fit: BodyFitResult) {
    Text("내 몸 기준 · 선호 핏 ${fit.preferredFit.label}", style = MaterialTheme.typography.bodySmall)
    Text(ResultFormatter.bodySentence(fit), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    val items = BodyFitItem.entries.filter { it in fit.items }
    if (items.isNotEmpty()) {
        Column(Modifier.horizontalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row {
                Cell("사이즈", bold = true)
                items.forEach { Cell("${it.label} 여유", bold = true) }
            }
            fit.sizes.forEach { s ->
                val best = s.sizeLabel in fit.recommended
                Row {
                    Cell(s.sizeLabel + if (best) " ★" else "", bold = best)
                    items.forEach { item ->
                        val e = s.eases.firstOrNull { it.item == item }
                        Cell(e?.let { "${BodyFitEngine.formatEase(it.easeCm)} ${it.level.label}" } ?: "-")
                    }
                }
            }
        }
    }
    fit.notes.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    var showRules by remember { mutableStateOf(false) }
    TextButton(onClick = { showRules = !showRules }) { Text(if (showRules) "판단 기준 닫기" else "판단 기준 보기") }
    if (showRules) {
        BodyFitEngine.RULES_TEXT.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        Text(
            "기준값은 일반적인 상의 여유분 관례에서 정한 참고값이에요. 소재·신축성은 반영하지 않아요.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** 비교에 쓴 사이즈표 원본 값. 어떤 숫자를 어느 항목으로 읽었는지 사용자가 상품 페이지와 대조할 수 있게 한다. */
@Composable
private fun ReadChartTable(chart: SizeChart) {
    val items = MeasureItem.entries.filter { item -> chart.sizes.any { it.measurements[item] != null } }
    if (items.isEmpty()) return
    Text("읽은 사이즈표 (${chart.unit})", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
    Column(Modifier.horizontalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row {
            Cell("사이즈", bold = true)
            items.forEach { Cell(it.label, bold = true) }
        }
        chart.sizes.forEach { s ->
            Row {
                Cell(s.label)
                items.forEach { item -> Cell(s.measurements[item]?.let { ResultFormatter.cm(it) } ?: "-") }
            }
        }
    }
    if (chart.skippedItems.isNotEmpty()) {
        Text(
            "표에 있던 '${chart.skippedItems.joinToString("', '")}' 은(는) 어떤 부위인지 확실하지 않아 비교에서 뺐어요.",
            style = MaterialTheme.typography.bodySmall,
            color = DemoAmber,
        )
    }
}

@Composable
private fun DiffTable(result: ComparisonResult) {
    val items = listOf(MeasureItem.SHOULDER, MeasureItem.CHEST_FLAT, MeasureItem.LENGTH, MeasureItem.SLEEVE)
        .filter { it in result.comparedItems || result.unrankedSizes.any { s -> it in s.comparedItems } }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row {
            Cell("사이즈", bold = true)
            items.forEach { Cell(it.label, bold = true) }
        }
        result.rankedSizes.forEach { s ->
            Row {
                Cell(s.sizeLabel + if (s.sizeLabel in result.closestSizes) " ★" else "", bold = s.sizeLabel in result.closestSizes)
                items.forEach { item -> Cell(s.diffs[item]?.let { ResultFormatter.diffLabel(item, it) } ?: "-") }
            }
        }
        if (result.unrankedSizes.isNotEmpty()) {
            Text("순위 제외(비교 항목 구성이 다름)", style = MaterialTheme.typography.labelSmall)
            result.unrankedSizes.forEach { s ->
                Row {
                    Cell(s.sizeLabel)
                    items.forEach { item -> Cell(s.diffs[item]?.let { ResultFormatter.diffLabel(item, it) } ?: "-") }
                }
            }
        }
    }
}

@Composable
private fun Cell(text: String, bold: Boolean = false) {
    Text(
        text,
        modifier = Modifier.width(68.dp),
        style = MaterialTheme.typography.bodySmall,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
    )
}

@Composable
private fun CandidateContent(product: DetectedProduct, onPick: (String) -> Unit) {
    Text(AnalysisError.MULTIPLE_CANDIDATES.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Text(AnalysisError.MULTIPLE_CANDIDATES.message, style = MaterialTheme.typography.bodyMedium)
    product.candidates.forEach { c ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(c.name, fontWeight = FontWeight.SemiBold)
                Text(c.brand + (c.shop?.let { " · $it" } ?: ""), style = MaterialTheme.typography.bodySmall)
            }
            if (!c.id.startsWith("remote-")) TextButton(onClick = { onPick(c.id) }) { Text("이 상품이에요") }
        }
    }
}

@Composable
private fun FailureContent(f: AnalysisOutcome.Failure, onOpenApp: (() -> Unit)?) {
    f.product?.takeIf { it.status != IdentificationStatus.NOT_FOUND || it.name != null }?.let { ProductHeader(it, null) }
    Text(f.error.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = WarnRed)
    Text(f.error.message, style = MaterialTheme.typography.bodyMedium)
    f.detail?.let { Text("상세: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    Text("사이즈 값을 추측해서 보여 주지 않아요.", style = MaterialTheme.typography.bodySmall)
    if (BuildConfig.DEBUG && !f.screenRows.isNullOrEmpty()) ScreenRowsDebug(f.screenRows)
    if (onOpenApp != null && (f.error == AnalysisError.REFERENCE_INCOMPLETE || f.error == AnalysisError.AI_CONSENT_REQUIRED)) {
        OutlinedButton(onClick = onOpenApp) { Text("앱에서 설정하기") }
    }
}

/** 디버그 빌드 전용: OCR 이 읽은 행을 보여 줘 사이즈표 인식 실패 원인을 확인한다. 저장하지 않는다. */
@Composable
private fun ScreenRowsDebug(rows: List<String>) {
    var open by remember { mutableStateOf(false) }
    TextButton(onClick = { open = !open }) { Text(if (open) "인식된 텍스트 닫기 (디버그)" else "인식된 텍스트 보기 (디버그)") }
    if (open) {
        Text("앱 버전 ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodySmall)
        Text(
            rows.take(120).joinToString("\n") { it.replace('\t', '|') },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
