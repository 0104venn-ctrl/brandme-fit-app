package com.brandme.fit.body3d

import com.brandme.fit.comparison.BodyFitEngine
import com.brandme.fit.data.model.Measurements
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** 입힌 옷: 메시, 정점별 색(핏 색상 지도), 기본 옷 색 */
class FittedGarment(
    val mesh: Mesh,
    val heatColors: FloatArray,
    val plainColors: FloatArray,
    val hemCutAtCrotch: Boolean,
)

/** 핏 색상 지도의 색 단계 */
enum class HeatLevel(val label: String, val rgb: Int) {
    TIGHT("낌", 0xE5484D),
    FITTED("딱 맞음", 0xF5C542),
    COMFORT("적당한 여유", 0x46B86F),
    LOOSE("많이 남음", 0x4A8FE7),
}

/**
 * 사이즈표 숫자로 상의를 3D 로 만들어 몸에 입힌다(천 시뮬레이션이 아닌 형태 근사).
 *
 *  - 몸판: 겨드랑이 아래로는 "위에서 가장 튀어나온 곳에서 천이 곧게 떨어지는" 원통이다.
 *    높이마다 그 높이와 그 위 몸 단면을 모두 감싸는 볼록 윤곽을 만들고, 둘레가 옷 둘레(가슴 단면 × 2)가 되도록 띄운다.
 *    밑단은 수평으로 반듯하게 자른다.
 *  - 어깨: 어깨 위는 몸에 얹힌 천(요크)으로, 몸 표면을 살짝 띄워 만든다(목은 비운다).
 *  - 소매: 팔 축을 따라가는 원통. 어깨선이 몸 어깨보다 바깥이면(드롭숄더) 그만큼 팔 위로 내려와 시작한다.
 * 색 기준은 BodyFitEngine 의 여유 구간과 같다.
 */
object GarmentFitter {

    private const val TORSO = 2
    private const val LEGS = 9
    private const val AROUND = 48
    private const val SLEEVE_AROUND = 24

    private fun rgb(c: Int) = floatArrayOf(((c shr 16) and 0xFF) / 255f, ((c shr 8) and 0xFF) / 255f, (c and 0xFF) / 255f)

    fun torsoLevel(ease: Double) = when {
        ease < BodyFitEngine.CHEST_RULES[0].first -> HeatLevel.TIGHT
        ease < BodyFitEngine.CHEST_RULES[1].first -> HeatLevel.FITTED
        ease < BodyFitEngine.CHEST_RULES[3].first -> HeatLevel.COMFORT
        else -> HeatLevel.LOOSE
    }

    fun shoulderLevel(ease: Double) = when {
        ease < -2 -> HeatLevel.TIGHT
        ease < 2 -> HeatLevel.FITTED
        ease < 6 -> HeatLevel.COMFORT
        else -> HeatLevel.LOOSE
    }

    fun sleeveLevel(ease: Double) = when {
        ease < -3 -> HeatLevel.TIGHT
        ease < 3 -> HeatLevel.FITTED
        else -> HeatLevel.LOOSE
    }

    private class P2(val x: Double, val z: Double)

    /** 볼록 껍질(반시계) */
    private fun hull(pts: List<P2>): List<P2> {
        if (pts.size < 3) return pts
        val s = pts.sortedWith(compareBy({ it.x }, { it.z }))
        fun cross(o: P2, a: P2, b: P2) = (a.x - o.x) * (b.z - o.z) - (a.z - o.z) * (b.x - o.x)
        val lower = ArrayList<P2>(); val upper = ArrayList<P2>()
        for (q in s) { while (lower.size >= 2 && cross(lower[lower.size - 2], lower.last(), q) <= 0) lower.removeAt(lower.size - 1); lower += q }
        for (q in s.asReversed()) { while (upper.size >= 2 && cross(upper[upper.size - 2], upper.last(), q) <= 0) upper.removeAt(upper.size - 1); upper += q }
        return lower.dropLast(1) + upper.dropLast(1)
    }

    private fun perimeter(h: List<P2>) = h.indices.sumOf { i ->
        val a = h[i]; val b = h[(i + 1) % h.size]; sqrt((a.x - b.x) * (a.x - b.x) + (a.z - b.z) * (a.z - b.z))
    }

    fun hullPerimeter(pts: List<Pair<Float, Float>>): Double = perimeter(hull(pts.map { P2(it.first.toDouble(), it.second.toDouble()) }))

    /** 중심에서 θ 방향으로 껍질까지의 거리 */
    private fun radiusAt(h: List<P2>, cx: Double, cz: Double, th: Double): Double {
        val dx = cos(th); val dz = sin(th)
        var best = 0.0
        for (i in h.indices) {
            val a = h[i]; val b = h[(i + 1) % h.size]
            val ex = b.x - a.x; val ez = b.z - a.z
            val den = dx * ez - dz * ex
            if (abs(den) < 1e-9) continue
            val t = ((a.x - cx) * ez - (a.z - cz) * ex) / den
            val u = ((a.x - cx) * dz - (a.z - cz) * dx) / den
            if (t > 0 && u in -1e-6..1.000001) best = maxOf(best, t)
        }
        return best
    }

    private class Builder {
        val pos = ArrayList<Float>(); val col = ArrayList<Float>(); val idx = ArrayList<Int>()
        fun add(x: Double, y: Double, z: Double, c: HeatLevel): Int {
            pos += x.toFloat(); pos += y.toFloat(); pos += z.toFloat()
            val r = rgb(c.rgb); col += r[0]; col += r[1]; col += r[2]
            return pos.size / 3 - 1
        }
        fun ringStrip(rings: List<List<Int>>) {
            for (i in 0 until rings.size - 1) {
                val a = rings[i]; val b = rings[i + 1]; val n = a.size
                for (j in 0 until n) { val j2 = (j + 1) % n; idx += a[j]; idx += b[j]; idx += a[j2]; idx += a[j2]; idx += b[j]; idx += b[j2] }
            }
        }
    }

    fun fit(body: HumanBodyModel.Result, dims: MannequinDims, garment: Measurements): FittedGarment {
        val m = body.mesh
        val p = m.positions; val n = m.normals; val parts = body.parts; val armT = body.armT
        val h = dims.height
        val crotchY = (0 until m.vertexCount).filter { parts[it] == TORSO }.minOf { p[it * 3 + 1] }.toDouble()

        // 높이별 몸통 단면 점(몸통 + 골반·허벅지 윗부분, 팔 제외)
        val bins = HashMap<Int, ArrayList<P2>>()
        for (i in 0 until m.vertexCount) {
            val y = p[i * 3 + 1]
            if (parts[i] == TORSO || (parts[i] == LEGS && y > crotchY - 0.06 * h)) {
                bins.getOrPut(y.toInt()) { ArrayList() } += P2(p[i * 3].toDouble(), p[i * 3 + 2].toDouble())
            }
        }
        fun sectionAt(y: Double): List<P2> = (-1..1).flatMap { bins[y.toInt() + it].orEmpty() }

        val hpsY = 0.835 * h
        val armpitY = 0.735 * h
        val yokeY = 0.795 * h                         // 이 위는 어깨에 얹힌 천
        val length = garment.lengthCm ?: (0.40 * h)
        var hemY = hpsY - length
        val hemCut = hemY < crotchY + 1.0
        if (hemCut) hemY = crotchY + 1.0
        val garmentGirth = garment.chestCircumferenceCm ?: garment.chestFlatCm?.let { it * 2 } ?: (dims.chest + 10)
        val shoulderEase = garment.shoulderCm?.let { it - dims.shoulder } ?: 1.0
        val drop = maxOf(0.0, shoulderEase / 2)
        val sleeveLen = garment.sleeveCm ?: (dims.arm * 0.35)
        val shortSleeve = sleeveLen < dims.arm * 0.6
        val sleeveEase = garment.sleeveCm?.let { (garment.shoulderCm ?: dims.shoulder) / 2 + it - (dims.shoulder / 2 + dims.arm) } ?: 0.0

        val b = Builder()

        // ---- 몸판: 위(어깨 요크 아래)에서 밑단까지. 겨드랑이 아래는 위 단면까지 함께 감싸 곧게 떨어지게 한다
        val step = 1.5
        val ys = generateSequence(yokeY) { it - step }.takeWhile { it > hemY }.toList() + hemY
        var accum = ArrayList<P2>()
        val rings = ArrayList<List<Int>>()
        for (y in ys) {
            val own = hull(sectionAt(y))
            if (own.size < 3) continue
            if (y <= armpitY) accum.addAll(own) else accum = ArrayList(own)
            val shape = hull(accum)
            accum = ArrayList(shape)
            val cx = shape.sumOf { it.x } / shape.size; val cz = shape.sumOf { it.z } / shape.size
            val bodyGirth = perimeter(own)
            val target = if (y <= armpitY) garmentGirth else {
                // 겨드랑이 위: 옷 둘레에서 어깨 쪽 몸 둘레(+2cm)로 자연스럽게 이어진다
                val t = ((y - armpitY) / (yokeY - armpitY)).coerceIn(0.0, 1.0)
                garmentGirth * (1 - t) + (bodyGirth + 2.0) * t
            }
            val d = ((target - perimeter(shape)) / (2 * PI)).coerceIn(0.3, 12.0)
            val ease = garmentGirth - bodyGirth
            val level = if (y > armpitY + (yokeY - armpitY) * 0.5) shoulderLevel(shoulderEase) else torsoLevel(ease)
            rings += (0 until AROUND).map { k ->
                val th = 2 * PI * k / AROUND
                val r = radiusAt(shape, cx, cz, th) + d
                b.add(cx + r * cos(th), y, cz + r * sin(th), level)
            }
        }
        b.ringStrip(rings)

        // ---- 어깨 요크: 요크 높이 위의 몸통 표면(목 제외)을 살짝 띄운다
        val neckR = (sectionAt(hpsY).let { if (it.size >= 3) perimeter(hull(it)) else 36.0 }) / (2 * PI)
        val yokeTop = hpsY + 1.0
        val remap = IntArray(m.vertexCount) { -1 }
        fun inYoke(i: Int): Boolean {
            if (parts[i] != TORSO) return false
            val x = p[i * 3]; val y = p[i * 3 + 1]; val z = p[i * 3 + 2]
            if (y < yokeY - 2.0 || y > yokeTop + 1.0) return false
            return sqrt((x * x + z * z).toDouble()) > neckR + 0.8 || y < yokeTop - 1.5
        }
        val yokeLevel = shoulderLevel(shoulderEase)
        for (t in m.indices.indices step 3) {
            val a = m.indices[t]; val c2 = m.indices[t + 1]; val c3 = m.indices[t + 2]
            if (inYoke(a) && inYoke(c2) && inYoke(c3)) {
                for (v in intArrayOf(a, c2, c3)) if (remap[v] < 0) {
                    remap[v] = b.add(
                        (p[v * 3] + n[v * 3] * 0.45).toDouble(), (p[v * 3 + 1] + n[v * 3 + 1] * 0.45).toDouble(),
                        (p[v * 3 + 2] + n[v * 3 + 2] * 0.45).toDouble(), yokeLevel,
                    )
                }
                b.idx += remap[a]; b.idx += remap[c2]; b.idx += remap[c3]
            }
        }

        // ---- 소매: 팔 축을 따라가는 원통
        for (side in listOf(setOf(3, 5), setOf(4, 6))) {
            val arm = (0 until m.vertexCount).filter { parts[it] in side }
            if (arm.size < 20) continue
            fun centroid(sel: List<Int>) = DoubleArray(3) { k -> sel.sumOf { p[it * 3 + k].toDouble() } / sel.size }
            val sTop = centroid(arm.filter { armT[it] < 0.08f }.ifEmpty { arm })
            val sEnd = centroid(arm.filter { armT[it] > 0.92f }.ifEmpty { arm })
            val ax = DoubleArray(3) { sEnd[it] - sTop[it] }
            val axLen = sqrt(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2])
            for (k in 0..2) ax[k] /= axLen
            // 팔 축에 수직인 두 방향
            val ref = doubleArrayOf(0.0, 0.0, 1.0)
            val u = doubleArrayOf(ax[1] * ref[2] - ax[2] * ref[1], ax[2] * ref[0] - ax[0] * ref[2], ax[0] * ref[1] - ax[1] * ref[0])
            val ul = sqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]); for (k in 0..2) u[k] /= ul
            val v = doubleArrayOf(ax[1] * u[2] - ax[2] * u[1], ax[2] * u[0] - ax[0] * u[2], ax[0] * u[1] - ax[1] * u[0])
            // 축 위치별 팔 반지름: 그 위치 팔 단면 점들의 거리 중 상위 25% 값(어깨 쪽 몸통 점이 섞여 튀는 것을 막는다)
            fun armRadius(t: Double): Double {
                val near = arm.filter { abs(armT[it] * axLen - t) < 2.0 }
                if (near.size < 4) return 4.5
                val ds = near.map { i ->
                    val q = DoubleArray(3) { k -> p[i * 3 + k] - sTop[k] }
                    val along = q[0] * ax[0] + q[1] * ax[1] + q[2] * ax[2]
                    sqrt(maxOf(0.0, q[0] * q[0] + q[1] * q[1] + q[2] * q[2] - along * along))
                }.sorted()
                return ds[(ds.size * 0.75).toInt().coerceAtMost(ds.size - 1)]
            }
            val upperArmR = armRadius(axLen * 0.25)
            val start = -4.0 + minOf(drop, 6.0) * 0.3            // 몸판 안쪽에서 시작해 이음새를 감춘다
            val end = (drop + sleeveLen).coerceAtMost(axLen + 4.0)
            val stations = generateSequence(start) { it + 2.0 }.takeWhile { it < end }.toList() + end
            val sleeveRings = stations.map { t ->
                val k = ((t - start) / (end - start)).coerceIn(0.0, 1.0)
                // 소매 품: 팔보다 위쪽 1.2cm(드롭숄더는 조금 더), 소매 끝 0.6cm 정도 띄운다. 어깨 쪽에서 팔 굵기가 튀어도 위팔의 1.4배를 넘지 않게
                val armR = minOf(armRadius(t.coerceIn(0.0, axLen)), upperArmR * 1.4)
                val r = armR + (1.2 + minOf(drop, 10.0) * 0.12) * (1 - k) + 0.6 * k
                val level = when {
                    t < drop -> shoulderLevel(shoulderEase)
                    shortSleeve -> HeatLevel.COMFORT
                    else -> sleeveLevel(sleeveEase)
                }
                (0 until SLEEVE_AROUND).map { j ->
                    val th = 2 * PI * j / SLEEVE_AROUND
                    val cx = sTop[0] + ax[0] * t; val cy = sTop[1] + ax[1] * t; val cz = sTop[2] + ax[2] * t
                    b.add(cx + r * (u[0] * cos(th) + v[0] * sin(th)), cy + r * (u[1] * cos(th) + v[1] * sin(th)), cz + r * (u[2] * cos(th) + v[2] * sin(th)), level)
                }
            }
            b.ringStrip(sleeveRings)
        }

        val pos = b.pos.toFloatArray()
        val idx = b.idx.toIntArray()
        val heat = b.col.toFloatArray()
        val plain = rgb(0xB9C3CF).let { c -> FloatArray(heat.size) { c[it % 3] } }
        return FittedGarment(Mesh(pos, normals(pos, idx), idx), heat, plain, hemCut)
    }

    private fun normals(p: FloatArray, idx: IntArray): FloatArray {
        val out = FloatArray(p.size)
        for (t in idx.indices step 3) {
            val a = idx[t] * 3; val b = idx[t + 1] * 3; val c = idx[t + 2] * 3
            val ux = p[b] - p[a]; val uy = p[b + 1] - p[a + 1]; val uz = p[b + 2] - p[a + 2]
            val vx = p[c] - p[a]; val vy = p[c + 1] - p[a + 1]; val vz = p[c + 2] - p[a + 2]
            val fx = uy * vz - uz * vy; val fy = uz * vx - ux * vz; val fz = ux * vy - uy * vx
            for (k in intArrayOf(a, b, c)) { out[k] += fx; out[k + 1] += fy; out[k + 2] += fz }
        }
        for (i in 0 until p.size / 3) {
            val l = sqrt(out[i * 3] * out[i * 3] + out[i * 3 + 1] * out[i * 3 + 1] + out[i * 3 + 2] * out[i * 3 + 2]).coerceAtLeast(1e-9f)
            out[i * 3] /= l; out[i * 3 + 1] /= l; out[i * 3 + 2] /= l
        }
        return out
    }
}
