package com.brandme.fit.catalog

import com.brandme.fit.data.model.ChestMeasureMethod
import com.brandme.fit.data.model.Measurements
import com.brandme.fit.data.model.ProductSize
import com.brandme.fit.data.model.SizeChart
import com.brandme.fit.data.model.SizeChartSource
import com.brandme.fit.data.model.VerificationStatus
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** assets/demo_products.json 의 구조 */
@Serializable
data class CatalogFile(
    val version: Int,
    val products: List<CatalogProduct>,
)

@Serializable
data class CatalogProduct(
    val id: String,
    val brand: String,
    val name: String,
    val shop: String,
    val productCode: String? = null,
    val options: List<String>,
    val unit: String,
    val chestMethod: String = "UNKNOWN",
    val sizeChart: List<CatalogSize>,
    /** "verified" = 실제로 확인한 데이터, "demo" = 임의로 만든 데이터 */
    val source: String,
    val sourceDetail: String? = null,
    val verifiedAt: String? = null,
    /** 화면 텍스트 매칭용 추가 키워드(선택) */
    val keywords: List<String> = emptyList(),
) {
    val isDemo: Boolean get() = source != SOURCE_VERIFIED

    val verification: VerificationStatus
        get() = if (source == SOURCE_VERIFIED && !verifiedAt.isNullOrBlank()) VerificationStatus.VERIFIED
        else VerificationStatus.DEMO

    fun toSizeChart(): SizeChart = SizeChart(
        sizes = sizeChart.map { it.toProductSize() },
        unit = unit,
        source = SizeChartSource.LOCAL_CATALOG,
        verification = verification,
        sourceDetail = sourceDetail,
        verifiedAt = verifiedAt,
        chestMethod = runCatching { ChestMeasureMethod.valueOf(chestMethod) }.getOrDefault(ChestMeasureMethod.UNKNOWN),
    )

    companion object {
        const val SOURCE_VERIFIED = "verified"
        const val SOURCE_DEMO = "demo"
    }
}

@Serializable
data class CatalogSize(
    val label: String,
    val shoulder: Double? = null,
    @SerialName("chestFlat") val chestFlat: Double? = null,
    @SerialName("chestCircumference") val chestCircumference: Double? = null,
    val length: Double? = null,
    val sleeve: Double? = null,
) {
    fun toProductSize() = ProductSize(
        label = label,
        measurements = Measurements(
            shoulderCm = shoulder,
            chestFlatCm = chestFlat,
            lengthCm = length,
            sleeveCm = sleeve,
            chestCircumferenceCm = chestCircumference,
        ),
    )
}
