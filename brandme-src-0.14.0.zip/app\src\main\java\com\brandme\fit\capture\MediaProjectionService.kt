package com.brandme.fit.capture

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.WindowManager
import com.brandme.fit.BrandmeFitApp
import com.brandme.fit.R
import kotlinx.coroutines.android.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * 화면 캡처 전용 포그라운드 서비스 (foregroundServiceType=mediaProjection).
 *
 * - 캡처 세션마다 사용자 동의를 새로 받는다. 동의 토큰(Intent)은 저장/재사용하지 않는다.
 * - MediaProjection 하나당 VirtualDisplay 는 하나만 만든다.
 * - MediaProjection.Callback.onStop 에서 모든 자원을 해제한다.
 * - 회전/크기 변경 시 VirtualDisplay 를 resize 하고 ImageReader 를 교체한다.
 * - 프레임은 메모리에만 두고, 캡처 요청 시 Bitmap 으로 복사해 넘긴 뒤 바로 닫는다.
 */
class MediaProjectionService : Service(), ScreenCapturer {

    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var width = 0
    private var height = 0
    private var dpi = 0

    /** 가장 최근 프레임(1장만 유지). handler 스레드에서만 접근. */
    private var latest: Image? = null
    private var latestAtNanos = 0L
    @Volatile private var contentVisible = true

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() {
            // 사용자가 상태 표시줄 칩에서 중지했거나 화면이 잠겼을 때 등
            handler.post { releaseProjection("캡처 세션이 종료되었어요.") }
            Handler(Looper.getMainLooper()).post { stopSelfSafely() }
        }

        override fun onCapturedContentResize(w: Int, h: Int) {
            handler.post { resize(w, h) }
        }

        override fun onCapturedContentVisibilityChanged(isVisible: Boolean) {
            contentVisible = isVisible
        }
    }

    override fun onCreate() {
        super.onCreate()
        thread = HandlerThread("brandme-capture").apply { start() }
        handler = Handler(thread.looper)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                handler.post { releaseProjection("사용자가 캡처를 중지했어요.") }
                stopSelfSafely()
            }
            ACTION_START -> start(intent)
            else -> stopSelfSafely()
        }
        return START_NOT_STICKY // 시스템이 재시작해도 자동으로 캡처를 다시 시작하지 않는다.
    }

    private fun start(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        if (data == null) {
            CaptureCoordinator.onConsentDenied()
            stopSelfSafely()
            return
        }
        try {
            // Android 14+: getMediaProjection 전에 mediaProjection 타입으로 포그라운드 시작이 필요하다.
            startForeground(NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            CaptureCoordinator.reportError("캡처 서비스를 시작하지 못했어요.")
            CaptureCoordinator.onConsentDenied()
            stopSelfSafely()
            return
        }
        handler.post {
            // 이전 세션이 남아 있으면 먼저 정리한다(토큰 재사용 안 함).
            releaseProjection(null)
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val mp = try {
                mpm.getMediaProjection(resultCode, data)
            } catch (e: Exception) {
                Log.e(TAG, "getMediaProjection failed", e)
                null
            }
            if (mp == null) {
                CaptureCoordinator.reportError("캡처 세션을 만들지 못했어요.")
                CaptureCoordinator.onConsentDenied()
                Handler(Looper.getMainLooper()).post { stopSelfSafely() }
                return@post
            }
            projection = mp
            mp.registerCallback(callback, handler) // createVirtualDisplay 전에 등록해야 한다.
            try {
                createDisplay(mp)
                CaptureCoordinator.attach(this)
            } catch (e: Exception) {
                Log.e(TAG, "createVirtualDisplay failed", e)
                CaptureCoordinator.reportError("가상 디스플레이를 만들지 못했어요.")
                releaseProjection("캡처를 시작하지 못했어요.")
                Handler(Looper.getMainLooper()).post { stopSelfSafely() }
            }
        }
    }

    private fun screenSize(): Triple<Int, Int, Int> {
        val bounds = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
        return Triple(bounds.width(), bounds.height(), resources.configuration.densityDpi)
    }

    private fun newReader(w: Int, h: Int): ImageReader =
        ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3).apply {
            setOnImageAvailableListener({ r ->
                val img = try { r.acquireLatestImage() } catch (e: IllegalStateException) { null } ?: return@setOnImageAvailableListener
                latest?.close()
                latest = img
                latestAtNanos = System.nanoTime()
            }, handler)
        }

    private fun createDisplay(mp: MediaProjection) {
        check(virtualDisplay == null) { "VirtualDisplay already exists for this projection" }
        val (w, h, d) = screenSize()
        width = w; height = h; dpi = d
        val r = newReader(w, h)
        reader = r
        virtualDisplay = mp.createVirtualDisplay(
            "brandme-fit-capture", w, h, d,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler,
        )
    }

    /** handler 스레드에서 호출 */
    private fun resize(w: Int, h: Int) {
        val vd = virtualDisplay ?: return
        if (w <= 0 || h <= 0 || (w == width && h == height)) return
        val old = reader
        val r = newReader(w, h)
        width = w; height = h
        vd.resize(w, h, dpi)
        vd.surface = r.surface
        reader = r
        latest?.close(); latest = null
        old?.close()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val (w, h, d) = screenSize()
        handler.post { dpi = d; resize(w, h) }
    }

    override suspend fun capture(requestedAtNanos: Long): CaptureResult {
        if (!contentVisible) return CaptureResult.Failed("캡처 대상 앱이 지금 화면에 보이지 않아요.")
        val dispatcher = handler.asCoroutineDispatcher()
        // 오버레이를 숨긴 뒤의 새 프레임을 최대 700ms 기다린다. 화면 변화가 없으면 최신 프레임을 쓴다.
        var waitedMs = 0
        while (waitedMs < 700) {
            val fresh = withContext(dispatcher) { latest != null && latestAtNanos >= requestedAtNanos }
            if (fresh) break
            delay(50)
            waitedMs += 50
        }
        return withContext(dispatcher) {
            val img = latest ?: return@withContext CaptureResult.Failed("캡처된 프레임이 없어요.")
            try {
                val bmp = img.toBitmap()
                latest = null
                if (isMostlyBlack(bmp)) {
                    bmp.recycle()
                    CaptureResult.ProtectedOrBlank
                } else CaptureResult.Ok(bmp)
            } catch (e: Exception) {
                Log.e(TAG, "frame copy failed", e)
                CaptureResult.Failed("프레임을 읽지 못했어요.")
            } finally {
                img.close()
            }
        }
    }

    private fun Image.toBitmap(): Bitmap {
        val plane = planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * width
        val padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
        plane.buffer.rewind()
        padded.copyPixelsFromBuffer(plane.buffer)
        if (padded.width == width) return padded
        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return cropped
    }

    /** FLAG_SECURE 화면은 캡처 결과가 검게 나온다. 97% 이상이 거의 검정이면 보호 화면으로 본다. */
    private fun isMostlyBlack(bmp: Bitmap): Boolean {
        val steps = 40
        var dark = 0
        for (i in 0 until steps) for (j in 0 until steps) {
            val p = bmp.getPixel((bmp.width - 1) * i / (steps - 1), (bmp.height - 1) * j / (steps - 1))
            val r = (p shr 16) and 0xff; val g = (p shr 8) and 0xff; val b = p and 0xff
            if (r < 12 && g < 12 && b < 12) dark++
        }
        return dark >= steps * steps * 0.97
    }

    /** handler 스레드에서 호출. reason 이 null 이면 이벤트를 보내지 않는다(세션 교체 시). */
    private fun releaseProjection(reason: String?) {
        latest?.close(); latest = null
        virtualDisplay?.release(); virtualDisplay = null
        reader?.close(); reader = null
        projection?.let {
            it.unregisterCallback(callback)
            it.stop()
        }
        projection = null
        if (reason != null) CaptureCoordinator.detach(this, reason)
    }

    private fun stopSelfSafely() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.post { releaseProjection("캡처 서비스가 종료되었어요.") }
        thread.quitSafely()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 1, Intent(this, MediaProjectionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return Notification.Builder(this, BrandmeFitApp.CHANNEL_CAPTURE)
            .setSmallIcon(R.drawable.ic_stat_fit)
            .setContentTitle("brandme Fit 화면 캡처 활성화")
            .setContentText("버튼을 누를 때만 현재 화면을 분석해요. 원본 이미지는 저장하지 않아요.")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "캡처 중지", stop).build())
            .build()
    }

    companion object {
        private const val TAG = "MediaProjectionService"
        const val ACTION_START = "com.brandme.fit.capture.START"
        const val ACTION_STOP = "com.brandme.fit.capture.STOP"
        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_RESULT_DATA = "result_data"
        private const val NOTIFICATION_ID = 2002

        fun startIntent(context: Context, resultCode: Int, data: Intent): Intent =
            Intent(context, MediaProjectionService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_RESULT_DATA, data)

        fun stop(context: Context) {
            context.stopService(Intent(context, MediaProjectionService::class.java))
        }
    }
}
