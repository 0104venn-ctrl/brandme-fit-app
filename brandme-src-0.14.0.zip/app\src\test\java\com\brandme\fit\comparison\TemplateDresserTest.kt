package com.brandme.fit.comparison

import com.brandme.fit.body3d.ClothesLibrary
import com.brandme.fit.body3d.HeatLevel
import com.brandme.fit.body3d.HumanBodyModel
import com.brandme.fit.body3d.MannequinDims
import com.brandme.fit.body3d.TemplateDresser
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.model.BodyShapeBase
import com.brandme.fit.data.model.Measurements
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** 실제 옷 틀(MakeHuman CC0 Shirts 01)을 몸에 입히고 사이즈표 수치에 맞추는지 확인 */
class TemplateDresserTest {
    private val dir by lazy { listOf(File("src/main/assets/body"), File("app/src/main/assets/body")).first { it.exists() } }
    private val model by lazy { HumanBodyModel.load(File(dir, "body_model.bin").readBytes(), File(dir, "body_model.json").readText()) }
    private val lib by lazy { ClothesLibrary.load(File(dir, "clothes_model.bin").readBytes()) }
    private val dims = MannequinDims.from(BodyProfile(heightCm = 176.0, shoulderCm = 42.0, chestCm = 96.0, waistCm = 82.0, hipCm = 95.0, armCm = 58.0))
    private val body by lazy { model.build(dims) }

    private fun torsoGirthNear(m: com.brandme.fit.body3d.Mesh, y: Double): Double {
        val pts = (0 until m.vertexCount).filter { kotlin.math.abs(m.positions[it * 3 + 1] - y) < 1.5 && kotlin.math.abs(m.positions[it * 3]) < 22 }
            .map { m.positions[it * 3] to m.positions[it * 3 + 2] }
        return com.brandme.fit.body3d.GarmentFitter.hullPerimeter(pts)
    }

    @Test fun `library has tee and sweater templates`() {
        assertNotNull(lib.pick(BodyShapeBase.MALE, shortSleeve = true))
        assertNotNull(lib.pick(BodyShapeBase.FEMALE, shortSleeve = true))
        assertEquals("sweater", lib.pick(BodyShapeBase.MALE, shortSleeve = false)!!.name)
    }

    @Test fun `bigger chest size makes a wider garment`() {
        val tpl = lib.pick(BodyShapeBase.MALE, true)!!
        val small = TemplateDresser.dress(body, dims, Measurements(chestFlatCm = 50.0, lengthCm = 68.0, sleeveCm = 20.0, shoulderCm = 44.0), tpl)
        val big = TemplateDresser.dress(body, dims, Measurements(chestFlatCm = 62.0, lengthCm = 68.0, sleeveCm = 20.0, shoulderCm = 50.0), tpl)
        val y = 0.69 * 176
        assertTrue(torsoGirthNear(big.mesh, y) > torsoGirthNear(small.mesh, y) + 15)
        // 목표 둘레(가슴 단면 × 2)에 가깝게
        assertEquals(124.0, torsoGirthNear(big.mesh, y), 10.0)
    }

    @Test fun `length follows the size chart`() {
        val tpl = lib.pick(BodyShapeBase.MALE, true)!!
        val short = TemplateDresser.dress(body, dims, Measurements(chestFlatCm = 55.0, lengthCm = 55.0, sleeveCm = 20.0), tpl)
        val long = TemplateDresser.dress(body, dims, Measurements(chestFlatCm = 55.0, lengthCm = 66.0, sleeveCm = 20.0), tpl)
        val minShort = (0 until short.mesh.vertexCount).minOf { short.mesh.positions[it * 3 + 1] }
        val minLong = (0 until long.mesh.vertexCount).minOf { long.mesh.positions[it * 3 + 1] }
        assertEquals(0.835 * 176 - 55, minShort.toDouble(), 3.0)
        assertTrue(minLong < minShort - 8)
    }

    @Test fun `too small chest is shown as tight`() {
        val tpl = lib.pick(BodyShapeBase.MALE, true)!!
        val g = TemplateDresser.dress(body, dims, Measurements(chestFlatCm = 42.0, lengthCm = 62.0, sleeveCm = 18.0, shoulderCm = 38.0), tpl)
        val r = ((HeatLevel.TIGHT.rgb shr 16) and 0xFF) / 255f
        val tight = (0 until g.mesh.vertexCount).count { kotlin.math.abs(g.heatColors[it * 3] - r) < 0.01f }
        assertTrue(tight > g.mesh.vertexCount * 0.3)
    }
}
