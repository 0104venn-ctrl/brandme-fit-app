package com.brandme.fit.data.model

/** 한 사이즈의 비교 결과. diff = 상품 − 기준 옷 (cm). */
data class SizeComparison(
    val sizeLabel: String,
    val diffs: Map<MeasureItem, Double>,
    val comparedItems: Set<MeasureItem>,
    /** 비교 항목 절대 차이의 평균. 비교 항목이 없으면 null. 낮을수록 가깝다. */
    val score: Double?,
)

enum class ComparisonWarning(val message: String) {
    SINGLE_ITEM("비교할 수 있는 항목이 1개뿐이라 참고용으로만 보세요."),
    MIXED_ITEM_SETS("사이즈마다 제공된 항목이 달라, 항목 구성이 다른 사이즈는 순위에서 제외했어요."),
    CHEST_METHOD_MISMATCH("이 사이즈표는 가슴 둘레 기준이라 기준 옷의 가슴 단면과 비교하지 않았어요."),
    REFERENCE_ITEM_MISSING_IN_CHART("기준 옷에 있는 일부 항목이 사이즈표에 없어 비교에서 빠졌어요."),
    DEMO_DATA("Demo 데이터 기준 결과입니다. 실제 상품 정보가 아닙니다."),
    UNVERIFIED_DATA("화면에서 읽은 미검증 값입니다. 상품 페이지의 표와 한 번 더 확인하세요."),
    PRODUCT_NOT_CONFIRMED("상품을 확정하지 못해, 화면에 보이는 사이즈표 기준으로만 비교했어요."),
}

enum class ComparisonError(val message: String) {
    REFERENCE_INCOMPLETE("기준 옷의 실측값이 부족하거나 잘못되었어요."),
    NO_SIZES("사이즈표에 사이즈가 없어요."),
    NO_COMPARABLE_ITEMS("기준 옷과 사이즈표에 공통으로 있는 항목이 없어 비교할 수 없어요."),
    INVALID_CHART_VALUES("사이즈표에 비정상 값(0, 음수, 범위 밖)이 있어 비교하지 않았어요."),
    DUPLICATE_SIZE_LABELS("사이즈표에 같은 사이즈가 중복되어 있어요."),
    UNIT_NOT_CM("cm 단위가 아닌 사이즈표는 비교하지 않아요."),
}

data class ComparisonResult(
    val algorithmVersion: String,
    val referenceName: String,
    val source: SizeChartSource?,
    val verification: VerificationStatus?,
    /** 가장 가까운 사이즈. 동점이면 여러 개. 오류면 비어 있다. */
    val closestSizes: List<String>,
    /** 같은 항목 구성으로 계산되어 서로 순위를 매길 수 있는 사이즈 (score 오름차순) */
    val rankedSizes: List<SizeComparison>,
    /** 항목 구성이 달라 순위에서 제외된 사이즈 */
    val unrankedSizes: List<SizeComparison>,
    val comparedItems: Set<MeasureItem>,
    val warnings: List<ComparisonWarning>,
    val error: ComparisonError?,
    val createdAt: Long,
) {
    val isSuccess: Boolean get() = error == null && closestSizes.isNotEmpty()

    fun withExtraWarning(w: ComparisonWarning): ComparisonResult =
        if (w in warnings) this else copy(warnings = listOf(w) + warnings)
}
