package com.brandme.fit.capture

import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * 시스템 화면 캡처 동의 창을 띄우기 위한 투명 Activity.
 * 서비스는 직접 동의 결과를 받을 수 없어서 이 Activity 가 대신 받는다.
 * 캡처 목적 설명은 오버레이(동의 전 안내 카드)에서 먼저 보여 준다.
 */
class CaptureConsentActivity : ComponentActivity() {

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == RESULT_OK && data != null) {
            // 동의 결과는 바로 서비스로 넘기고 여기서 보관하지 않는다.
            startForegroundService(MediaProjectionService.startIntent(this, res.resultCode, data))
        } else {
            CaptureCoordinator.onConsentDenied()
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            CaptureCoordinator.onAwaitingConsent()
            val mpm = getSystemService(MediaProjectionManager::class.java)
            try {
                launcher.launch(mpm.createScreenCaptureIntent())
            } catch (e: Exception) {
                CaptureCoordinator.onConsentDenied()
                finish()
            }
        }
    }
}
