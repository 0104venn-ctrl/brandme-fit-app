package com.brandme.fit.photo

import com.brandme.fit.data.model.BodyItem
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.sqrt

/** 사람 윤곽 마스크(이진) */
class BodyMask(val width: Int, val height: Int, private val data: BooleanArray) {
    operator fun get(x: Int, y: Int): Boolean = x in 0 until width && y in 0 until height && data[y * width + x]

    /**
     * (sx, sy)에서 시작해 이어진 덩어리만 남긴 마스크. 배경에 잘못 잡힌 점·다른 물체를 버린다.
     * 시작점이 몸 밖이면 가까운 몸 픽셀에서 시작한다. 몸을 못 찾으면 null.
     */
    fun component(sx: Int, sy: Int): BodyMask? {
        var seed = -1
        if (this[sx, sy]) seed = sy * width + sx
        else {
            val r = maxOf(width, height) / 20
            loop@ for (d in 1..r) for (dy in -d..d) for (dx in -d..d) {
                if (this[sx + dx, sy + dy]) { seed = (sy + dy) * width + (sx + dx); break@loop }
            }
        }
        if (seed < 0) return null
        val out = BooleanArray(data.size)
        val queue = IntArray(data.size)
        var head = 0; var tail = 0
        out[seed] = true; queue[tail++] = seed
        while (head < tail) {
            val i = queue[head++]
            val x = i % width; val y = i / width
            fun visit(nx: Int, ny: Int) {
                if (nx !in 0 until width || ny !in 0 until height) return
                val j = ny * width + nx
                if (data[j] && !out[j]) { out[j] = true; queue[tail++] = j }
            }
            visit(x - 1, y); visit(x + 1, y); visit(x, y - 1); visit(x, y + 1)
        }
        return BodyMask(width, height, out)
    }

    companion object {
        fun fromProbabilities(width: Int, height: Int, prob: FloatArray, threshold: Float = 0.5f) =
            BodyMask(width, height, BooleanArray(prob.size) { prob[it] >= threshold })
    }
}

data class Pt(val x: Double, val y: Double)

/** 한 장의 사진에서 얻은 것: 윤곽 마스크와 관절 위치(없으면 null) */
data class PhotoObservation(
    val mask: BodyMask,
    val leftShoulder: Pt?, val rightShoulder: Pt?,
    val leftHip: Pt?, val rightHip: Pt?,
    val leftWrist: Pt?, val rightWrist: Pt?,
    val nose: Pt? = null,
    val leftHeel: Pt? = null, val rightHeel: Pt? = null,
    val leftElbow: Pt? = null, val rightElbow: Pt? = null,
)

data class Estimate(val value: Double, val plusMinus: Double)

/** 진단 화면용: 잰 위치(가로선)와 관절 점 */
data class MeasureLine(val label: String, val y: Int, val x0: Int, val x1: Int)

data class PhotoDiagnostic(
    val title: String,
    val mask: BodyMask,
    val top: Int?,
    val bottom: Int?,
    val lines: List<MeasureLine>,
    val points: List<Pt>,
)

data class PhotoEstimateResult(
    val values: Map<BodyItem, Estimate>,
    /** 사용자에게 보여 줄 문제(다시 찍기 안내) */
    val problems: List<String>,
    /** 인식된 윤곽과 잰 위치(사진이 아니라 윤곽 모양만). 결과 화면을 닫으면 버린다. */
    val diagnostics: List<PhotoDiagnostic> = emptyList(),
)

/**
 * 정면·옆면 사진으로 몸 치수를 추정한다. 사진 속 몸 높이를 입력한 키에 맞춰 cm 로 환산한다.
 *  - 몸 높이: 몸통에서 이어진 윤곽 덩어리의 맨 위~맨 아래. 코·발뒤꿈치 관절과 어긋나면 관절 기준으로 고친다.
 *  - 어깨너비: 정면 양 어깨 관절 거리 × [SHOULDER_JOINT_TO_TIP] (관절 중심 → 어깨 끝 뼈)
 *  - 팔길이: 어깨 관절~손목 관절 + [ARM_TIP_OFFSET_CM]
 *  - 가슴·허리·엉덩이 둘레: 정면 너비와 옆면 두께를 타원으로 보고 둘레 계산
 * 근사치이며 결과마다 ± 범위를 함께 준다. 보정값은 인체 측정 평균 비율로 정한 잠정값이다.
 */
object BodyPhotoEstimator {

    /** 어깨 관절 중심 사이 거리 → 어깨 끝 뼈(견봉) 사이 거리 비율(잠정) */
    const val SHOULDER_JOINT_TO_TIP = 1.15
    /** 어깨 끝 뼈는 관절 중심보다 위쪽 바깥에 있어 팔길이가 그만큼 길다(잠정, cm) */
    const val ARM_TIP_OFFSET_CM = 3.0
    /** 팔 반폭 ≈ 키의 2.2%(팔 두께 약 8cm/176cm). 팔이 지나는 자리에서 이만큼을 몸통이 아닌 것으로 잘라낸다 */
    const val ARM_HALF_WIDTH_RATIO = 0.022
    /** 어깨 바깥너비를 잴 높이: 어깨 관절에서 엉덩이까지의 이 비율만큼 아래(삼각근이 가장 튀어나온 곳 근처) */
    const val DELTOID_LEVEL = 0.12

    private fun mid(a: Pt?, b: Pt?): Pt? = when {
        a != null && b != null -> Pt((a.x + b.x) / 2, (a.y + b.y) / 2)
        else -> a ?: b
    }

    /** 몸의 맨 위·맨 아래 행 */
    private fun verticalExtent(m: BodyMask): Pair<Int, Int>? {
        val minRun = maxOf(2, m.width / 200)
        fun rowHas(y: Int): Boolean {
            var run = 0
            for (x in 0 until m.width) { if (m[x, y]) { run++; if (run >= minRun) return true } else run = 0 }
            return false
        }
        val top = (0 until m.height).firstOrNull(::rowHas) ?: return null
        val bottom = (m.height - 1 downTo 0).first(::rowHas)
        return top to bottom
    }

    /** y 행에서 cx 를 포함하는 몸 구간(px). cx 가 몸 밖이면 가까운 몸 구간을 찾는다. */
    fun runSpan(m: BodyMask, y: Int, cx: Int): IntRange? {
        var x0 = cx
        if (!m[x0, y]) {
            val near = (1..m.width / 10).firstOrNull { d -> m[cx - d, y] || m[cx + d, y] } ?: return null
            x0 = if (m[cx - near, y]) cx - near else cx + near
        }
        var l = x0; var r = x0
        while (m[l - 1, y]) l--
        while (m[r + 1, y]) r++
        return l..r
    }

    fun runWidth(m: BodyMask, y: Int, cx: Int): Int? = runSpan(m, y, cx)?.let { it.last - it.first + 1 }

    /** Ramanujan 근사 타원 둘레 */
    fun ellipseCircumference(width: Double, depth: Double): Double {
        val a = width / 2; val b = depth / 2
        return PI * (3 * (a + b) - sqrt((3 * a + b) * (a + 3 * b)))
    }

    private data class Levels(
        val chest: Int, val waist: Int, val hip: Int, val cx: Int, val scale: Double,
        val top: Int, val bottom: Int, val mask: BodyMask,
    )

    private fun levels(o: PhotoObservation, heightCm: Double, label: String, problems: MutableList<String>): Levels? {
        val sh = mid(o.leftShoulder, o.rightShoulder)
        val hp = mid(o.leftHip, o.rightHip)
        if (sh == null || hp == null || hp.y <= sh.y) {
            problems += "$label 사진에서 어깨·골반 위치를 찾지 못했어요. 밝은 곳에서 몸 전체가 보이게 찍어 주세요."
            return null
        }
        // 몸통 가운데에서 이어진 덩어리만 몸으로 본다
        val m = o.mask.component(((sh.x + hp.x) / 2).toInt(), ((sh.y + hp.y) / 2).toInt())
            ?: run { problems += "$label 사진에서 사람을 찾지 못했어요."; return null }
        var (top, bottom) = verticalExtent(m) ?: run { problems += "$label 사진에서 사람을 찾지 못했어요."; return null }
        if (top <= 1 || bottom >= m.height - 2) {
            problems += "$label 사진에서 머리나 발이 잘렸어요. 몸 전체가 가이드 선 안에 들어오게 찍어 주세요."
            return null
        }
        // 관절로 맨 위·아래를 검증: 코 위 머리 높이, 발뒤꿈치 아래 발바닥 높이를 벗어나면 관절 기준으로 고친다
        val heel = listOfNotNull(o.leftHeel, o.rightHeel).maxOfOrNull { it.y }
        val nose = o.nose
        if (heel != null && nose != null && heel > nose.y) {
            val span = heel - nose.y                      // 코~발뒤꿈치 ≈ 키의 약 0.92
            val topExpected = nose.y - span * 0.075
            if (top < topExpected - span * 0.05 || top > topExpected + span * 0.05) top = topExpected.toInt()
            if (bottom > heel + span * 0.04 || bottom < heel - span * 0.02) bottom = (heel + span * 0.01).toInt()
        }
        val hPx = (bottom - top).toDouble()
        if (hPx < m.height * 0.45) {
            problems += "$label 사진에서 몸이 너무 작아요. 가이드 선에 맞게 조금 더 가까이 서 주세요."
            return null
        }
        val torso = hp.y - sh.y
        val cx = ((sh.x + hp.x) / 2).toInt()
        fun y(f: Double) = (sh.y + f * torso).toInt().coerceIn(0, m.height - 1)
        val scale = heightCm / hPx
        val waistY = (y(0.55)..y(0.85)).minByOrNull { runWidth(m, it, cx) ?: Int.MAX_VALUE } ?: y(0.7)
        val hipY = (y(0.95)..y(1.25)).maxByOrNull { runWidth(m, it, cx) ?: 0 } ?: y(1.05)
        return Levels(y(0.28), waistY, hipY, cx, scale, top, bottom, m)
    }

    fun estimate(front: PhotoObservation, side: PhotoObservation, heightCm: Double): PhotoEstimateResult {
        val problems = mutableListOf<String>()
        val out = linkedMapOf<BodyItem, Estimate>()
        val f = levels(front, heightCm, "정면", problems)
        val s = levels(side, heightCm, "옆면", problems)
        /** 정면에서 잰 몸통 구간(팔을 잘라낸 뒤)과 잘라냈는지 */
        val frontSpans = linkedMapOf<String, Pair<IntRange, Boolean>>()
        var deltoidRow: Int? = null

        if (f != null) {
            val ls = front.leftShoulder; val rs = front.rightShoulder
            if (ls != null && rs != null) {
                val shoulderPx = hypot(ls.x - rs.x, ls.y - rs.y)
                out[BodyItem.SHOULDER] = Estimate(shoulderPx * f.scale * SHOULDER_JOINT_TO_TIP, 3.0)
                // 어깨 바깥너비: 어깨 관절 조금 아래(삼각근 높이)에서 양팔 바깥까지 이어진 윤곽 폭
                val deltoidY = (minOf(ls.y, rs.y) + (f.hip - minOf(ls.y, rs.y)) * DELTOID_LEVEL).toInt()
                runSpan(f.mask, deltoidY, f.cx)?.let { span ->
                    val w = (span.last - span.first + 1).toDouble()
                    if (w in shoulderPx * 1.0..shoulderPx * 1.6) {
                        out[BodyItem.SHOULDER_OUTER] = Estimate(w * f.scale, 3.0)
                        frontSpans["어깨 바깥"] = span to false
                        deltoidRow = deltoidY
                    }
                }
                // 팔길이: 양쪽 어깨~손목 거리의 평균
                val arms = listOfNotNull(
                    front.leftWrist?.let { hypot(it.x - ls.x, it.y - ls.y) },
                    front.rightWrist?.let { hypot(it.x - rs.x, it.y - rs.y) },
                )
                if (arms.isNotEmpty()) out[BodyItem.ARM] = Estimate(arms.average() * f.scale + ARM_TIP_OFFSET_CM, 3.0)

                // 팔·손이 몸통에 붙으면 몸통 너비에 섞인다: 어깨→팔꿈치→손목 관절로 팔이 지나는 자리를 알아내 잘라낸다
                val armHalf = (f.bottom - f.top) * ARM_HALF_WIDTH_RATIO
                val armsLines = listOf(
                    listOfNotNull(ls, front.leftElbow, front.leftWrist),
                    listOfNotNull(rs, front.rightElbow, front.rightWrist),
                )
                fun armXAt(line: List<Pt>, y: Int): Double? = line.zipWithNext().firstNotNullOfOrNull { (a, b) ->
                    val lo = minOf(a.y, b.y); val hi = maxOf(a.y, b.y)
                    if (y < lo || y > hi || hi - lo < 1) null else a.x + (b.x - a.x) * (y - a.y) / (b.y - a.y)
                } ?: line.lastOrNull()?.takeIf { y > it.y && y < it.y + armHalf * 4 }?.x // 손목 아래 손
                for ((name, y) in listOf("가슴" to f.chest, "허리" to f.waist, "엉덩이" to f.hip)) {
                    var span = runSpan(f.mask, y, f.cx) ?: continue
                    var cut = false
                    for (line in armsLines) {
                        val ax = armXAt(line, y) ?: continue
                        // 몸통 구간이 팔 중심선을 넘어 이어졌을 때만(=팔이 붙었을 때만) 자른다
                        if (ax < f.cx && span.first <= ax) { span = (ax + armHalf).toInt()..span.last; cut = true }
                        if (ax > f.cx && span.last >= ax) { span = span.first..(ax - armHalf).toInt(); cut = true }
                    }
                    frontSpans[name] = span to cut
                }
                fun frontWidth(name: String, limit: Double): Pair<Double, Boolean>? {
                    val (span, cut) = frontSpans[name] ?: return null
                    val w = (span.last - span.first + 1).toDouble()
                    if (w > shoulderPx * limit || w < shoulderPx * 0.45) return null
                    return w * f.scale to cut
                }
                val chestW = frontWidth("가슴", 1.2)
                val waistW = frontWidth("허리", 1.2)
                val hipW = frontWidth("엉덩이", 1.5)
                if (chestW == null || waistW == null || hipW == null) {
                    problems += "정면 사진에서 몸통 너비를 잴 수 없는 높이가 있었어요. 양팔을 몸에서 비스듬히(약 45°) 벌리고 다시 찍어 주세요."
                }
                if (listOfNotNull(chestW, waistW, hipW).any { it.second }) {
                    problems += "팔이 몸에 붙어 팔 부분을 잘라내고 쟀어요(오차가 커요). 양팔을 비스듬히 벌리고 다시 찍으면 더 정확해요."
                }
                if (s != null) {
                    fun depth(y: Int) = runWidth(s.mask, y, s.cx)?.let { it * s.scale }
                    fun circ(w: Pair<Double, Boolean>?, d: Double?) =
                        if (w != null && d != null && d < w.first * 1.3) Estimate(ellipseCircumference(w.first, d), if (w.second) 7.0 else 5.0) else null
                    circ(chestW, depth(s.chest))?.let { out[BodyItem.CHEST] = it }
                    circ(waistW, depth(s.waist))?.let { out[BodyItem.WAIST] = it }
                    circ(hipW, depth(s.hip))?.let { out[BodyItem.HIP] = it }
                }
            } else {
                problems += "정면 사진에서 양쪽 어깨를 찾지 못했어요."
            }
        }

        fun lines(l: Levels?, spans: Map<String, Pair<IntRange, Boolean>> = emptyMap(), extra: List<Pair<String, Int>> = emptyList()) =
            if (l == null) emptyList() else (extra + listOf("가슴" to l.chest, "허리" to l.waist, "엉덩이" to l.hip))
                .mapNotNull { (name, y) -> (spans[name]?.first ?: runSpan(l.mask, y, l.cx))?.let { MeasureLine(name, y, it.first, it.last) } }
        val diagnostics = listOf(
            PhotoDiagnostic("정면", f?.mask ?: front.mask, f?.top, f?.bottom, lines(f, frontSpans, listOfNotNull(deltoidRow?.let { "어깨 바깥" to it })),
                listOfNotNull(
                    front.leftShoulder, front.rightShoulder, front.leftElbow, front.rightElbow,
                    front.leftHip, front.rightHip, front.leftWrist, front.rightWrist, front.nose,
                )),
            PhotoDiagnostic("옆면", s?.mask ?: side.mask, s?.top, s?.bottom, lines(s),
                listOfNotNull(side.leftShoulder, side.rightShoulder, side.leftHip, side.rightHip, side.nose)),
        )

        // 범위를 벗어난 추정은 버린다(잘못 읽은 것)
        val valid = out.filter { (item, e) -> e.value in item.range }
        if (valid.size < out.size) problems += "일부 값이 정상 범위를 벗어나 버렸어요. 가이드 선에 맞춰 다시 찍어 보세요."
        return PhotoEstimateResult(valid, problems.distinct(), diagnostics)
    }
}
