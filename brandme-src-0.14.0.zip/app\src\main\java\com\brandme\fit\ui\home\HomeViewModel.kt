package com.brandme.fit.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.brandme.fit.AppContainer
import com.brandme.fit.capture.CaptureCoordinator
import com.brandme.fit.capture.ProjectionState
import com.brandme.fit.catalog.CatalogProduct
import com.brandme.fit.data.local.AppSettings
import com.brandme.fit.data.model.BodyProfile
import com.brandme.fit.data.repository.HistoryItem
import com.brandme.fit.recognition.AnalysisMode
import com.brandme.fit.recognition.AnalysisOutcome
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** SCR-04 상태 값 */
enum class HomeStatus(val label: String) {
    READY("준비됨"),
    NEED_OVERLAY("오버레이 권한 필요"),
    NEED_CAPTURE("캡처 승인 필요"),
    CAPTURE_ACTIVE("캡처 활성화"),
    ANALYZING("분석 중"),
    ERROR("오류"),
}

data class HomeUiState(
    val history: List<HistoryItem> = emptyList(),
    val settings: AppSettings = AppSettings(),
    val overlayPermission: Boolean = false,
    val overlayRunning: Boolean = false,
    val projection: ProjectionState = ProjectionState.INACTIVE,
    val analyzing: Boolean = false,
    val lastError: String? = null,
) {
    val status: HomeStatus
        get() = when {
            !overlayPermission -> HomeStatus.NEED_OVERLAY
            analyzing -> HomeStatus.ANALYZING
            lastError != null -> HomeStatus.ERROR
            projection == ProjectionState.ACTIVE -> HomeStatus.CAPTURE_ACTIVE
            overlayRunning -> HomeStatus.NEED_CAPTURE
            else -> HomeStatus.READY
        }
}

class HomeViewModel(private val c: AppContainer) : ViewModel() {
    private val overlayPermission = MutableStateFlow(false)
    val demoOutcome = MutableStateFlow<AnalysisOutcome?>(null)

    val demoProducts: List<CatalogProduct> get() = c.catalog.products

    private val capture = combine(
        CaptureCoordinator.overlayRunning, CaptureCoordinator.projection,
        CaptureCoordinator.analyzing, CaptureCoordinator.lastError,
    ) { running, proj, analyzing, err -> listOf(running, proj, analyzing, err) }

    val state: StateFlow<HomeUiState> = combine(
        c.history.recent, c.settings.settings, overlayPermission, capture,
    ) { h, s, perm, cap ->
        HomeUiState(
            history = h, settings = s, overlayPermission = perm,
            overlayRunning = cap[0] as Boolean, projection = cap[1] as ProjectionState,
            analyzing = cap[2] as Boolean, lastError = cap[3] as String?,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    fun refreshPermission(granted: Boolean) {
        overlayPermission.value = granted
    }

    fun clearError() = CaptureCoordinator.reportError(null)

    fun runDemo(productId: String) {
        viewModelScope.launch {
            val basis = c.fitBasis()
            val outcome = c.pipeline.compareCatalogProduct(productId, basis)
            demoOutcome.value = outcome
            if (basis.isUsable) c.history.record(outcome, basis.displayName)
        }
    }

    fun dismissDemo() {
        demoOutcome.value = null
    }

    // ---- 개인정보/모드 설정
    fun setMode(mode: AnalysisMode) = viewModelScope.launch { c.settings.setMode(mode) }
    fun setAiConsent(v: Boolean) = viewModelScope.launch { c.settings.setAiConsent(v) }
    fun setServerUrl(v: String) = viewModelScope.launch { c.settings.setServerUrl(v) }

    fun deleteHistory() = viewModelScope.launch { c.history.deleteAll() }

    /** 내 몸 치수(홈 카드용) */
    val body: StateFlow<BodyProfile?> = c.body.profile.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun deleteAll(onDone: () -> Unit) = viewModelScope.launch {
        c.history.deleteAll()
        c.garments.deleteAll()
        c.body.clear()
        c.settings.clearAll()
        onDone()
    }
}
