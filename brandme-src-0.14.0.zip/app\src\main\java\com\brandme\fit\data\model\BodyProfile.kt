package com.brandme.fit.data.model

/** 3D 모형의 기본 체형(치수를 입력하지 않은 부위를 평균 비율로 그릴 때만 쓴다). 비교 계산에는 쓰지 않는다. */
enum class BodyShapeBase(val label: String) {
    MALE("남성 체형"),
    FEMALE("여성 체형"),
}

/**
 * 3D 모형 색. 흰색 마네킹과, 밝은 피부부터 어두운 피부까지 10단계.
 * 사람의 피부색 범위를 고르게 나누도록 직접 정한 값이며 특정 인종을 지칭하지 않는다.
 */
enum class SkinTone(val label: String, val rgb: Int) {
    MANNEQUIN("흰색", 0xEDEDF2),
    TONE_1("1", 0xF6EDE4),
    TONE_2("2", 0xF3E7DB),
    TONE_3("3", 0xF7EAD0),
    TONE_4("4", 0xEADABA),
    TONE_5("5", 0xD7BD96),
    TONE_6("6", 0xA07E56),
    TONE_7("7", 0x825C43),
    TONE_8("8", 0x604134),
    TONE_9("9", 0x3A312A),
    TONE_10("10", 0x292420),
}

/** 몸 치수 항목. 범위를 벗어나면 비정상 값으로 거부한다. */
enum class BodyItem(
    val label: String,
    val unit: String,
    val range: ClosedFloatingPointRange<Double>,
    /** 재는 방법 안내 */
    val guide: String,
) {
    HEIGHT("키", "cm", 120.0..220.0, "맨발로 벽에 등을 붙이고 서서 정수리까지 잰 길이"),
    WEIGHT("몸무게", "kg", 30.0..200.0, "3D 모형의 전체 체형을 그릴 때만 참고해요"),
    SHOULDER("어깨너비", "cm", 28.0..65.0, "등 쪽에서 왼쪽 어깨 끝 뼈부터 오른쪽 어깨 끝 뼈까지 직선 거리"),
    SHOULDER_OUTER("어깨 바깥너비", "cm", 32.0..75.0, "팔을 내리고, 어깨 아래 팔 바깥이 가장 튀어나온 곳 양쪽 사이 직선 거리(드롭숄더 옷 비교용)"),
    CHEST("가슴둘레", "cm", 60.0..160.0, "겨드랑이 바로 아래, 가슴의 가장 두꺼운 부분을 수평으로 한 바퀴"),
    WAIST("허리둘레", "cm", 50.0..160.0, "배꼽 위 가장 잘록한 부분을 수평으로 한 바퀴"),
    HIP("엉덩이둘레", "cm", 70.0..170.0, "엉덩이의 가장 튀어나온 부분을 수평으로 한 바퀴"),
    ARM("팔길이", "cm", 40.0..85.0, "팔을 자연스럽게 내리고 어깨 끝 뼈부터 손목 뼈까지"),
}

/**
 * 내 몸 치수. 키만 필수이고 나머지는 선택이다.
 * 사진 추정값은 사용자가 확인·수정한 뒤에만 저장한다(2단계).
 */
data class BodyProfile(
    val heightCm: Double,
    val weightKg: Double? = null,
    val shoulderCm: Double? = null,
    /** 팔 바깥(삼각근)이 가장 튀어나온 곳 사이 너비. 드롭숄더 옷 비교용 */
    val shoulderOuterCm: Double? = null,
    val chestCm: Double? = null,
    val waistCm: Double? = null,
    val hipCm: Double? = null,
    val armCm: Double? = null,
    val shapeBase: BodyShapeBase = BodyShapeBase.MALE,
    val preferredFit: PreferredFit = PreferredFit.REGULAR,
    val skinTone: SkinTone = SkinTone.MANNEQUIN,
    val updatedAt: Long = System.currentTimeMillis(),
) {
    operator fun get(item: BodyItem): Double? = when (item) {
        BodyItem.HEIGHT -> heightCm
        BodyItem.WEIGHT -> weightKg
        BodyItem.SHOULDER -> shoulderCm
        BodyItem.SHOULDER_OUTER -> shoulderOuterCm
        BodyItem.CHEST -> chestCm
        BodyItem.WAIST -> waistCm
        BodyItem.HIP -> hipCm
        BodyItem.ARM -> armCm
    }

    /** 사이즈 비교에 쓸 수 있는 몸 치수가 하나 이상 있는지(어깨·가슴·팔) */
    val isComparable: Boolean get() = shoulderCm != null || chestCm != null || armCm != null
}

object BodyProfileValidator {
    data class Result(val errors: Map<BodyItem, String>, val profile: BodyProfile?) {
        val isValid: Boolean get() = errors.isEmpty() && profile != null
    }

    fun parse(raw: String): Double? = raw.trim().removeSuffix("cm").removeSuffix("kg").trim().replace(',', '.').toDoubleOrNull()

    fun validate(
        inputs: Map<BodyItem, String>,
        shapeBase: BodyShapeBase,
        preferredFit: PreferredFit,
        now: Long = System.currentTimeMillis(),
        skinTone: SkinTone = SkinTone.MANNEQUIN,
    ): Result {
        val errors = linkedMapOf<BodyItem, String>()
        val values = BodyItem.entries.associateWith { item ->
            val text = inputs[item].orEmpty().trim()
            if (text.isEmpty()) {
                if (item == BodyItem.HEIGHT) errors[item] = "키는 꼭 입력해 주세요(3D 모형 크기의 기준)."
                return@associateWith null
            }
            val v = parse(text)
            when {
                v == null || v.isNaN() || v.isInfinite() -> { errors[item] = "숫자로 입력하세요."; null }
                v !in item.range -> {
                    errors[item] = "${item.label} 값이 비정상이에요. ${item.range.start.toInt()}~${item.range.endInclusive.toInt()}${item.unit} 사이로 입력하세요."
                    null
                }
                else -> v
            }
        }
        if (errors.isNotEmpty()) return Result(errors, null)
        return Result(
            emptyMap(),
            BodyProfile(
                heightCm = values[BodyItem.HEIGHT]!!,
                weightKg = values[BodyItem.WEIGHT],
                shoulderCm = values[BodyItem.SHOULDER],
                shoulderOuterCm = values[BodyItem.SHOULDER_OUTER],
                chestCm = values[BodyItem.CHEST],
                waistCm = values[BodyItem.WAIST],
                hipCm = values[BodyItem.HIP],
                armCm = values[BodyItem.ARM],
                shapeBase = shapeBase,
                preferredFit = preferredFit,
                skinTone = skinTone,
                updatedAt = now,
            ),
        )
    }
}
