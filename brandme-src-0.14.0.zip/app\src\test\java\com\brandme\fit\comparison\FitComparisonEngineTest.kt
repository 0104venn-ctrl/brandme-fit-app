package com.brandme.fit.comparison

import com.brandme.fit.data.model.ChestMeasureMethod
import com.brandme.fit.data.model.ComparisonError
import com.brandme.fit.data.model.ComparisonWarning
import com.brandme.fit.data.model.GarmentCategory
import com.brandme.fit.data.model.MeasureItem
import com.brandme.fit.data.model.Measurements
import com.brandme.fit.data.model.ProductSize
import com.brandme.fit.data.model.ReferenceGarment
import com.brandme.fit.data.model.SizeChart
import com.brandme.fit.data.model.SizeChartSource
import com.brandme.fit.data.model.VerificationStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FitComparisonEngineTest {

    private fun ref(shoulder: Double? = 46.0, chest: Double? = 52.0, length: Double? = 70.0, sleeve: Double? = null) =
        ReferenceGarment(name = "기준 티", category = GarmentCategory.SHORT_SLEEVE_TEE,
            measurements = Measurements(shoulder, chest, length, sleeve))

    private fun size(label: String, s: Double? = null, c: Double? = null, l: Double? = null, sl: Double? = null, circ: Double? = null) =
        ProductSize(label, Measurements(s, c, l, sl, circ))

    private fun chart(vararg sizes: ProductSize, verification: VerificationStatus = VerificationStatus.VERIFIED,
                      unit: String = "cm", method: ChestMeasureMethod = ChestMeasureMethod.FLAT) =
        SizeChart(sizes.toList(), unit, SizeChartSource.LOCAL_CATALOG, verification, chestMethod = method)

    @Test fun `diff is product minus reference with positive negative and zero`() {
        val r = FitComparisonEngine.compare(ref(), chart(size("M", s = 48.0, c = 49.0, l = 70.0)))
        val m = r.rankedSizes.single()
        assertEquals(2.0, m.diffs[MeasureItem.SHOULDER]!!, 1e-9)
        assertEquals(-3.0, m.diffs[MeasureItem.CHEST_FLAT]!!, 1e-9)
        assertEquals(0.0, m.diffs[MeasureItem.LENGTH]!!, 1e-9)
        assertEquals((2.0 + 3.0 + 0.0) / 3, m.score!!, 1e-9)
        assertEquals(listOf("M"), r.closestSizes)
        assertEquals("1.0.0", r.algorithmVersion)
        assertNull(r.error)
    }

    @Test fun `lower mean absolute difference is closer`() {
        val r = FitComparisonEngine.compare(ref(), chart(
            size("S", 44.0, 50.0, 68.0), size("M", 46.0, 52.5, 70.0), size("L", 48.0, 55.0, 72.0),
        ))
        assertEquals(listOf("M"), r.closestSizes)
        assertEquals(listOf("M", "S", "L"), r.rankedSizes.map { it.sizeLabel })
    }

    @Test fun `missing items are skipped not treated as zero`() {
        // 기준 옷에 소매 없음, 상품 사이즈에 총장 없음 → 어깨·가슴만 비교
        val r = FitComparisonEngine.compare(ref(sleeve = null), chart(size("M", s = 47.0, c = 53.0, sl = 20.0)))
        assertEquals(setOf(MeasureItem.SHOULDER, MeasureItem.CHEST_FLAT), r.comparedItems)
        assertEquals(1.0, r.rankedSizes.single().score!!, 1e-9)
        assertTrue(ComparisonWarning.REFERENCE_ITEM_MISSING_IN_CHART in r.warnings)
    }

    @Test fun `ties are reported as jointly closest`() {
        val r = FitComparisonEngine.compare(ref(), chart(
            size("M", 45.0, 52.0, 70.0), size("L", 47.0, 52.0, 70.0), size("XL", 50.0, 56.0, 74.0),
        ))
        assertEquals(listOf("M", "L"), r.closestSizes)
    }

    @Test fun `float noise does not break ties`() {
        val r = FitComparisonEngine.compare(ref(46.0, 52.0, 70.0), chart(
            size("M", 46.1, 52.2, 70.0), size("L", 46.2, 52.1, 70.0),
        ))
        assertEquals(listOf("M", "L"), r.closestSizes)
    }

    @Test fun `sizes with different item sets are not ranked against each other`() {
        val r = FitComparisonEngine.compare(ref(), chart(
            size("S", 44.0, 50.0, 68.0),
            size("M", 46.0, 52.0, 70.0),
            size("L", s = 46.0), // 어깨만 → 점수 0 이지만 다른 구성이라 순위 제외
        ))
        assertEquals(listOf("M"), r.closestSizes)
        assertEquals(listOf("L"), r.unrankedSizes.map { it.sizeLabel })
        assertTrue(ComparisonWarning.MIXED_ITEM_SETS in r.warnings)
    }

    @Test fun `no comparable items produces no result`() {
        val r = FitComparisonEngine.compare(ref(shoulder = 46.0, chest = null, length = null), chart(size("M", l = 70.0)))
        assertEquals(ComparisonError.NO_COMPARABLE_ITEMS, r.error)
        assertTrue(r.closestSizes.isEmpty())
        assertFalse(r.isSuccess)
    }

    @Test fun `invalid reference values are rejected`() {
        listOf(0.0, -5.0, Double.NaN, 500.0).forEach { bad ->
            val r = FitComparisonEngine.compare(ref(shoulder = bad), chart(size("M", 46.0, 52.0, 70.0)))
            assertEquals("value $bad", ComparisonError.REFERENCE_INCOMPLETE, r.error)
        }
        val empty = FitComparisonEngine.compare(ref(null, null, null, null), chart(size("M", 46.0)))
        assertEquals(ComparisonError.REFERENCE_INCOMPLETE, empty.error)
    }

    @Test fun `invalid chart data is rejected not skipped`() {
        assertEquals(ComparisonError.INVALID_CHART_VALUES,
            FitComparisonEngine.compare(ref(), chart(size("M", 0.0, 52.0, 70.0))).error)
        assertEquals(ComparisonError.INVALID_CHART_VALUES,
            FitComparisonEngine.compare(ref(), chart(size("M", -46.0, 52.0, 70.0))).error)
        assertEquals(ComparisonError.DUPLICATE_SIZE_LABELS,
            FitComparisonEngine.compare(ref(), chart(size("M", 46.0), size("m", 47.0))).error)
        assertEquals(ComparisonError.NO_SIZES, FitComparisonEngine.compare(ref(), chart()).error)
        assertEquals(ComparisonError.UNIT_NOT_CM,
            FitComparisonEngine.compare(ref(), chart(size("M", 18.0, 21.0, 28.0), unit = "inch")).error)
    }

    @Test fun `chest circumference is never compared with chest flat`() {
        val r = FitComparisonEngine.compare(ref(), chart(
            size("M", s = 46.0, l = 70.0, circ = 104.0), method = ChestMeasureMethod.CIRCUMFERENCE,
        ))
        assertFalse(MeasureItem.CHEST_FLAT in r.comparedItems)
        assertFalse(MeasureItem.CHEST_CIRCUMFERENCE in r.comparedItems)
        assertTrue(ComparisonWarning.CHEST_METHOD_MISMATCH in r.warnings)
        assertFalse(ComparisonWarning.REFERENCE_ITEM_MISSING_IN_CHART in r.warnings)
    }

    @Test fun `single compared item warns`() {
        val r = FitComparisonEngine.compare(ref(shoulder = 46.0, chest = null, length = null), chart(size("M", s = 47.0)))
        assertTrue(ComparisonWarning.SINGLE_ITEM in r.warnings)
    }

    @Test fun `demo and unverified data are flagged and never become verified`() {
        val demo = FitComparisonEngine.compare(ref(), chart(size("M", 46.0, 52.0, 70.0), verification = VerificationStatus.DEMO))
        assertEquals(VerificationStatus.DEMO, demo.verification)
        assertTrue(ComparisonWarning.DEMO_DATA in demo.warnings)
        val ocr = FitComparisonEngine.compare(ref(), chart(size("M", 46.0, 52.0, 70.0), verification = VerificationStatus.UNVERIFIED))
        assertEquals(VerificationStatus.UNVERIFIED, ocr.verification)
        assertTrue(ComparisonWarning.UNVERIFIED_DATA in ocr.warnings)
        val real = FitComparisonEngine.compare(ref(), chart(size("M", 46.0, 52.0, 70.0)))
        assertFalse(ComparisonWarning.DEMO_DATA in real.warnings)
    }

    @Test fun `createdAt is recorded`() {
        val r = FitComparisonEngine.compare(ref(), chart(size("M", 46.0, 52.0, 70.0)), now = 1234L)
        assertEquals(1234L, r.createdAt)
    }
}
