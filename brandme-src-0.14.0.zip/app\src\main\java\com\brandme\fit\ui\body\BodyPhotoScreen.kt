package com.brandme.fit.ui.body

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import java.util.concurrent.atomic.AtomicReference
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.brandme.fit.data.model.BodyItem
import com.brandme.fit.photo.BodyPhotoEstimator
import com.brandme.fit.photo.BodyAnalyzer
import com.brandme.fit.photo.PhotoDiagnostic
import com.brandme.fit.photo.PhotoEstimateResult
import com.brandme.fit.photo.PhotoObservation
import com.brandme.fit.photo.PhotoPose
import com.brandme.fit.photo.LivePoseChecker
import com.brandme.fit.photo.PoseCheck
import com.brandme.fit.photo.PoseGuide
import com.brandme.fit.photo.PoseStatus
import com.brandme.fit.photo.Pt
import java.util.concurrent.Executors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private val GUIDE_GREEN = Color(0xFF22E06B)

/**
 * 정면·옆면 사진으로 몸 치수 추정.
 * 사진은 메모리에서 분석한 뒤 바로 버린다(파일 저장·외부 전송 없음). 결과는 사용자가 확인 후 입력칸에 채운다.
 */
@Composable
fun BodyPhotoScreen(heightCm: Double?, onApply: (Map<BodyItem, Double>) -> Unit, onClose: () -> Unit) {
    val context = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            heightCm == null -> Message(
                "먼저 키를 입력해 주세요",
                "사진 속 몸 길이를 키에 맞춰 cm 로 바꾸기 때문에 키가 필요해요.",
                "돌아가기", onClose,
            )
            !granted -> Message(
                "카메라 권한이 필요해요",
                "정면·옆면 사진을 찍어 기기 안에서만 분석하고 바로 지워요. 사진은 저장하거나 보내지 않아요.",
                "권한 허용", { permLauncher.launch(Manifest.permission.CAMERA) },
                onClose,
            )
            else -> PhotoFlow(heightCm, onApply, onClose)
        }
    }
}

@Composable
private fun Message(title: String, body: String, action: String, onAction: () -> Unit, onClose: (() -> Unit)? = null) {
    Column(
        Modifier.fillMaxSize().safeDrawingPadding().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
    ) {
        Text(title, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(body, color = Color.White.copy(alpha = 0.85f))
        Button(onClick = onAction) { Text(action) }
        if (onClose != null) TextButton(onClick = onClose) { Text("닫기", color = Color.White) }
    }
}

@Composable
private fun PhotoFlow(heightCm: Double, onApply: (Map<BodyItem, Double>) -> Unit, onClose: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var pose by remember { mutableStateOf(PhotoPose.FRONT) }
    var useFront by remember { mutableStateOf(true) }
    var auto by remember { mutableStateOf(true) }
    var timer by remember { mutableStateOf(true) }
    var countdown by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var frontObs by remember { mutableStateOf<PhotoObservation?>(null) }
    var result by remember { mutableStateOf<PhotoEstimateResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf(PoseStatus(false, "자세를 확인하고 있어요")) }
    val anchors = remember { ArrayDeque<Pt>() }
    var okSince by remember { mutableLongStateOf(0L) }

    val previewView = remember { PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }
    val checker = remember { runCatching { LivePoseChecker(context) }.getOrNull() }
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(Unit) { onDispose { analysisExecutor.shutdown(); checker?.close() } }

    // 현재 자세(분석 스레드에서 읽음)
    val poseRef = remember { AtomicReference(PhotoPose.FRONT) }
    LaunchedEffect(pose) { poseRef.set(pose); anchors.clear(); okSince = 0L }

    fun shoot(autoShot: Boolean) {
        if (busy || countdown > 0) return
        scope.launch {
            if (autoShot || timer) {
                for (i in (if (autoShot) 3 else 5) downTo 1) {
                    countdown = i
                    delay(1000)
                    if (autoShot && !status.ok) { countdown = 0; return@launch } // 자세가 흐트러지면 취소
                }
            }
            countdown = 0
            busy = true
            error = null
            try {
                val bitmap = takePicture(imageCapture, context)
                val obs = try {
                    withContext(Dispatchers.Default) { BodyAnalyzer.analyze(context, bitmap) }
                } finally {
                    bitmap.recycle() // 분석 직후 사진을 메모리에서 지운다
                }
                if (pose == PhotoPose.FRONT) {
                    frontObs = obs
                    pose = PhotoPose.SIDE
                } else {
                    val front = frontObs ?: return@launch
                    result = withContext(Dispatchers.Default) { BodyPhotoEstimator.estimate(front, obs, heightCm) }
                    frontObs = null // 분석이 끝나면 윤곽 데이터도 버린다
                }
            } catch (e: Exception) {
                error = "사진을 분석하지 못했어요. 다시 찍어 주세요."
            } finally {
                busy = false
            }
        }
    }

    DisposableEffect(useFront) {
        val future = ProcessCameraProvider.getInstance(context)
        val mainExecutor = ContextCompat.getMainExecutor(context)
        var lastRun = 0L
        val analysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
        analysis.setAnalyzer(analysisExecutor) { image ->
            try {
                val now = System.currentTimeMillis()
                if (checker != null && now - lastRun >= 250) {
                    lastRun = now
                    val frame = image.toUprightBitmap(480)
                    val st = try { checker.check(frame, poseRef.get()) } finally { frame.recycle() }
                    mainExecutor.execute {
                        status = st
                        st.anchor?.let { anchors.addLast(it); while (anchors.size > 4) anchors.removeFirst() }
                        val steady = PoseCheck.isSteady(anchors.toList())
                        if (st.ok && steady) {
                            if (okSince == 0L) okSince = System.currentTimeMillis()
                            if (auto && result == null && System.currentTimeMillis() - okSince > 800) shoot(autoShot = true)
                        } else {
                            okSince = 0L
                        }
                    }
                }
            } finally {
                image.close()
            }
        }
        val listener = Runnable {
            val provider = future.get()
            provider.unbindAll()
            val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
            val selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            runCatching { provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture, analysis) }
                .onFailure {
                    // 일부 기기는 세 가지를 동시에 못 쓴다: 자동 촬영 없이 연다
                    runCatching { provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture) }
                        .onFailure { error = "카메라를 열지 못했어요." }
                    status = PoseStatus(false, "이 기기에서는 자동 촬영을 쓸 수 없어 버튼으로 찍어 주세요")
                }
        }
        future.addListener(listener, mainExecutor)
        onDispose { analysis.clearAnalyzer(); runCatching { future.get().unbindAll() } }
    }

    val r = result
    if (r != null) {
        ResultView(r, onApply = { onApply(r.values.mapValues { it.value.value }) }, onRetake = {
            result = null; pose = PhotoPose.FRONT
        }, onClose = onClose)
        return
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        GuideOverlay(pose, status.ok, Modifier.fillMaxSize())
        Column(
            Modifier.fillMaxWidth().safeDrawingPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${if (pose == PhotoPose.FRONT) 1 else 2}/2 · ${pose.title}", color = GUIDE_GREEN, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Box(Modifier.weight(1f))
                TextButton(onClick = onClose) { Text("닫기", color = Color.White) }
            }
            Text(pose.instruction, color = Color.White, style = MaterialTheme.typography.bodyMedium)
            Text(
                status.message,
                color = if (status.ok) GUIDE_GREEN else Color(0xFFFFD54F),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier.background(Color(0x99000000)).padding(horizontal = 8.dp, vertical = 4.dp),
            )
            error?.let { Text(it, color = Color(0xFFFF8A80), style = MaterialTheme.typography.bodySmall) }
        }
        if (countdown > 0) {
            Text("$countdown", color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center))
        }
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().safeDrawingPadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("자동 촬영", color = Color.White)
                Switch(checked = auto, onCheckedChange = { auto = it })
                if (!auto) {
                    Text("5초 타이머", color = Color.White)
                    Switch(checked = timer, onCheckedChange = { timer = it })
                }
                Box(Modifier.weight(1f))
                OutlinedButton(onClick = { useFront = !useFront }) { Text(if (useFront) "후면" else "전면", color = Color.White) }
            }
            Button(onClick = { shoot(autoShot = false) }, enabled = !busy && countdown == 0, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                when {
                    busy -> CircularProgressIndicator(Modifier.height(20.dp), strokeWidth = 2.dp)
                    auto -> Text("자세가 맞으면 자동으로 찍혀요 · 지금 찍기")
                    else -> Text("${pose.title} 촬영")
                }
            }
        }
    }
}

/** 가이드 선 밖은 어둡게, 선은 녹색으로 */
@Composable
private fun GuideOverlay(pose: PhotoPose, ok: Boolean, modifier: Modifier) {
    Canvas(modifier.graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }) {
        val boxH = size.height * 0.80f
        val boxW = boxH
        val left = (size.width - boxW) / 2
        val top = size.height * 0.13f
        fun at(p: Pair<Double, Double>) = Offset(left + p.first.toFloat() * boxW, top + p.second.toFloat() * boxH)
        val segs = PoseGuide.bezierSegments(PoseGuide.points(pose))
        val path = Path().apply {
            val s0 = at(segs.first()[0]); moveTo(s0.x, s0.y)
            for (s in segs) { val c1 = at(s[1]); val c2 = at(s[2]); val e = at(s[3]); cubicTo(c1.x, c1.y, c2.x, c2.y, e.x, e.y) }
            close()
        }
        drawRect(Color.Black.copy(alpha = 0.62f))
        drawPath(path, Color.Transparent, blendMode = BlendMode.Clear)
        drawPath(path, if (ok) GUIDE_GREEN else Color.White.copy(alpha = 0.85f), style = Stroke(width = 3.dp.toPx()))
    }
}

@Composable
private fun ResultView(r: PhotoEstimateResult, onApply: () -> Unit, onRetake: () -> Unit, onClose: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).safeDrawingPadding()
            .verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("사진으로 잰 치수 (추정)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "사진은 분석 후 바로 지웠어요. 아래 값은 근사치라 줄자로 잰 값과 다를 수 있어요. 채운 뒤 확인하고 저장해 주세요.",
            style = MaterialTheme.typography.bodySmall,
        )
        if (r.values.isEmpty()) Text("잴 수 있는 항목이 없었어요.", fontWeight = FontWeight.Bold)
        r.values.forEach { (item, e) ->
            Row {
                Text(item.label, modifier = Modifier.weight(1f))
                Text("약 ${"%.1f".format(e.value)} ${item.unit}  (±${e.plusMinus.toInt()})", fontWeight = FontWeight.Bold)
            }
        }
        r.problems.forEach { Text("• $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        if (r.diagnostics.isNotEmpty()) {
            Text("인식된 몸 윤곽과 잰 위치", style = MaterialTheme.typography.labelLarge)
            Text(
                "사진이 아니라 윤곽 모양만 보여 줘요. 윤곽이 몸과 다르거나 선이 엉뚱한 곳에 있으면 다시 찍어 주세요.",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                r.diagnostics.forEach { d -> DiagnosticView(d, Modifier.weight(1f).height(320.dp)) }
            }
        }
        Button(onClick = onApply, enabled = r.values.isNotEmpty(), modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("입력칸에 채우기") }
        OutlinedButton(onClick = onRetake, modifier = Modifier.fillMaxWidth()) { Text("다시 찍기") }
        TextButton(onClick = onClose) { Text("닫기") }
    }
}

/** 사진 한 장을 메모리로 받아 올바른 방향의 Bitmap 으로 만든다(긴 변 1600px 이하). 파일로 저장하지 않는다. */
private suspend fun takePicture(capture: ImageCapture, context: android.content.Context): Bitmap =
    suspendCancellableCoroutine { cont ->
        capture.takePicture(
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    try {
                        val raw = image.toBitmap()
                        val rot = image.imageInfo.rotationDegrees
                        val longSide = maxOf(raw.width, raw.height)
                        val s = if (longSide > 1600) 1600f / longSide else 1f
                        val m = Matrix().apply { postScale(s, s); postRotate(rot.toFloat()) }
                        val out = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                        if (out !== raw) raw.recycle()
                        cont.resume(out)
                    } catch (e: Exception) {
                        cont.resumeWithException(e)
                    } finally {
                        image.close()
                    }
                }

                override fun onError(exception: ImageCaptureException) = cont.resumeWithException(exception)
            },
        )
    }

/** 윤곽(흰색) + 몸 맨 위·아래(파랑) + 잰 위치(녹색 가로선) + 관절(주황 점) */
@Composable
private fun DiagnosticView(d: PhotoDiagnostic, modifier: Modifier) {
    val image = remember(d) {
        val step = maxOf(1, d.mask.height / 400)
        val w = d.mask.width / step; val h = d.mask.height / step
        val px = IntArray(w * h) { i -> if (d.mask[(i % w) * step, (i / w) * step]) 0xFFE8E8E8.toInt() else 0xFF202124.toInt() }
        Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888).asImageBitmap()
    }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(d.title, style = MaterialTheme.typography.labelMedium)
        Canvas(Modifier.fillMaxWidth().weight(1f).background(Color(0xFF202124))) {
            val s = minOf(size.width / d.mask.width, size.height / d.mask.height)
            val ox = (size.width - d.mask.width * s) / 2
            val oy = (size.height - d.mask.height * s) / 2
            drawImage(
                image,
                dstOffset = IntOffset(ox.toInt(), oy.toInt()),
                dstSize = IntSize((d.mask.width * s).toInt(), (d.mask.height * s).toInt()),
            )
            fun p(x: Number, y: Number) = Offset(ox + x.toFloat() * s, oy + y.toFloat() * s)
            listOfNotNull(d.top, d.bottom).forEach { y ->
                drawLine(Color(0xFF4FC3F7), p(0, y), p(d.mask.width, y), strokeWidth = 2f)
            }
            d.lines.forEach { l -> drawLine(GUIDE_GREEN, p(l.x0, l.y), p(l.x1, l.y), strokeWidth = 4f) }
            d.points.forEach { pt -> drawCircle(Color(0xFFFFA726), radius = 5f, center = p(pt.x, pt.y)) }
        }
    }
}

/** 미리보기 프레임을 똑바로 세운 작은 Bitmap 으로(긴 변 maxSide 이하) */
private fun ImageProxy.toUprightBitmap(maxSide: Int): Bitmap {
    val raw = toBitmap()
    val s = minOf(1f, maxSide.toFloat() / maxOf(raw.width, raw.height))
    val m = Matrix().apply { postScale(s, s); postRotate(imageInfo.rotationDegrees.toFloat()) }
    val out = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
    if (out !== raw) raw.recycle()
    return out
}
