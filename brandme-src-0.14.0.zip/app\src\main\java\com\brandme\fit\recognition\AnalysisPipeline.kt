package com.brandme.fit.recognition

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import com.brandme.fit.catalog.CatalogProduct
import com.brandme.fit.catalog.DemoCatalog
import com.brandme.fit.comparison.BodyFitEngine
import com.brandme.fit.comparison.FitComparisonEngine
import com.brandme.fit.data.model.ChestMeasureMethod
import com.brandme.fit.data.model.ComparisonWarning
import com.brandme.fit.data.model.DetectedProduct
import com.brandme.fit.data.model.IdentificationStatus
import com.brandme.fit.data.model.ProductCandidate
import com.brandme.fit.data.model.ReferenceGarment
import com.brandme.fit.data.model.SizeChart
import com.brandme.fit.data.model.SizeChartSource
import com.brandme.fit.data.model.VerificationStatus
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import retrofit2.HttpException
import java.io.IOException
import kotlin.math.abs

/**
 * 상품 인식 → 사이즈표 확보 → 비교 파이프라인.
 *
 * 사이즈표 우선순위: 1) 로컬 카탈로그(정확 일치만) 2) 현재 화면에 보이는 표 3) (AI Mode) 서버 추출 결과.
 * 어떤 경로든 사이즈 값을 만들어 내지 않는다. 표가 없으면 실패를 그대로 돌려준다.
 * 비교는 항상 기기에서 FitComparisonEngine 으로 수행한다.
 */
class AnalysisPipeline(
    private val catalog: DemoCatalog,
    private val textReader: ScreenTextReader,
    private val remoteFactory: (String) -> RemoteAnalyzer = { RemoteAnalyzer(it) },
) {
    private val matcher = ProductMatcher(catalog.products)

    data class Options(
        val mode: AnalysisMode,
        val aiConsent: Boolean,
        val serverUrl: String,
    )

    /** bitmap 은 호출자가 소유/해제한다. 여기서는 보관하지 않는다. */
    suspend fun analyze(
        bitmap: Bitmap,
        reference: FitBasis,
        options: Options,
        onStage: (AnalysisStage) -> Unit,
    ): AnalysisOutcome {
        if (!reference.isUsable) return AnalysisOutcome.Failure(AnalysisError.REFERENCE_INCOMPLETE)
        if (options.mode == AnalysisMode.AI && !options.aiConsent) return AnalysisOutcome.Failure(AnalysisError.AI_CONSENT_REQUIRED)

        onStage(AnalysisStage.RECOGNIZING)
        val screen = textReader.read(bitmap)
        // 외부로 보내기 전에 기기 안에서 민감 화면을 먼저 걸러낸다.
        if (SensitiveScreenDetector.isSensitive(screen.fullText)) return AnalysisOutcome.Failure(AnalysisError.SENSITIVE_SCREEN)

        var local = analyzeText(screen, reference, onStage)
        if (local is AnalysisOutcome.Failure && local.error == AnalysisError.SIZE_CHART_UNREADABLE) {
            local = retryZoomed(bitmap, screen, reference, local)
        }
        if (options.mode == AnalysisMode.DEMO) return local
        // AI Mode: 로컬 카탈로그 정확 일치가 있으면 그것을 우선 사용한다.
        if (local is AnalysisOutcome.Success && local.chart.source == SizeChartSource.LOCAL_CATALOG) return local

        onStage(AnalysisStage.FINDING_SIZE_CHART)
        val response = try {
            remoteFactory(options.serverUrl).analyze(bitmap)
        } catch (e: HttpException) {
            return AnalysisOutcome.Failure(AnalysisError.API_CONNECTION_FAILED, detail = "HTTP ${e.code()}")
        } catch (e: IOException) {
            return AnalysisOutcome.Failure(AnalysisError.API_CONNECTION_FAILED, detail = e.javaClass.simpleName)
        } catch (e: kotlinx.serialization.SerializationException) {
            return AnalysisOutcome.Failure(AnalysisError.API_CONNECTION_FAILED, detail = "응답 형식 오류")
        }
        onStage(AnalysisStage.COMPARING)
        return mapRemote(response, reference)
    }

    /**
     * 표 헤더는 찾았지만 값을 못 읽은 경우: 표 영역만 잘라 확대한 뒤 한 번 더 OCR 한다.
     * 확대본은 메모리에서만 쓰고 바로 해제한다. 다시 읽어도 실패하면 그 실패를 그대로 돌려준다.
     */
    private suspend fun retryZoomed(
        bitmap: Bitmap,
        screen: ScreenText,
        reference: FitBasis,
        first: AnalysisOutcome.Failure,
    ): AnalysisOutcome {
        fun note(text: String) = first.copy(screenRows = first.screenRows.orEmpty() + "--- $text ---")
        val region = TableRegion.find(screen, bitmap.width, bitmap.height)
            ?: return note("확대 재인식 안 함: 표 영역을 못 찾았거나 글자가 이미 큼 (화면 ${bitmap.width}x${bitmap.height})")
        val info = "영역 ${region.width}x${region.height} ×%.1f".format(region.scale)
        val zoomed = readEnlarged(bitmap, region.left, region.top, region.right, region.bottom, region.scale)
        val zoomedOutcome = if (zoomed.lines.isEmpty()) null else analyzeText(zoomed, reference)
        if (zoomedOutcome != null && zoomedOutcome !is AnalysisOutcome.Failure) return zoomedOutcome
        val debug = first.screenRows.orEmpty() + "--- 1) 표 영역 확대 후 다시 읽음 ($info) ---" +
            ((zoomedOutcome as? AnalysisOutcome.Failure)?.screenRows ?: listOf("(글자 없음)"))

        // 2) 칸별로 나눠 다시 읽기
        val columns = TableColumns.columns(region.header, region.left, region.right)
        val bodyTop = region.header.maxOf { it.bottom } + 2
        if (columns.size < 3 || bodyTop >= region.bottom) {
            return first.copy(detail = "확대 후에도 ${first.detail}", screenRows = debug + "--- 2) 칸별 읽기 안 함 (칸 ${columns.size}개) ---")
        }
        val cells = columns.map { c ->
            readEnlarged(bitmap, c.left, bodyTop, c.right, region.bottom, region.scale).lines.map { l ->
                // 원본 좌표로 되돌린다
                TextLine(
                    l.text,
                    c.left + (l.left / region.scale).toInt(), bodyTop + (l.top / region.scale).toInt(),
                    c.left + (l.right / region.scale).toInt(), bodyTop + (l.bottom / region.scale).toInt(),
                )
            }
        }
        val assembled = TableColumns.assemble(columns, cells)
        val columnDebug = debug + "--- 2) 칸별로 다시 읽음 (칸 ${columns.size}개, 라벨 없는 값 ${assembled.orphanCells}개) ---" + assembled.rows
        if (assembled.orphanCells > 0) {
            // 일부 행의 사이즈 라벨을 못 읽었다. 남은 행만으로 결과를 내면 사이즈가 빠진 결과가 되므로 실패로 둔다.
            return first.copy(detail = "확대·칸별 읽기 후에도 사이즈 라벨을 읽지 못한 행이 있음", screenRows = columnDebug)
        }
        val outcome = analyzeRows(screen, assembled.rows, reference, {})
        return when (outcome) {
            is AnalysisOutcome.Failure ->
                outcome.copy(detail = outcome.detail?.let { "확대·칸별 읽기 후에도 $it" }, screenRows = columnDebug)
            is AnalysisOutcome.Success -> outcome.copy(screenRows = columnDebug)
            else -> outcome
        }
    }

    /**
     * 원본의 일부를 잘라 확대·흑백·대비 강화한 뒤 OCR 한다. 좌표는 확대본 기준으로 돌려준다.
     * 확대본은 메모리에서만 쓰고 바로 해제한다.
     */
    private suspend fun readEnlarged(bitmap: Bitmap, left: Int, top: Int, right: Int, bottom: Int, scale: Float): ScreenText {
        val l = left.coerceIn(0, bitmap.width - 1)
        val t = top.coerceIn(0, bitmap.height - 1)
        val w = (right.coerceAtMost(bitmap.width) - l).coerceAtLeast(1)
        val h = (bottom.coerceAtMost(bitmap.height) - t).coerceAtLeast(1)
        val out = Bitmap.createBitmap((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        Canvas(out).apply {
            drawColor(Color.WHITE)
            scale(scale, scale)
            drawBitmap(bitmap, Rect(l, t, l + w, t + h), Rect(0, 0, w, h), ENHANCE_PAINT)
        }
        try {
            return textReader.read(out)
        } finally {
            // 취소된 경우 OCR 이 아직 읽고 있을 수 있으므로 해제하지 않고 참조만 놓는다(GC 가 회수).
            if (currentCoroutineContext().isActive) out.recycle()
        }
    }

    /** 기준 옷만으로 비교(테스트·이전 호출 호환) */
    fun analyzeText(screen: ScreenText, reference: ReferenceGarment, onStage: (AnalysisStage) -> Unit = {}): AnalysisOutcome =
        analyzeText(screen, FitBasis(reference, null), onStage)

    /** Demo Mode 의 핵심 로직 (Bitmap 없이 테스트 가능) */
    fun analyzeText(
        screen: ScreenText,
        reference: FitBasis,
        onStage: (AnalysisStage) -> Unit = {},
    ): AnalysisOutcome {
        if (screen.lines.isEmpty()) return AnalysisOutcome.Failure(AnalysisError.NO_PRODUCT_NO_CHART)
        // 1순위: 숫자로 표를 만들고 이름을 붙이는 방식(NumberGrid). 숫자 표가 있으면 그 판단을 그대로 쓴다.
        // 숫자 표가 없을 때만 글자 기반 파서(한 줄형 "M : 어깨 46 / 가슴 52" 등)로 넘어간다.
        val grid = NumberGrid.read(screen.lines)
        val rows = TableGrid.rows(screen.lines) ?: screen.rows()
        // 단어 위치(OCR element)가 없으면 칸 위치가 추정치라, 숫자 표가 "읽지 못함"이라 해도 글자 파서에 기회를 준다.
        val hasWordBoxes = screen.lines.any { it.words.isNotEmpty() }
        val gridChart = grid?.result?.takeIf { it is SizeChartTextParser.Result.Found || hasWordBoxes }
        val outcome = analyzeRows(screen, rows, reference, onStage, gridChart)
        val debugRows = rows + (grid?.let { listOf("--- 숫자로 재구성한 표 ---") + it.debug } ?: emptyList())
        return when (outcome) {
            is AnalysisOutcome.Failure -> outcome.copy(screenRows = debugRows)
            is AnalysisOutcome.Success -> outcome.copy(screenRows = debugRows)
            else -> outcome
        }
    }

    private fun analyzeRows(
        screen: ScreenText,
        rows: List<String>,
        reference: FitBasis,
        onStage: (AnalysisStage) -> Unit,
        chartFromGrid: SizeChartTextParser.Result? = null,
    ): AnalysisOutcome {
        val match = matcher.match(screen.fullText)

        onStage(AnalysisStage.FINDING_SIZE_CHART)
        val screenChart = chartFromGrid ?: SizeChartTextParser.parse(rows)

        if (match.status == IdentificationStatus.EXACT_MATCH && match.product != null) {
            val catalogChart = match.product.toSizeChart()
            if (screenChart is SizeChartTextParser.Result.Found && conflicts(catalogChart, screenChart.chart)) {
                return AnalysisOutcome.Failure(AnalysisError.CONFLICTING_VALUES, match.toDetected(), "카탈로그와 화면의 표가 다름")
            }
            onStage(AnalysisStage.COMPARING)
            return compare(match.toDetected(), catalogChart, reference)
        }

        val detected = match.toDetected()
        return when (screenChart) {
            is SizeChartTextParser.Result.Found -> {
                onStage(AnalysisStage.COMPARING)
                compare(detected, screenChart.chart, reference, ComparisonWarning.PRODUCT_NOT_CONFIRMED)
            }
            is SizeChartTextParser.Result.Conflicting ->
                AnalysisOutcome.Failure(AnalysisError.CONFLICTING_VALUES, detected, "${screenChart.sizeLabel} 사이즈 값 충돌")
            is SizeChartTextParser.Result.Unreadable ->
                AnalysisOutcome.Failure(AnalysisError.SIZE_CHART_UNREADABLE, detected, screenChart.reason)
            SizeChartTextParser.Result.NotFound -> when (match.status) {
                IdentificationStatus.CANDIDATE_MATCH, IdentificationStatus.AMBIGUOUS ->
                    AnalysisOutcome.NeedsCandidateChoice(detected)
                else -> AnalysisOutcome.Failure(AnalysisError.NO_PRODUCT_NO_CHART, detected)
            }
        }
    }

    /** 사용자가 후보 목록에서 직접 고른 카탈로그 상품으로 비교 */
    fun compareChosenCandidate(candidateId: String, reference: FitBasis): AnalysisOutcome {
        if (!reference.isUsable) return AnalysisOutcome.Failure(AnalysisError.REFERENCE_INCOMPLETE)
        val p = catalog.byId(candidateId) ?: return AnalysisOutcome.Failure(AnalysisError.PRODUCT_NOT_IDENTIFIED)
        return compare(p.toDetected(IdentificationStatus.CANDIDATE_MATCH, userConfirmed = true), p.toSizeChart(), reference)
    }

    /** 홈 화면의 "Demo 체험" — 캡처 없이 카탈로그 상품으로 흐름을 보여 준다(결과는 Demo 로 표시). */
    fun compareCatalogProduct(productId: String, reference: FitBasis): AnalysisOutcome {
        if (!reference.isUsable) return AnalysisOutcome.Failure(AnalysisError.REFERENCE_INCOMPLETE)
        val p = catalog.byId(productId) ?: return AnalysisOutcome.Failure(AnalysisError.PRODUCT_NOT_IDENTIFIED)
        return compare(p.toDetected(IdentificationStatus.EXACT_MATCH), p.toSizeChart(), reference)
    }

    fun mapRemote(r: AnalyzeScreenResponse, reference: FitBasis): AnalysisOutcome {
        val status = runCatching { IdentificationStatus.valueOf(r.status) }.getOrDefault(IdentificationStatus.NOT_FOUND)
        val detected = DetectedProduct(
            brand = r.product?.brand, name = r.product?.name, shop = r.product?.shop,
            productCode = r.product?.productCode, status = status,
            candidates = r.candidates.mapIndexed { i, c ->
                ProductCandidate("remote-$i", c.brand.orEmpty(), c.name.orEmpty(), c.shop, c.score ?: 0.0)
            },
        )
        val charts = r.sizeChartCandidates.map { rc ->
            SizeChart(
                sizes = rc.sizes.map { it.toProductSize() },
                unit = rc.unit,
                source = SizeChartSource.AI_SERVER,
                verification = VerificationStatus.UNVERIFIED,
                sourceDetail = rc.evidence ?: "AI 서버가 현재 화면에서 추출",
                chestMethod = runCatching { ChestMeasureMethod.valueOf(rc.chestMethod) }.getOrDefault(ChestMeasureMethod.UNKNOWN),
            )
        }
        val distinct = charts.distinctBy { c -> c.sizes.map { it.label.uppercase() to it.measurements } }
        return when {
            distinct.size > 1 -> AnalysisOutcome.Failure(AnalysisError.CONFLICTING_VALUES, detected, "서버가 서로 다른 표 ${distinct.size}개를 반환")
            distinct.size == 1 -> compare(
                detected, distinct.single(), reference,
                if (status == IdentificationStatus.EXACT_MATCH) null else ComparisonWarning.PRODUCT_NOT_CONFIRMED,
            )
            r.failureReason == "SIZE_CHART_UNREADABLE" -> AnalysisOutcome.Failure(AnalysisError.SIZE_CHART_UNREADABLE, detected)
            status == IdentificationStatus.EXACT_MATCH || status == IdentificationStatus.CANDIDATE_MATCH ->
                AnalysisOutcome.Failure(AnalysisError.SIZE_CHART_NOT_FOUND, detected, r.failureReason)
            status == IdentificationStatus.AMBIGUOUS -> AnalysisOutcome.Failure(AnalysisError.MULTIPLE_CANDIDATES, detected, r.failureReason)
            else -> AnalysisOutcome.Failure(AnalysisError.PRODUCT_NOT_IDENTIFIED, detected, r.failureReason)
        }
    }

    private fun compare(
        product: DetectedProduct,
        chart: SizeChart,
        reference: FitBasis,
        extraWarning: ComparisonWarning? = null,
    ): AnalysisOutcome {
        // 기준 옷 비교와 몸 기준 비교를 각각 할 수 있는 만큼 한다. 둘 다 못 하면 비교 불가.
        var result = reference.garment?.takeIf { it.isComparable }?.let { FitComparisonEngine.compare(it, chart) }
        val bodyFit = reference.body?.takeIf { it.isComparable }?.let { BodyFitEngine.evaluate(it, chart) }
        val garmentError = result?.error
        if (garmentError != null) result = null
        // 몸 기준 추천을 못 정해도(가슴·어깨 치수 없음 등) 사이즈표와 3D 입혀 보기는 보여 준다
        if (result == null && bodyFit == null) {
            val reason = garmentError?.message
            return AnalysisOutcome.Failure(AnalysisError.COMPARISON_IMPOSSIBLE, product, reason)
        }
        if (extraWarning != null) result = result?.withExtraWarning(extraWarning)
        return AnalysisOutcome.Success(product, chart, result, bodyFit, reference.body)
    }

    /** 같은 라벨인데 값이 0.5cm 넘게 다르면 충돌 */
    private fun conflicts(a: SizeChart, b: SizeChart): Boolean {
        val bMap = b.sizes.associateBy { it.label.uppercase() }
        return a.sizes.any { sa ->
            val sb = bMap[sa.label.uppercase()] ?: return@any false
            com.brandme.fit.data.model.MeasureItem.entries.any { item ->
                val x = sa.measurements[item]; val y = sb.measurements[item]
                x != null && y != null && abs(x - y) > 0.5
            }
        }
    }
}

private fun CatalogProduct.toDetected(status: IdentificationStatus, userConfirmed: Boolean = false) = DetectedProduct(
    id = id, brand = brand, name = name, shop = shop, productCode = productCode,
    status = status, isDemo = isDemo, userConfirmed = userConfirmed,
)

/** 흑백 + 대비 강화. 회색 작은 글씨가 배경과 더 잘 구분되도록 한다. */
private val ENHANCE_PAINT by lazy { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
    val contrast = 1.6f
    val shift = (1f - contrast) * 128f
    val gray = ColorMatrix().apply { setSaturation(0f) }
    gray.postConcat(
        ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, shift,
                0f, contrast, 0f, 0f, shift,
                0f, 0f, contrast, 0f, shift,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
    colorFilter = ColorMatrixColorFilter(gray)
} }
