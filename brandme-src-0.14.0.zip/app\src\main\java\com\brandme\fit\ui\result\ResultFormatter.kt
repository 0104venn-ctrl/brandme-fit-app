package com.brandme.fit.ui.result

import com.brandme.fit.comparison.BodyFitResult
import com.brandme.fit.data.model.ComparisonResult
import com.brandme.fit.recognition.AnalysisOutcome
import com.brandme.fit.data.model.MeasureItem
import com.brandme.fit.data.model.SizeComparison
import kotlin.math.abs

/**
 * 결과 문구. 실측 차이만 사실대로 말한다.
 * "완벽하게 맞습니다", "정확도 99%", "무조건 M" 같은 단정/보장 표현은 쓰지 않는다.
 */
object ResultFormatter {
    const val DISCLAIMER = "실측 비교 결과이며 실제 착용감이나 사이즈 적합도를 보장하지 않습니다."

    /** 테스트에서 금지 문구 검사에 쓴다 */
    val FORBIDDEN_PHRASES = listOf("완벽하게 맞", "정확도", "무조건", "딱 맞", "100%", "보장합니다")

    fun bodySentence(fit: BodyFitResult): String = when {
        !fit.isSuccess -> "추천 사이즈를 정하지 못했어요. 아래에서 사이즈별로 입혀 볼 수 있어요."
        fit.recommended.size == 1 -> "${withRo(fit.preferredFit.label)} 입기에 가장 가까운 사이즈는 ${fit.recommended.single()}입니다."
        else -> "${withRo(fit.preferredFit.label)} 입기에 가장 가까운 사이즈는 ${fit.recommended.joinToString(", ")}입니다(차이가 같음)."
    }

    /** "정핏으로", "세미오버로" — 받침(ㄹ 제외)이 있으면 "으로" */
    private fun withRo(word: String): String {
        val ch = word.lastOrNull() ?: return word
        val jong = if (ch in '가'..'힣') (ch - '가') % 28 else 0
        return word + if (jong != 0 && jong != 8) "으로" else "로"
    }

    /** 기록용 한 줄 요약 */
    fun summary(outcome: AnalysisOutcome.Success): String =
        outcome.bodyFit?.let { bodySentence(it) } ?: outcome.result?.let { closestSentence(it) } ?: "비교 결과가 없습니다."

    fun closestSentence(result: ComparisonResult): String = when {
        !result.isSuccess -> "비교 결과가 없습니다."
        result.closestSizes.size == 1 ->
            "기준 옷과 실측이 가장 가까운 사이즈는 ${result.closestSizes.single()}입니다."
        else ->
            "기준 옷과 실측이 가장 가까운 사이즈는 ${result.closestSizes.joinToString(", ")}입니다(차이가 같음)."
    }

    /** 예: "어깨는 2cm 넓고 가슴 단면은 3cm 넓습니다." */
    fun diffSentence(size: SizeComparison): String {
        val parts = ORDER.filter { it in size.diffs }.map { item -> phrase(item, size.diffs.getValue(item)) }
        if (parts.isEmpty()) return "비교할 수 있는 항목이 없습니다."
        val joined = parts.mapIndexed { i, p ->
            if (i == parts.lastIndex) p.final else p.connective
        }.joinToString(" ")
        return "$joined."
    }

    fun diffLabel(item: MeasureItem, diff: Double): String = when {
        abs(diff) < 0.05 -> "같음"
        diff > 0 -> "+${cm(diff)}cm"
        else -> "-${cm(abs(diff))}cm"
    }

    fun cm(v: Double): String {
        val r = Math.round(v * 10) / 10.0
        return if (r == Math.floor(r)) r.toLong().toString() else r.toString()
    }

    private val ORDER = listOf(MeasureItem.SHOULDER, MeasureItem.CHEST_FLAT, MeasureItem.LENGTH, MeasureItem.SLEEVE)

    private data class Phrase(val connective: String, val final: String)

    private fun phrase(item: MeasureItem, diff: Double): Phrase {
        val subject = item.label + if (hasFinalConsonant(item.label)) "은" else "는"
        if (abs(diff) < 0.05) return Phrase("$subject 같고", "$subject 같습니다")
        val amount = "${cm(abs(diff))}cm"
        val (c, f) = when {
            item.widthLike && diff > 0 -> "넓고" to "넓습니다"
            item.widthLike -> "좁고" to "좁습니다"
            diff > 0 -> "길고" to "깁니다"
            else -> "짧고" to "짧습니다"
        }
        return Phrase("$subject $amount $c", "$subject $amount $f")
    }

    private fun hasFinalConsonant(word: String): Boolean {
        val ch = word.trimEnd().lastOrNull() ?: return false
        if (ch !in '가'..'힣') return false
        return (ch - '가') % 28 != 0
    }
}
