# brandme Fit (Android)

쇼핑 앱(무신사·지그재그·에이블리) 위에 떠 있는 **Fit 버튼**을 누르면, 지금 화면의 상품 사이즈표와
사용자가 저장한 **기준 옷 실측**을 비교해 결과를 쇼핑 앱 위에 보여 주는 앱입니다.

> 실측 비교 결과이며 실제 착용감이나 사이즈 적합도를 보장하지 않습니다.

## 현재 상태 (정직하게)

| 구분 | 내용 |
|---|---|
| 빌드 | `app/build/outputs/apk/debug/app-debug.apk` 생성됨 |
| 자동 테스트 | Android JVM 단위 테스트 53개, 백엔드 7개 통과 |
| 실기기 | **미검증** — 오버레이·캡처·OCR·결과 패널 모두 기기에서 실행해 본 적 없음 |
| 실제 쇼핑 앱 인식 | **미검증**. 번들 카탈로그는 전부 가상 Demo 데이터라 실제 상품과 일치하지 않음 |
| AI Mode | 서버 예제만 있음. 실제 OpenAI 호출은 미검증 |

자세한 한계: [docs/known-limitations.md](docs/known-limitations.md)

## 두 가지 모드

- **Demo Mode (기본값)**: API 키·서버 없이 동작. 기기 안 ML Kit 한국어 OCR → 로컬 Demo 카탈로그 정확 일치 →
  화면에 보이는 실측 사이즈표 파싱 → 기기에서 비교. 외부로 아무것도 보내지 않음.
  카탈로그 결과는 `DEMO` 로, 화면 표 결과는 `미검증` 으로 표시됩니다.
- **AI Mode**: 개인정보 화면에서 외부 전송에 **명시 동의**한 경우에만 선택 가능. 캡처 1장을 `backend/` 서버로 보내고,
  서버가 OpenAI Vision 으로 구조화 JSON 을 추출(Pydantic 검증)합니다. 비교는 여전히 기기에서 합니다.
  **API 키는 서버 환경 변수에만 있고 APK 에는 없습니다.**

홈 화면의 **Demo 체험**은 캡처 없이 Demo 카탈로그 상품으로 결과 화면을 보여 주는 기능이며, 실제 인식이 아닙니다.

## 버전

| 항목 | 버전 |
|---|---|
| Gradle (Wrapper) | 8.14.3 |
| Android Gradle Plugin | 8.13.0 |
| Kotlin / Compose compiler plugin | 2.2.21 |
| KSP | 2.2.21-2.0.4 |
| JDK | 21 (Android Studio 번들 JBR), 바이트코드 target 17 |
| compileSdk / targetSdk / minSdk | 36 / 36 / 34 |
| Compose BOM | 2025.10.01 (Material 3) |
| core-ktx 1.17.0 · activity-compose 1.11.0 · lifecycle 2.9.4 · navigation-compose 2.9.5 | |
| Room 2.8.3 · DataStore 1.1.7 · Coroutines 1.10.2 · kotlinx-serialization 1.9.0 | |
| Retrofit 2.12.0 · OkHttp 4.12.0 · ML Kit text-recognition-korean 16.0.1 | |
| 백엔드 | Python 3.11, FastAPI ≥0.115, Pydantic 2, openai SDK ≥1.60,<3 |

targetSdk 는 이 PC 에 설치된 최신 플랫폼(36)을 사용했습니다. 최신 안정 API 37 로 올리는 방법은 아래 참고.

## 빌드

Windows, Android Studio 설치 기준 (SDK: `%LOCALAPPDATA%\Android\Sdk`).

```bash
cd brandme-fit
export JAVA_HOME="/c/Program Files/Android/Android Studio/jbr"
./gradlew assembleDebug
```

결과: `app/build/outputs/apk/debug/app-debug.apk`

`local.properties` 의 `sdk.dir` 은 이 PC 경로입니다. 다른 PC 에서는 Android Studio 로 열면 자동 생성됩니다.

### 한글 경로 주의

프로젝트 경로(`3d 체형 분석기`)에 한글이 있어 `gradle.properties` 에 `android.overridePathCheck=true` 를 넣었습니다.
APK 빌드는 되지만 **단위 테스트는 한글 경로에서 ClassNotFoundException 으로 실패**합니다. ASCII 드라이브로 매핑해 실행하세요.

```powershell
subst X: "C:\Users\VENN\Desktop\3d 체형 분석기\brandme-fit"
```

```bash
cd /x/ && ./gradlew testDebugUnitTest
```

```powershell
subst X: /d
```

### 설치

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### targetSdk 37 로 올리기

1. Android Studio SDK Manager 에서 Android 17 (API 37) 플랫폼 설치
2. AGP 를 API 37 을 지원하는 버전으로 올림(`gradle/libs.versions.toml` 의 `agp`, 필요 시 Gradle Wrapper)
3. `app/build.gradle.kts` 의 `compileSdk`, `targetSdk` 를 37 로 변경 후 재빌드·재테스트

## 백엔드 (선택, AI Mode)

```bash
cd backend
python -m venv .venv && . .venv/Scripts/activate
pip install -r requirements.txt
cp .env.example .env   # OPENAI_API_KEY, OPENAI_MODEL 입력 (.env 는 커밋 금지)
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

- `GET /health` — 키 설정 여부(`aiConfigured`)
- `POST /api/analyze-screen` — multipart `image`(jpeg/png/webp, 6MB 이하), `consent=true` 필수. 이미지는 저장하지 않음.
  키/모델이 없으면 503 `AI_NOT_CONFIGURED`.
- `POST /api/compare` — `{reference, chart}` → 비교 결과(앱과 같은 알고리즘 v1.0.0)
- 테스트: `python -m unittest discover -s tests`

앱 기본 서버 주소는 에뮬레이터용 `http://10.0.2.2:8000/` 입니다. 실기기는 개인정보 화면에서 PC 의 LAN 주소로 바꾸세요
(디버그 빌드만 평문 HTTP 허용, 릴리스는 HTTPS 필요).

## 릴리스 서명 (절차만 — 키는 저장소에 넣지 않음)

1. 키 생성:
   ```bash
   keytool -genkeypair -v -keystore brandme-release.jks -alias brandme -keyalg RSA -keysize 4096 -validity 10000
   ```
2. 저장소 밖 또는 `.gitignore` 된 `keystore.properties` 에 `storeFile`, `storePassword`, `keyAlias`, `keyPassword` 기록
3. `app/build.gradle.kts` 에 `signingConfigs { create("release") { ... } }` 를 추가해 위 파일을 읽고 `buildTypes.release.signingConfig` 로 지정
4. `./gradlew assembleRelease` (또는 Play 배포용 `bundleRelease`)
5. Play 배포 시 `specialUse` 포그라운드 서비스와 `SYSTEM_ALERT_WINDOW`, MediaProjection 사용 목적을 Play Console 선언서에 설명해야 합니다.

## 구조

```
app/src/main/java/com/brandme/fit/
  ui/{onboarding,home,profile,result,theme}
  overlay/FloatingOverlayService.kt
  capture/{CaptureCoordinator,MediaProjectionService,CaptureConsentActivity}.kt
  recognition/   OCR, 사이즈표 파서, 상품 매칭, 민감 화면, AI 원격 분석, 파이프라인
  catalog/       demo_products.json 모델·검증·로더
  comparison/FitComparisonEngine.kt
  data/{local,model,repository}
app/src/main/assets/demo_products.json   (12개, 전부 demo)
backend/        FastAPI 예제 서버
docs/           architecture, permissions, test-plan, known-limitations
```

## 실기기 완료 기준 시나리오 (미실행)

- **A**: 설치 → 프로필 저장 → 오버레이 허용 → 쇼핑 앱 → 버튼 → 캡처 동의 → 결과 → 닫기 → 쇼핑 계속
- **B**: 사이즈표 없음 → 분석 불가 안내
- **C**: 캡처 거부 → 크래시 없음
- **D**: 서비스 중지 → 버튼·프로젝션·포그라운드 서비스 정리

체크리스트: [docs/test-plan.md](docs/test-plan.md)
