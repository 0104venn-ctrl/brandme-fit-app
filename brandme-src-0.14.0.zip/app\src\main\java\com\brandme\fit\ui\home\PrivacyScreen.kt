package com.brandme.fit.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.brandme.fit.capture.MediaProjectionService
import com.brandme.fit.overlay.FloatingOverlayService
import com.brandme.fit.recognition.AnalysisMode
import com.brandme.fit.ui.theme.WarnRed

/** 개인정보 · 분석 모드 · 데이터 삭제 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyScreen(onBack: () -> Unit, onAllDeleted: () -> Unit) {
    val context = LocalContext.current
    val vm = homeViewModel()
    val state by vm.state.collectAsStateWithLifecycle()
    var confirmDeleteAll by remember { mutableStateOf(false) }
    var askConsent by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf("") }
    LaunchedEffect(state.settings.serverUrl) { url = state.settings.serverUrl }

    if (askConsent) {
        AlertDialog(
            onDismissRequest = { askConsent = false },
            title = { Text("외부 AI 서버 전송 동의") },
            text = {
                Text(
                    "AI Mode에서는 Fit 버튼을 누를 때 캡처한 화면 이미지 1장을 아래 서버로 보내 상품과 사이즈표를 추출해요. " +
                        "화면에 다른 개인정보가 보이면 함께 전송될 수 있어요. 결제·계정·메시지 화면으로 보이면 전송 전에 기기에서 중단해요. " +
                        "서버는 이 저장소의 backend 예제이며, 운영자가 OpenAI API로 전달할 수 있어요.\n\n서버: ${state.settings.serverUrl}",
                )
            },
            confirmButton = { TextButton(onClick = { askConsent = false; vm.setAiConsent(true) }) { Text("동의") } },
            dismissButton = { TextButton(onClick = { askConsent = false }) { Text("동의 안 함") } },
        )
    }
    if (confirmDeleteAll) {
        AlertDialog(
            onDismissRequest = { confirmDeleteAll = false },
            title = { Text("모든 데이터 삭제") },
            text = { Text("내 몸 치수, 비교 기록, 설정을 모두 지우고 버튼과 캡처를 중지해요. 되돌릴 수 없어요.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDeleteAll = false
                    FloatingOverlayService.stop(context)
                    MediaProjectionService.stop(context)
                    vm.deleteAll(onAllDeleted)
                }) { Text("삭제", color = WarnRed) }
            },
            dismissButton = { TextButton(onClick = { confirmDeleteAll = false }) { Text("취소") } },
        )
    }

    Scaffold(topBar = { TopAppBar(title = { Text("개인정보 · 설정") }, navigationIcon = { TextButton(onClick = onBack) { Text("뒤로") } }) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("이 앱이 하는 일", fontWeight = FontWeight.Bold)
                    Text(
                        "• Fit 버튼을 누를 때만 화면 1장을 캡처해요.\n" +
                            "• 원본 이미지는 저장하지 않고 분석 직후 메모리에서 지워요.\n" +
                            "• 비교 기록에는 상품명·가까운 사이즈 같은 요약만 남겨요.\n" +
                            "• 결제·계정·메시지 화면으로 보이면 분석을 멈춰요.\n" +
                            "• 캡처를 막아 둔 보안 화면(FLAG_SECURE)은 우회하지 않아요.\n" +
                            "• 접근성 서비스와 루트 권한을 쓰지 않아요.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("분석 모드", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = state.settings.mode == AnalysisMode.DEMO, onClick = { vm.setMode(AnalysisMode.DEMO) }, label = { Text("Demo Mode") })
                        FilterChip(
                            selected = state.settings.mode == AnalysisMode.AI,
                            enabled = state.settings.aiConsent,
                            onClick = { vm.setMode(AnalysisMode.AI) },
                            label = { Text("AI Mode") },
                        )
                    }
                    Text(
                        "Demo Mode: 기기 안 OCR + Demo 카탈로그 + 화면에 보이는 사이즈표만 사용. 키·서버 불필요.\n" +
                            "AI Mode: 화면 이미지를 서버로 보내 추출. 서버에 OpenAI 키가 설정되어 있어야 동작해요.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("외부 AI 서버 전송 동의", modifier = Modifier.weight(1f))
                        Switch(checked = state.settings.aiConsent, onCheckedChange = { if (it) askConsent = true else vm.setAiConsent(false) })
                    }
                    OutlinedTextField(
                        value = url, onValueChange = { url = it }, label = { Text("AI 서버 주소") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    TextButton(onClick = { vm.setServerUrl(url) }) { Text("서버 주소 저장") }
                }
            }
            OutlinedButton(onClick = { vm.deleteHistory() }, modifier = Modifier.fillMaxWidth()) { Text("비교 기록 삭제") }
            Button(
                onClick = { confirmDeleteAll = true },
                colors = ButtonDefaults.buttonColors(containerColor = WarnRed),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("모든 데이터 삭제") }
        }
    }
}
